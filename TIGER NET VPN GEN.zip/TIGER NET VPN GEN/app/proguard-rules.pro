# ══════════════════════════════════════════════════════════════════
#  ProGuard Rules — TIGER NET VPN GEN
# ══════════════════════════════════════════════════════════════════

# ── Optimization ──────────────────────────────────────────────────
-optimizationpasses 5
-allowaccessmodification
-repackageclasses
-ignorewarnings

# ── Debug Info (stack traces) ─────────────────────────────────────
-keepattributes SourceFile,LineNumberTable
-renamesourcefileattribute SourceFile

# ══════════════════════════════════════════════════════════════════
#  App Classes
# ══════════════════════════════════════════════════════════════════
-keep class gen.tiger.net.** { *; }
-keep class gen.tiger.net.models.** { *; }
-keep class gen.tiger.net.constants.** { *; }
-keep class gen.tiger.net.utils.** { *; }

# ══════════════════════════════════════════════════════════════════
#  JSON — org.json
# ══════════════════════════════════════════════════════════════════
-keep class org.json.** { *; }
-keepclassmembers class * {
    @org.json.* <fields>;
    @org.json.* <methods>;
}

# ══════════════════════════════════════════════════════════════════
#  OkHttp + Okio
# ══════════════════════════════════════════════════════════════════
-dontwarn okhttp3.**
-dontwarn okio.**
-keep class okhttp3.** { *; }
-keep class okio.** { *; }
-keepnames class okhttp3.internal.publicsuffix.PublicSuffixDatabase

# ══════════════════════════════════════════════════════════════════
#  Material Components
# ══════════════════════════════════════════════════════════════════
-keep class com.google.android.material.** { *; }
-dontwarn com.google.android.material.**

# ══════════════════════════════════════════════════════════════════
#  AndroidX
# ══════════════════════════════════════════════════════════════════
-keep class androidx.** { *; }
-dontwarn androidx.**

# ══════════════════════════════════════════════════════════════════
#  Security — AES / Crypto
# ══════════════════════════════════════════════════════════════════
-keep class javax.crypto.** { *; }
-keep class java.security.** { *; }

# ══════════════════════════════════════════════════════════════════
#  Enums
# ══════════════════════════════════════════════════════════════════
-keepclassmembers enum * {
    public static **[] values();
    public static ** valueOf(java.lang.String);
}

# ══════════════════════════════════════════════════════════════════
#  Serializable
# ══════════════════════════════════════════════════════════════════
-keepclassmembers class * implements java.io.Serializable {
    static final long serialVersionUID;
    private static final java.io.ObjectStreamField[] serialPersistentFields;
    private void writeObject(java.io.ObjectOutputStream);
    private void readObject(java.io.ObjectInputStream);
    java.lang.Object writeReplace();
    java.lang.Object readResolve();
}

# ══════════════════════════════════════════════════════════════════
#  Suppress common warnings
# ══════════════════════════════════════════════════════════════════
-dontwarn java.lang.invoke.**
-dontwarn **$$Lambda$*
-dontwarn kotlin.**
