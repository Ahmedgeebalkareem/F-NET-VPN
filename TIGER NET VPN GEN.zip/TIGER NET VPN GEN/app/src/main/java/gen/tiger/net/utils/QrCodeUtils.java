package gen.tiger.net.utils;

import android.graphics.Bitmap;
import android.graphics.Color;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.EncodeHintType;
import com.google.zxing.WriterException;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.QRCodeWriter;
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel;

import java.util.EnumMap;
import java.util.Map;

/**
 * يولّد QR Code كـ Bitmap من أي نص.
 * يُستخدم لتصدير الـ Config المُشفَّر بصورة قابلة للمسح.
 */
public final class QrCodeUtils {

    private static final int QR_SIZE   = 512; // بكسل
    private static final int COLOR_ON  = Color.BLACK;
    private static final int COLOR_OFF = Color.WHITE;

    private QrCodeUtils() {}

    /**
     * يُنشئ Bitmap يحتوي QR Code للنص المُمرَّر.
     *
     * @param content النص المراد تحويله (الـ Config المُشفَّر)
     * @return Bitmap جاهز للعرض أو الحفظ، أو null عند الفشل
     */
    public static Bitmap generate(String content) {
        if (content == null || content.isEmpty()) return null;

        Map<EncodeHintType, Object> hints = new EnumMap<>(EncodeHintType.class);
        hints.put(EncodeHintType.ERROR_CORRECTION, ErrorCorrectionLevel.M);
        hints.put(EncodeHintType.MARGIN, 2);
        hints.put(EncodeHintType.CHARACTER_SET, "UTF-8");

        try {
            QRCodeWriter writer = new QRCodeWriter();
            BitMatrix matrix = writer.encode(content, BarcodeFormat.QR_CODE, QR_SIZE, QR_SIZE, hints);

            int width  = matrix.getWidth();
            int height = matrix.getHeight();
            int[] pixels = new int[width * height];

            for (int y = 0; y < height; y++) {
                for (int x = 0; x < width; x++) {
                    pixels[y * width + x] = matrix.get(x, y) ? COLOR_ON : COLOR_OFF;
                }
            }

            Bitmap bmp = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
            bmp.setPixels(pixels, 0, width, 0, 0, width, height);
            return bmp;

        } catch (WriterException e) {
            return null;
        }
    }

    /**
     * يتحقق إذا كان النص طويلاً جداً لـ QR Code.
     * الحد الأقصى لـ QR Code بمستوى M هو ~1800 حرف.
     */
    public static boolean isTooLong(String content) {
        return content != null && content.length() > 1800;
    }
}
