package gen.tiger.net.utils;

import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Simple async HTTP GET request utility.
 * Runs on a shared thread pool and delivers results on the main thread.
 */
public final class GETRequest {

    private static final String TAG            = "GETRequest";
    private static final int    TIMEOUT_MS     = 15_000;
    private static final String DEFAULT_TOKEN  = "Bearer";
    private static final String DEFAULT_ACCEPT = "application/json";

    private static volatile ExecutorService EXECUTOR = Executors.newCachedThreadPool();
    private static final Handler            MAIN     = new Handler(Looper.getMainLooper());

    // ══════════════════════════════════════════════════════════════
    //  Listener
    // ══════════════════════════════════════════════════════════════
    public interface Listener {
        void onResponse(@NonNull String response);
        void onError(@NonNull String error);
    }

    // ══════════════════════════════════════════════════════════════
    //  Fields
    // ══════════════════════════════════════════════════════════════
    private final String   api;
    private final String   authToken;
    private final String   tokenType;
    private final String   acceptHeader;
    private final Listener listener;

    // ══════════════════════════════════════════════════════════════
    //  Constructors
    // ══════════════════════════════════════════════════════════════
    public GETRequest(@NonNull String api, @Nullable String authToken, @NonNull Listener listener) {
        this(api, authToken, DEFAULT_TOKEN, DEFAULT_ACCEPT, listener);
    }

    public GETRequest(
            @NonNull  String   api,
            @Nullable String   authToken,
            @Nullable String   tokenType,
            @Nullable String   acceptHeader,
            @NonNull  Listener listener) {
        this.api          = api;
        this.authToken    = authToken;
        this.tokenType    = nonEmpty(tokenType,    DEFAULT_TOKEN);
        this.acceptHeader = nonEmpty(acceptHeader, DEFAULT_ACCEPT);
        this.listener     = listener;
    }

    // ══════════════════════════════════════════════════════════════
    //  Execute
    // ══════════════════════════════════════════════════════════════
    public void start() {
        getExecutor().submit(this::execute);
    }

    private void execute() {
        HttpURLConnection conn = null;
        try {
            conn = (HttpURLConnection) new URL(api).openConnection();
            conn.setConnectTimeout(TIMEOUT_MS);
            conn.setReadTimeout(TIMEOUT_MS);
            conn.setRequestMethod("GET");
            conn.setRequestProperty("Accept", acceptHeader);

            if (authToken != null && !authToken.isEmpty()) {
                conn.setRequestProperty("Authorization", tokenType + " " + authToken);
            }

            int code = conn.getResponseCode();
            if (code == HttpURLConnection.HTTP_OK) {
                postSuccess(readResponse(conn));
            } else {
                postError("HTTP " + code + ": " + conn.getResponseMessage());
            }

        } catch (Exception e) {
            Log.e(TAG, "Request failed: " + api, e);
            postError("Request failed: " + e.getMessage());
        } finally {
            if (conn != null) conn.disconnect();
        }
    }

    // ══════════════════════════════════════════════════════════════
    //  Helpers
    // ══════════════════════════════════════════════════════════════
    private static synchronized ExecutorService getExecutor() {
        if (EXECUTOR == null || EXECUTOR.isShutdown() || EXECUTOR.isTerminated()) {
            EXECUTOR = Executors.newCachedThreadPool();
        }
        return EXECUTOR;
    }

    private static String readResponse(HttpURLConnection conn) throws Exception {
        try (BufferedReader reader = new BufferedReader(
                new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8))) {
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) sb.append(line);
            return sb.toString();
        }
    }

    private static String nonEmpty(@Nullable String value, @NonNull String fallback) {
        return (value == null || value.isEmpty()) ? fallback : value;
    }

    private void postSuccess(String response) {
        MAIN.post(() -> listener.onResponse(response));
    }

    private void postError(String msg) {
        MAIN.post(() -> listener.onError(msg));
    }
}