package gen.tiger.net.activities;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.appbar.CollapsingToolbarLayout;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.button.MaterialButtonToggleGroup;
import com.google.android.material.floatingactionbutton.ExtendedFloatingActionButton;
import com.google.android.material.color.DynamicColors;
import com.google.android.material.materialswitch.MaterialSwitch;
import com.google.android.material.textfield.MaterialAutoCompleteTextView;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

import gen.tiger.net.R;
import gen.tiger.net.constants.Constant;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.Arrays;
import java.util.List;

public class SSLNetworkActivity extends AppCompatActivity {

    private static final String TAG = "SSLNetworkActivity";

    // ── Views ──────────────────────────────────────────────────────
    private MaterialToolbar toolbar;
    private TextInputEditText nameEditText;
    private TextInputEditText sniEditText;
    private TextInputEditText infoEditText;
    private TextInputEditText customPortEditText;
    private TextInputEditText proxyEditText;
    private TextInputEditText proxyPortEditText;
    private TextInputEditText payloadEditText;
    private MaterialSwitch useDefaultProxySwitch;
    private MaterialAutoCompleteTextView sslModeSpinner;
    private MaterialAutoCompleteTextView prioritySpinner;
    private MaterialButtonToggleGroup segmentGroup;
    private ExtendedFloatingActionButton fab;
    // proxyCardView removed — proxyLayout (sslproxylay) is the full card now
    private TextInputLayout payloadLayout;
    private View proxyLayout;

    // ── Data ───────────────────────────────────────────────────────
    private List<String> priorityOptions;
    private List<String> sslModeOptions;
    private int[] modeConstants;
    private boolean isEdit;

    // ══════════════════════════════════════════════════════════════
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        DynamicColors.applyToActivityIfAvailable(this);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fragment_ssl_network);

        bindViews();
        setupToolbar();
        setupAdapters();
        setupListeners();
        fillData();
    }

    // ══════════════════════════════════════════════════════════════
    //  ربط الـ Views
    // ══════════════════════════════════════════════════════════════
    private void bindViews() {
        toolbar = findViewById(R.id.toolbar);
        nameEditText = findViewById(R.id.etSSLName);
        sniEditText = findViewById(R.id.etSSLSNI);
        infoEditText = findViewById(R.id.etSSLInfo);
        customPortEditText = findViewById(R.id.etSSLPort);
        proxyEditText = findViewById(R.id.etSSLProxyIP);
        proxyPortEditText = findViewById(R.id.etSSLProxyPort);
        payloadEditText = findViewById(R.id.etSSLPayload);
        useDefaultProxySwitch = findViewById(R.id.swSSLUseDefProxy);
        segmentGroup = findViewById(R.id.segment_server_type);
        fab =findViewById(R.id.ssl_generate);
        // proxy_cv removed in v2 layout — proxyLayout is the full card now
        sslModeSpinner = findViewById(R.id.sslmethod);
        prioritySpinner = findViewById(R.id.etSSLPriority);
        payloadLayout = findViewById(R.id.lay_payload);
        proxyLayout = findViewById(R.id.sslproxylay);
    }

    // ══════════════════════════════════════════════════════════════
    //  إعداد الـ Toolbar
    // ══════════════════════════════════════════════════════════════
    private void setupToolbar() {
        setSupportActionBar(toolbar);
        toolbar.setNavigationOnClickListener(v -> finish());
    }

    /*@Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_network, menu);
        // إخفاء زر Generator لأن SSL لا يحتاجه
        menu.findItem(R.id.action_payload_gen).setVisible(false);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.action_save) {
            if (!validate()) return true;
            try {
                JSONObject sslJson = buildSSLNetworkJson();
                Intent result = new Intent();
                result.putExtra("ssl_network_data", sslJson.toString());
                result.putExtra("is_edit", isEdit);
                setResult(RESULT_OK, result);
                finish();
            } catch (JSONException e) {
                Log.e(TAG, "Save error: " + e.getMessage(), e);
                toast("Error: " + e.getMessage());
            }
            return true;
        }
        return super.onOptionsItemSelected(item);
    }*/

    // ══════════════════════════════════════════════════════════════
    //  إعداد الـ Adapters
    // ══════════════════════════════════════════════════════════════
    private void setupAdapters() {
        priorityOptions = Arrays.asList("PRIORITY LOW", "PRIORITY MEDIUM", "PRIORITY HIGH");
        sslModeOptions = Arrays.asList("SSL+DIRECT", "SSL+PAYLOAD", "SSL+PAYLOAD+WS");
        modeConstants =
                new int[] {
                    Constant.Mode.SSL_DIRECT,
                    Constant.Mode.SSL_DIRECT_WITH_PAYLOAD,
                    Constant.Mode.SSL_HTTP_PROXY
                };

        prioritySpinner.setAdapter(new ArrayAdapter<>(this, R.layout.item, priorityOptions));
        sslModeSpinner.setAdapter(new ArrayAdapter<>(this, R.layout.item, sslModeOptions));

        prioritySpinner.setText(priorityOptions.get(0), false);
        sslModeSpinner.setText(sslModeOptions.get(0), false);
    }

    // ══════════════════════════════════════════════════════════════
    //  إعداد الـ Listeners
    // ══════════════════════════════════════════════════════════════
    private void setupListeners() {
        sslModeSpinner.setOnItemClickListener(
                (parent, view, position, id) -> updateSSLVisibility(position));

        useDefaultProxySwitch.setOnCheckedChangeListener(
                (btn, isChecked) -> {
                    proxyEditText.setText(isChecked ? "[DEFAULT]" : "");
                    proxyEditText.setEnabled(!isChecked);
                });
        // ✅ Segmented Buttons Listener
        segmentGroup.addOnButtonCheckedListener(
                (group, checkedId, isChecked) -> {
                    if (!isChecked) return;

                    String type = "cf";

                    if (checkedId == R.id.btn_cf) {
                        type = "cf";
                    } else if (checkedId == R.id.btn_ws) {
                        type = "ws";
                    } else if (checkedId == R.id.btn_http) {
                        type = "http";
                    }

                    Log.d("SERVER_TYPE", type);
                });
                
        fab.setOnClickListener(v -> saveAndReturn());
    }

    // ══════════════════════════════════════════════════════════════
    //  تعبئة البيانات من الـ Intent
    // ══════════════════════════════════════════════════════════════
    private void fillData() {
        Intent intent = getIntent();
        isEdit = intent.getBooleanExtra("is_edit", false);

        if (isEdit) {
            // ✅ Set title on CollapsingToolbarLayout directly
            View parent = (View) toolbar.getParent();
            if (parent instanceof CollapsingToolbarLayout) {
                ((CollapsingToolbarLayout) parent)
                        .setTitle("Edit SSL NETWORK");
            }
            try {
                JSONObject network = new JSONObject(intent.getStringExtra("ssl_network_json"));
                nameEditText.setText(network.optString("Name", ""));
                sniEditText.setText(MainActivity.decrypt(network.optString("SNIHost", "")));
                payloadEditText.setText(MainActivity.decrypt(network.optString("Payload", "")));
                infoEditText.setText(network.optString("Info", ""));
                customPortEditText.setText(network.optString("CustomSSLPort", ""));

                String serverType = network.optString("ServerHostDNS", "cf");

                int id = R.id.btn_cf;

                switch (serverType) {
                    case "ws":
                        id = R.id.btn_ws;
                        break;
                    case "http":
                        id = R.id.btn_http;
                        break;
                }

                segmentGroup.check(id);

                // Priority
                int priorityIndex = network.optInt("Priority", 0);
                if (priorityIndex >= 0 && priorityIndex < priorityOptions.size())
                    prioritySpinner.setText(priorityOptions.get(priorityIndex), false);

                // Proxy Settings
                if (network.has("ProxySettings")) {
                    JSONObject proxy = network.getJSONObject("ProxySettings");
                    proxyPortEditText.setText(proxy.optString("Port", "443"));
                    String squid = MainActivity.decrypt(proxy.optString("Squid", ""));
                    if ("Default".equals(squid)) {
                        useDefaultProxySwitch.setChecked(true);
                        proxyEditText.setText("[Default]");
                        proxyEditText.setEnabled(false);
                    } else {
                        useDefaultProxySwitch.setChecked(false);
                        proxyEditText.setText(squid);
                        proxyEditText.setEnabled(true);
                    }
                }

                // SSL Mode
                int tunnelType = network.optInt("TunnelType", Constant.Mode.SSL_DIRECT);
                int sslModePos = getSSLModePosition(tunnelType);
                sslModeSpinner.setText(sslModeOptions.get(sslModePos), false);
                updateSSLVisibility(sslModePos);

            } catch (Exception e) {
                Log.e(TAG, "fillData: " + e.getMessage(), e);
            }
        } else {
            // title set via CollapsingToolbarLayout
            View parent2 = (View) toolbar.getParent();
            if (parent2 instanceof CollapsingToolbarLayout) {
                ((CollapsingToolbarLayout) parent2)
                        .setTitle("Add SSL NETWORK");
            }
            useDefaultProxySwitch.setChecked(true);
            proxyEditText.setText("[DEFAULT]");
            proxyEditText.setEnabled(false);
            segmentGroup.check(R.id.btn_cf); // افتراضي
            updateSSLVisibility(0);
        }
    }

    // ══════════════════════════════════════════════════════════════
    //  تحديث الواجهة بناءً على وضع SSL
    // ══════════════════════════════════════════════════════════════
    private void updateSSLVisibility(int position) {
        boolean showPayload = position > 0;
        boolean showProxy = position == 2;
        payloadLayout.setVisibility(showPayload ? View.VISIBLE : View.GONE);
        useDefaultProxySwitch.setVisibility(showProxy ? View.VISIBLE : View.GONE);
        proxyLayout.setVisibility(showProxy ? View.VISIBLE : View.GONE);
        // proxyCardView removed — proxyLayout IS the card in the new layout
    }

    private int getSSLModePosition(int tunnelType) {
        return switch (tunnelType) {
            case Constant.Mode.SSL_DIRECT -> 0;
            case Constant.Mode.SSL_DIRECT_WITH_PAYLOAD -> 1;
            case Constant.Mode.SSL_HTTP_PROXY -> 2;
            default -> 0;
        };
    }

    // ══════════════════════════════════════════════════════════════
    //  التحقق من صحة المدخلات
    // ══════════════════════════════════════════════════════════════
    private boolean validate() {
        String name = getText(nameEditText);
        String sni = getText(sniEditText);

        if (name.isEmpty()) {
            nameEditText.setError("Required");
            nameEditText.requestFocus();
            return false;
        }
        if (sni.isEmpty()) {
            sniEditText.setError("Required");
            sniEditText.requestFocus();
            return false;
        }

        String sslMode = sslModeSpinner.getText().toString();
        int sslModePos = sslModeOptions.indexOf(sslMode);

        if (sslModePos > 0 && TextUtils.isEmpty(payloadEditText.getText())) {
            payloadEditText.setError("Payload is required for this mode");
            payloadEditText.requestFocus();
            return false;
        }

        if (sslModePos == 2) {
            String proxy = getText(proxyEditText);
            String port = getText(proxyPortEditText);
            if (proxy.isEmpty() || proxy.equals("[DEFAULT]")) {
                proxyEditText.setError("Required");
                proxyEditText.requestFocus();
                return false;
            }
            if (port.isEmpty() || !port.matches("\\d+")) {
                proxyPortEditText.setError("Required");
                proxyPortEditText.requestFocus();
                return false;
            }
        }
        return true;
    }
    
    // ══════════════════════════════════════════════════════════════
    //  حفظ وإرجاع
    // ══════════════════════════════════════════════════════════════
    private void saveAndReturn() {
        if (!validate()) return;
            try {
                JSONObject sslJson = buildSSLNetworkJson();
                Intent result = new Intent();
                result.putExtra("ssl_network_data", sslJson.toString());
                result.putExtra("is_edit", isEdit);
                setResult(RESULT_OK, result);
                finish();
            } catch (JSONException e) {
                Log.e(TAG, "Save error: " + e.getMessage(), e);
                toast("Error: " + e.getMessage());
            }
    }

    // ══════════════════════════════════════════════════════════════
    //  بناء JSONObject من الحقول
    // ══════════════════════════════════════════════════════════════
    private JSONObject buildSSLNetworkJson() throws JSONException {
        JSONObject sslJson = new JSONObject();
        String sslMode = sslModeSpinner.getText().toString();
        int sslModePos = sslModeOptions.indexOf(sslMode);

        sslJson.put("Name", getText(nameEditText));
        sslJson.put("Info", getText(infoEditText));

        try {
            sslJson.put("SNIHost", MainActivity.encrypt(getText(sniEditText)));
        } catch (Exception ignored) {
        }

        // TunnelType
        if (sslModePos >= 0 && sslModePos < modeConstants.length)
            sslJson.put("TunnelType", modeConstants[sslModePos]);

        // Payload
        if (sslModePos > 0) {
            try {
                sslJson.put("Payload", MainActivity.encrypt(getText(payloadEditText)));
            } catch (Exception ignored) {
            }
        }

        // Priority
        sslJson.put("Priority", priorityOptions.indexOf(prioritySpinner.getText().toString()));

        // Custom SSL Port
        String customPort = getText(customPortEditText);
        if (!TextUtils.isEmpty(customPort)) sslJson.put("CustomSSLPort", customPort);

        int selectedId = segmentGroup.getCheckedButtonId();

        String dns = "cf";

        if (selectedId == R.id.btn_ws) {
            dns = "ws";
        } else if (selectedId == R.id.btn_http) {
            dns = "http";
        }

        sslJson.put("ServerHostDNS", dns);

        // Proxy Settings (SSL+PAYLOAD+WS فقط)
        if (sslModePos == 2) {
            JSONObject proxySettings = new JSONObject();
            String proxy = useDefaultProxySwitch.isChecked() ? "Default" : getText(proxyEditText);
            try {
                proxySettings.put("Squid", MainActivity.encrypt(proxy));
            } catch (Exception ignored) {
            }
            proxySettings.put("Port", getText(proxyPortEditText));
            sslJson.put("ProxySettings", proxySettings);
        }

        return sslJson;
    }

    // ══════════════════════════════════════════════════════════════
    //  Helpers
    // ══════════════════════════════════════════════════════════════
    private String getText(TextView view) {
        return (view != null && view.getText() != null) ? view.getText().toString().trim() : "";
    }

    private void toast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }
}
