package gen.tiger.net.models;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Build;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.preference.PreferenceManager;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.Reader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.security.MessageDigest;
import java.util.ArrayList;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

public class Config {

    private static final String TAG = "Config";

    // ══════════════════════════════════════════════════════════════
    //  Constants
    // ══════════════════════════════════════════════════════════════
    private static final String FILE_NAME = "data.ovpnudp";

    private static String getInternalKey(Context ctx) {
        String raw = ctx.getPackageName()
                + "|" + android.os.Build.MANUFACTURER
                + "|" + android.os.Build.MODEL;
        try {
            java.security.MessageDigest md = java.security.MessageDigest.getInstance("SHA-256");
            byte[] hash = md.digest(raw.getBytes(StandardCharsets.UTF_8));
            return android.util.Base64.encodeToString(hash, 0, 16, android.util.Base64.NO_WRAP);
        } catch (Exception e) {
            return "TigerFallbackKey";
        }
    }

    // BUG FIX #1: ENCRYPTED_PASSCODE كان plain text. الاسم مضلّل لأنه ليس
    // مشفّراً. تمت إعادة تسميته PLAIN_PASSCODE لتوضيح الحقيقة.
    private static final String PLAIN_PASSCODE = "hamoody";

    // BUG FIX #2: كلا المتغيّرين كانا يحملان نفس القيمة (copy-paste bug).
    // GET و POST يجب أن يشيرا لـ endpoints مختلفة.
    // TODO: شفّر الـ URL الصحيح لكل endpoint وضعه هنا.
    private static final String ENCRYPTED_GET_API =
            "qTHoWAEtGlLZNL4dtjAZXYYtOEWRplgvHNGAaA6LqiNBkmMys03FInFZLJzU/XewygW4iToQdzTMcMJ1bG5jIYD2d5fCD8F7KEk/IbT/QmbiqmLg9ZtV+JyTzwCg7a2z";
    // TODO: استبدل هذه القيمة بـ URL مشفّر مختلف لـ POST endpoint
    private static final String ENCRYPTED_POST_API =
            "qTHoWAEtGlLZNL4dtjAZXYYtOEWRplgvHNGAaA6LqiNBkmMys03FInFZLJzU/XewygW4iToQdzTMcMJ1bG5jIYD2d5fCD8F7KEk/IbT/QmbiqmLg9ZtV+JyTzwCg7a2z";

    // ── Prefs Keys ─────────────────────────────────────────────────
    private static final String KEY_SERVERS      = "servers";
    private static final String KEY_NETWORKS     = "networks";
    private static final String KEY_SSL_NETWORKS = "ssl_networks";
    private static final String KEY_USERNAME     = "username";
    private static final String KEY_PASSWORD     = "password";
    private static final String KEY_NOTES        = "notes";
    private static final String KEY_VERSION      = "version";

    // ── JSON Keys ──────────────────────────────────────────────────
    private static final String JSON_SERVERS      = "Servers";
    private static final String JSON_NETWORKS     = "Networks";
    private static final String JSON_SSL_NETWORKS = "SSLNetworks";
    private static final String JSON_USERNAME     = "Username";
    private static final String JSON_PASSWORD     = "Password";
    private static final String JSON_NOTES        = "Notes";
    private static final String JSON_VERSION      = "Version";

    // BUG FIX #3: cachedInternalKey لم يكن volatile → غير آمن للـ threads.
    private static volatile String cachedInternalKey;

    private static String internalKey(Context ctx) {
        if (cachedInternalKey == null) {
            synchronized (Config.class) {
                if (cachedInternalKey == null) {
                    cachedInternalKey = getInternalKey(ctx);
                }
            }
        }
        return cachedInternalKey;
    }

    // ══════════════════════════════════════════════════════════════
    //  Singleton
    // ══════════════════════════════════════════════════════════════

    // BUG FIX #4: getInstance() لم يكن thread-safe. MainActivity تستدعيه
    // من executor thread، مما كان يُسبّب إمكانية إنشاء instances متعددة.
    // الحل: Double-Checked Locking مع volatile.
    @SuppressLint("StaticFieldLeak")
    private static volatile Config instance;

    public static Config getInstance(Context context) {
        if (instance == null) {
            synchronized (Config.class) {
                if (instance == null) {
                    if (context == null) throw new IllegalArgumentException("Context must not be null");
                    instance = new Config(context.getApplicationContext());
                }
            }
        }
        return instance;
    }

    // ══════════════════════════════════════════════════════════════
    //  Fields
    // ══════════════════════════════════════════════════════════════
    private final Context           context;
    private final SharedPreferences prefs;

    private JSONObject jsObj;
    private JSONArray  serverArray;
    private JSONArray  networkArray;
    private JSONArray  sslNetworkArray;

    private String username = "";
    private String password = "";
    private String notes    = "";
    private String version  = "";

    // ══════════════════════════════════════════════════════════════
    //  Constructor
    // ══════════════════════════════════════════════════════════════
    private Config(Context context) {
        this.context = context;
        this.prefs   = PreferenceManager.getDefaultSharedPreferences(context);

        File file = new File(context.getFilesDir(), FILE_NAME);
        if (file.exists() && Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            try (InputStream in = Files.newInputStream(file.toPath())) {
                jsObj = new JSONObject(readStream(in));
                loadFromJson(jsObj);
            } catch (Exception e) {
                Log.e(TAG, "Error loading file, falling back to prefs", e);
                loadFromPrefs();
            }
        } else {
            loadFromPrefs();
        }
    }

    // ══════════════════════════════════════════════════════════════
    //  Decryption
    // ══════════════════════════════════════════════════════════════
    private static String decrypt(@Nullable Context ctx, String encryptedText) {
        try {
            String keyStr = (ctx != null) ? internalKey(ctx) : "TigerStaticFallbk";
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] keyBytes = digest.digest(keyStr.getBytes(StandardCharsets.UTF_8));
            SecretKeySpec key = new SecretKeySpec(keyBytes, "AES");

            IvParameterSpec ivSpec = new IvParameterSpec(new byte[16]);

            Cipher cipher = Cipher.getInstance("AES/CBC/PKCS7Padding");
            cipher.init(Cipher.DECRYPT_MODE, key, ivSpec);

            byte[] decoded  = android.util.Base64.decode(encryptedText, android.util.Base64.NO_WRAP);
            byte[] original = cipher.doFinal(decoded);

            return new String(original, StandardCharsets.UTF_8);
        } catch (Exception e) {
            Log.e(TAG, "Decryption failed", e);
            return null;
        }
    }

    public static String getPasscode() { return PLAIN_PASSCODE; }

    // BUG FIX #5: كانتا تُعيدان null عند فشل الفكّ مما يُسبّب NPE في
    // MyApplication لأن CONFIG_GET_API و CONFIG_POST_API كانا يُهيَّآن
    // في وقت تحميل الكلاس (static field init) بدون context.
    // الحل: إرجاع String فارغة بدلاً من null + @NonNull annotation.
    @NonNull
    public static String getGetApiUrl() {
        String url = decrypt(null, ENCRYPTED_GET_API);
        if (url == null) {
            Log.w(TAG, "getGetApiUrl: decryption returned null, check ENCRYPTED_GET_API value");
            return "";
        }
        return url;
    }

    @NonNull
    public static String getPostApiUrl() {
        String url = decrypt(null, ENCRYPTED_POST_API);
        if (url == null) {
            Log.w(TAG, "getPostApiUrl: decryption returned null, check ENCRYPTED_POST_API value");
            return "";
        }
        return url;
    }

    // ══════════════════════════════════════════════════════════════
    //  Load & Save
    // ══════════════════════════════════════════════════════════════
    private void loadFromJson(JSONObject obj) {
        serverArray     = safeArray(obj, JSON_SERVERS);
        networkArray    = safeArray(obj, JSON_NETWORKS);
        sslNetworkArray = safeArray(obj, JSON_SSL_NETWORKS);
        username = obj.optString(JSON_USERNAME, "");
        password = obj.optString(JSON_PASSWORD, "");
        notes    = obj.optString(JSON_NOTES,    "");
        version  = obj.optString(JSON_VERSION,  "");
    }

    // BUG FIX #6: loadFromPrefs() كانت لا تُحمّل notes و version.
    // عند إعادة التشغيل على أجهزة API < 26 تُستخدم prefs فقط،
    // فكانت notes و version تُفقد عند كل إعادة تشغيل.
    private void loadFromPrefs() {
        try {
            serverArray     = new JSONArray(prefs.getString(KEY_SERVERS,      "[]"));
            networkArray    = new JSONArray(prefs.getString(KEY_NETWORKS,     "[]"));
            sslNetworkArray = new JSONArray(prefs.getString(KEY_SSL_NETWORKS, "[]"));
            username = prefs.getString(KEY_USERNAME, "");
            password = prefs.getString(KEY_PASSWORD, "");
            notes    = prefs.getString(KEY_NOTES,    "");   // ✅ إضافة جديدة
            version  = prefs.getString(KEY_VERSION,  "");   // ✅ إضافة جديدة
        } catch (JSONException e) {
            Log.e(TAG, "Error loading from prefs", e);
            serverArray     = new JSONArray();
            networkArray    = new JSONArray();
            sslNetworkArray = new JSONArray();
        }
    }

    public void setJson(String jsonText) throws JSONException {
        if (jsonText == null || jsonText.trim().isEmpty())
            throw new JSONException("Empty JSON string.");
        this.jsObj = new JSONObject(jsonText);
        loadFromJson(this.jsObj);
        savePrefs();
    }

    public void save() {
        File file = new File(context.getFilesDir(), FILE_NAME);
        try (OutputStream out = new FileOutputStream(file)) {
            out.write(toString().getBytes(StandardCharsets.UTF_8));
            out.flush();
            savePrefs();
        } catch (IOException e) {
            Log.e(TAG, "Error saving file: " + e.getMessage(), e);
        }
    }

    // BUG FIX #7: savePrefs() كانت لا تحفظ notes و version.
    // أي تغيير في الحقلين كان يضيع عند إعادة التشغيل.
    private void savePrefs() {
        prefs.edit()
             .putString(KEY_SERVERS,      serverArray.toString())
             .putString(KEY_NETWORKS,     networkArray.toString())
             .putString(KEY_SSL_NETWORKS, sslNetworkArray.toString())
             .putString(KEY_USERNAME,     username)
             .putString(KEY_PASSWORD,     password)
             .putString(KEY_NOTES,        notes)      // ✅ إضافة جديدة
             .putString(KEY_VERSION,      version)    // ✅ إضافة جديدة
             .apply();
    }

    // ══════════════════════════════════════════════════════════════
    //  Getters
    // ══════════════════════════════════════════════════════════════
    public String    getUsername()       { return username; }
    public String    getPassword()       { return password; }
    public String    getNotes()          { return notes;    }
    public String    getVersion()        { return version;  }

    public JSONArray getServerArray()    { return serverArray;     }
    public JSONArray getNetworkArray()   { return networkArray;    }
    public JSONArray getSSLNetworkArray(){ return sslNetworkArray; }

    public ArrayList<JSONObject> getServerList()     { return toList(serverArray);     }
    public ArrayList<JSONObject> getNetworkList()    { return toList(networkArray);    }
    public ArrayList<JSONObject> getSSLNetworkList() { return toList(sslNetworkArray); }

    // ══════════════════════════════════════════════════════════════
    //  Setters
    // ══════════════════════════════════════════════════════════════
    public void setUsername(String v) { this.username = v != null ? v : ""; }
    public void setPassword(String v) { this.password = v != null ? v : ""; }
    public void setNotes(String v)    { this.notes    = v != null ? v : ""; }
    public void setVersion(String v)  { this.version  = v != null ? v : "1.0.0"; }

    public void addServer(JSONObject obj)     { if (obj != null) serverArray.put(obj);     }
    public void addNetwork(JSONObject obj)    { if (obj != null) networkArray.put(obj);    }
    public void addSSLNetwork(JSONObject obj) { if (obj != null) sslNetworkArray.put(obj); }

    // ══════════════════════════════════════════════════════════════
    //  toString
    // ══════════════════════════════════════════════════════════════
    @NonNull
    @Override
    public String toString() {
        try {
            return new JSONObject()
                    .put(JSON_SERVERS,      serverArray)
                    .put(JSON_NETWORKS,     networkArray)
                    .put(JSON_SSL_NETWORKS, sslNetworkArray)
                    .put(JSON_USERNAME,     username)
                    .put(JSON_PASSWORD,     password)
                    .put(JSON_NOTES,        notes)
                    .put(JSON_VERSION,      version)
                    .toString(2);
        } catch (JSONException e) {
            Log.e(TAG, "Error converting to JSON", e);
            return "{}";
        }
    }

    // ══════════════════════════════════════════════════════════════
    //  Helpers
    // ══════════════════════════════════════════════════════════════
    private JSONArray safeArray(JSONObject obj, String key) {
        JSONArray arr = obj.optJSONArray(key);
        return arr != null ? arr : new JSONArray();
    }

    private ArrayList<JSONObject> toList(JSONArray array) {
        ArrayList<JSONObject> list = new ArrayList<>();
        for (int i = 0; i < array.length(); i++) {
            JSONObject obj = array.optJSONObject(i);
            if (obj != null) list.add(obj);
        }
        return list;
    }

    private String readStream(InputStream input) throws IOException {
        StringBuilder sb = new StringBuilder();
        try (Reader reader = new BufferedReader(
                new InputStreamReader(input, StandardCharsets.UTF_8))) {
            char[] buf = new char[4096];
            int n;
            while ((n = reader.read(buf)) != -1) sb.append(buf, 0, n);
        }
        return sb.toString();
    }
}
