package gen.tiger.net.activities;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.color.DynamicColors;
import com.google.android.material.appbar.CollapsingToolbarLayout;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.materialswitch.MaterialSwitch;
import com.google.android.material.textfield.MaterialAutoCompleteTextView;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

import org.json.JSONException;
import org.json.JSONObject;

import gen.tiger.net.R;

public class V2RayActivity extends AppCompatActivity {

    private static final String TAG = "V2RayActivity";

    // ── Options ────────────────────────────────────────────────────
    private static final String[] ENCRYPT_OPTIONS   = {"auto", "none", "aes-128-gcm", "chacha20-poly1305"};
    private static final String[] TRANSPORT_OPTIONS = {"tcp", "ws", "grpc"};
    private static final String[] TYPE_OPTIONS      = {"none", "http"};
    private static final String[] TYPE_WS_OPTIONS   = {"none"};   // ws لا يدعم http type
    private static final String[] TLS_OPTIONS       = {"none", "tls"};

    // ── Defaults ───────────────────────────────────────────────────
    private static final String DEF_ENCRYPT   = "auto";
    private static final String DEF_TRANSPORT = "tcp";
    private static final String DEF_TYPE      = "none";
    private static final String DEF_TLS       = "none";

    // ── Views ──────────────────────────────────────────────────────
    private MaterialToolbar              toolbar;
    private TextInputEditText            etAddress;
    private TextInputEditText            etPort;
    private TextInputEditText            etUUID;
    private TextInputEditText            etAlterId;
    private TextInputEditText            etHost;
    private TextInputEditText            etPath;
    private TextInputEditText            etSni;
    private MaterialAutoCompleteTextView spinnerEncrypt;
    private MaterialAutoCompleteTextView spinnerTransport;
    private MaterialAutoCompleteTextView spinnerType;
    private MaterialAutoCompleteTextView spinnerTls;
    private TextInputLayout              layHost;
    private TextInputLayout              layPath;
    private TextInputLayout              laySni;
    private MaterialSwitch               switchMux;

    // ── State ──────────────────────────────────────────────────────
    private boolean isEdit;

    /**
     * نتتبع الحالة الحالية لكليهما لأن toggleHostPath() يحتاجهما معاً.
     */
    private String currentTransport = DEF_TRANSPORT;
    private String currentType      = DEF_TYPE;

    // ══════════════════════════════════════════════════════════════
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        DynamicColors.applyToActivityIfAvailable(this);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_v2ray);

        bindViews();
        setupToolbar();
        setupAdapters();
        setupListeners();
        fillData();
    }

    // ══════════════════════════════════════════════════════════════
    //  ربط الـ Views
    // ══════════════════════════════════════════════════════════════
    private void bindViews() {
        toolbar          = findViewById(R.id.toolbar);
        etAddress        = findViewById(R.id.editAddress);
        etPort           = findViewById(R.id.editPort);
        etUUID           = findViewById(R.id.editUUID);
        etAlterId        = findViewById(R.id.editAlterId);
        etHost           = findViewById(R.id.editHost);
        etPath           = findViewById(R.id.editPath);
        etSni            = findViewById(R.id.editSni);
        spinnerEncrypt   = findViewById(R.id.spinnerEncrypt);
        spinnerTransport = findViewById(R.id.spinnerTransport);
        spinnerType      = findViewById(R.id.spinnerType);
        spinnerTls       = findViewById(R.id.spinnerTls);
        layHost          = findViewById(R.id.lay_host);
        layPath          = findViewById(R.id.lay_path);
        laySni           = findViewById(R.id.lay_sni);
        switchMux        = findViewById(R.id.switch_mux);
    }

    // ══════════════════════════════════════════════════════════════
    //  إعداد الـ Toolbar
    // ══════════════════════════════════════════════════════════════
    private void setupToolbar() {
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayShowTitleEnabled(false);
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }
        toolbar.setNavigationOnClickListener(v -> finish());
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_generator, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.action_save) {
            if (!validate()) return true;
            try {
                String payload = buildJson();
                // ═══════════════════════════════════════════════════════
                //  FIX #4: كان يُرسل "v2ray_data" — تم توثيقه بوضوح.
                //  NetworkActivity.generatorLauncher يقرأ "v2ray_data"
                //  عندما lastLaunchedGeneratorType == GEN_V2RAY.
                // ═══════════════════════════════════════════════════════
                Intent result = new Intent();
                result.putExtra("v2ray_data", payload);
                result.putExtra("is_edit", isEdit);
                setResult(RESULT_OK, result);
                finish();
            } catch (Exception e) {
                Log.e(TAG, "Save error: " + e.getMessage(), e);
                toast("Error: " + e.getMessage());
            }
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    // ══════════════════════════════════════════════════════════════
    //  إعداد الـ Adapters
    // ══════════════════════════════════════════════════════════════
    private void setupAdapters() {
        spinnerEncrypt.setAdapter(adapter(ENCRYPT_OPTIONS));
        spinnerTransport.setAdapter(adapter(TRANSPORT_OPTIONS));
        spinnerType.setAdapter(adapter(TYPE_OPTIONS));
        spinnerTls.setAdapter(adapter(TLS_OPTIONS));

        spinnerEncrypt.setText(DEF_ENCRYPT,     false);
        spinnerTransport.setText(DEF_TRANSPORT, false);
        spinnerType.setText(DEF_TYPE,           false);
        spinnerTls.setText(DEF_TLS,             false);
    }

    private ArrayAdapter<String> adapter(String[] options) {
        return new ArrayAdapter<>(this, R.layout.item, options);
    }

    // ══════════════════════════════════════════════════════════════
    //  إعداد الـ Listeners
    // ══════════════════════════════════════════════════════════════
    private void setupListeners() {
        spinnerTransport.setOnItemClickListener((parent, v, i, l) -> {
            currentTransport = parent.getItemAtPosition(i).toString();
            updateTypeOptions(currentTransport);
            // ═══════════════════════════════════════════════════════
            //  FIX #5: كان toggleTransportFields يُخفي/يُظهر layHost/layPath
            //  بشكل مستقل عن toggleTypeFields، مما يُسبّب تعارضاً:
            //  مثلاً transport=ws يُظهرهما، ثم type=none يُخفيهما فوراً.
            //  الحل: دالة موحّدة toggleHostPath() تأخذ الحالتين معاً.
            // ═══════════════════════════════════════════════════════
            toggleHostPath();
        });

        spinnerType.setOnItemClickListener((parent, v, i, l) -> {
            currentType = parent.getItemAtPosition(i).toString();
            toggleHostPath();
        });

        spinnerTls.setOnItemClickListener((parent, v, i, l) ->
                toggleTlsFields(parent.getItemAtPosition(i).toString()));
    }

    // ══════════════════════════════════════════════════════════════
    //  تحديث خيارات Type حسب Transport
    // ══════════════════════════════════════════════════════════════
    private void updateTypeOptions(String transport) {
        // ws لا يدعم type=http (يستخدم path و host بشكل مختلف)
        String[] types = transport.equalsIgnoreCase("ws") ? TYPE_WS_OPTIONS : TYPE_OPTIONS;
        spinnerType.setAdapter(adapter(types));
        currentType = types[0];
        spinnerType.setText(currentType, false);
    }

    // ══════════════════════════════════════════════════════════════
    //  FIX #5: دالة موحّدة لإظهار/إخفاء Host & Path
    //
    //  القاعدة:
    //  ┌───────────────┬──────────┬───────────────────────────────┐
    //  │  transport    │  type    │  layHost & layPath مرئيان؟   │
    //  ├───────────────┼──────────┼───────────────────────────────┤
    //  │  ws           │  أي قيمة │  ✅ نعم (ws يحتاج host/path) │
    //  │  grpc         │  أي قيمة │  ✅ نعم (grpc يحتاج path)   │
    //  │  tcp          │  http    │  ✅ نعم (http camouflage)    │
    //  │  tcp          │  none    │  ❌ لا                       │
    //  └───────────────┴──────────┴───────────────────────────────┘
    // ══════════════════════════════════════════════════════════════
    private void toggleHostPath() {
        boolean isWs   = currentTransport.equalsIgnoreCase("ws");
        boolean isGrpc = currentTransport.equalsIgnoreCase("grpc");
        boolean isHttp = currentType.equalsIgnoreCase("http");

        boolean show = isWs || isGrpc || isHttp;
        setLayoutVisible(layHost, show);
        setLayoutVisible(layPath, show);
    }

    private void toggleTlsFields(String tls) {
        boolean show = tls.equalsIgnoreCase("tls");
        setLayoutVisible(laySni, show);
    }

    /** إظهار أو إخفاء TextInputLayout مع animation خفيف. */
    private void setLayoutVisible(TextInputLayout layout, boolean show) {
        if (layout == null) return;
        layout.animate().alpha(show ? 1f : 0f).setDuration(200).start();
        layout.setVisibility(show ? View.VISIBLE : View.GONE);
    }

    // ══════════════════════════════════════════════════════════════
    //  تعبئة البيانات من Intent
    // ══════════════════════════════════════════════════════════════
    @SuppressLint("SetTextI18n")
    private void fillData() {
        Intent intent = getIntent();
        isEdit = intent.getBooleanExtra("is_edit", false);

        CollapsingToolbarLayout ctl = (CollapsingToolbarLayout) toolbar.getParent();

        if (isEdit) {
            if (ctl != null) ctl.setTitle("Edit V2RAY");
            // ═══════════════════════════════════════════════════════
            //  FIX #6: NetworkActivity يُمرّر "v2ray_json" عند التعديل.
            //  كان الكود لا يُميّز بين وضع الإضافة والتعديل بشكل صحيح.
            // ═══════════════════════════════════════════════════════
            String jsonStr = intent.getStringExtra("v2ray_json");
            if (jsonStr != null && !jsonStr.isEmpty()) {
                try {
                    JSONObject json = new JSONObject(jsonStr);
                    etAddress.setText(json.optString("address", ""));
                    etPort.setText(String.valueOf(json.optInt("port", 0)));
                    etUUID.setText(json.optString("uuid", ""));
                    etAlterId.setText(String.valueOf(json.optInt("alterId", 0)));
                    etHost.setText(json.optString("host", ""));
                    etPath.setText(json.optString("path", ""));
                    etSni.setText(json.optString("sni", ""));
                    switchMux.setChecked(json.optBoolean("mux", true));

                    currentTransport = json.optString("transport", DEF_TRANSPORT);
                    currentType      = json.optString("type",      DEF_TYPE);
                    String tls       = json.optString("tls",       DEF_TLS);

                    spinnerEncrypt.setText(json.optString("encryption", DEF_ENCRYPT), false);
                    spinnerTransport.setText(currentTransport, false);
                    spinnerType.setText(currentType,           false);
                    spinnerTls.setText(tls,                    false);

                    toggleHostPath();
                    toggleTlsFields(tls);
                    return;

                } catch (Exception e) {
                    Log.w(TAG, "fillData: invalid JSON, resetting to defaults", e);
                }
            }
        } else {
            if (ctl != null) ctl.setTitle("Add V2RAY");
        }

        resetToDefaults();
    }

    // ══════════════════════════════════════════════════════════════
    //  Reset إلى الافتراضي
    // ══════════════════════════════════════════════════════════════
    @SuppressLint("SetTextI18n")
    private void resetToDefaults() {
        etAddress.setText("");  etPort.setText("");
        etUUID.setText("");     etAlterId.setText("0");
        etHost.setText("");     etPath.setText("");    etSni.setText("");

        currentTransport = DEF_TRANSPORT;
        currentType      = DEF_TYPE;

        spinnerEncrypt.setText(DEF_ENCRYPT,     false);
        spinnerTransport.setText(DEF_TRANSPORT, false);
        spinnerType.setText(DEF_TYPE,           false);
        spinnerTls.setText(DEF_TLS,             false);

        switchMux.setChecked(true);
        toggleHostPath();
        toggleTlsFields(DEF_TLS);
    }

    // ══════════════════════════════════════════════════════════════
    //  التحقق من المدخلات
    // ══════════════════════════════════════════════════════════════
    private boolean validate() {
        if (getText(etAddress).isEmpty()) {
            etAddress.setError("Required"); etAddress.requestFocus(); return false;
        }
        String portStr = getText(etPort);
        if (portStr.isEmpty()) {
            etPort.setError("Required"); etPort.requestFocus(); return false;
        }
        try {
            int port = Integer.parseInt(portStr);
            if (port < 1 || port > 65535) {
                etPort.setError("Invalid port (1-65535)"); etPort.requestFocus(); return false;
            }
        } catch (NumberFormatException e) {
            etPort.setError("Numbers only"); etPort.requestFocus(); return false;
        }
        if (getText(etUUID).isEmpty()) {
            etUUID.setError("Required"); etUUID.requestFocus(); return false;
        }
        return true;
    }

    // ══════════════════════════════════════════════════════════════
    //  بناء JSON — البايلود المُرسَل لـ NetworkActivity
    // ══════════════════════════════════════════════════════════════
    private String buildJson() throws JSONException {
        String transport = getText(spinnerTransport);
        String tls       = getText(spinnerTls);
        String type      = getText(spinnerType);

        // Host و Path يُضمَّنان عند ws أو grpc أو type=http
        boolean includeHostPath = transport.equalsIgnoreCase("ws")
                || transport.equalsIgnoreCase("grpc")
                || type.equalsIgnoreCase("http");

        JSONObject obj = new JSONObject();
        obj.put("address",    getText(etAddress));
        obj.put("port",       parseIntSafe(getText(etPort)));
        obj.put("uuid",       getText(etUUID));
        obj.put("alterId",    parseIntSafe(getText(etAlterId)));
        obj.put("encryption", transport.isEmpty() ? DEF_ENCRYPT    : getText(spinnerEncrypt));
        obj.put("transport",  transport.isEmpty() ? DEF_TRANSPORT  : transport);
        obj.put("type",       type.isEmpty()      ? DEF_TYPE       : type);
        obj.put("host",       includeHostPath ? getText(etHost) : "");
        obj.put("path",       includeHostPath ? getText(etPath) : "");
        obj.put("tls",        tls.isEmpty()       ? DEF_TLS        : tls);
        obj.put("sni",        !tls.equalsIgnoreCase(DEF_TLS) ? getText(etSni) : "");
        obj.put("mux",        switchMux.isChecked());
        // MISMATCH-FIX-4: Removed "socks5" field — V2Utilities.buildFullV2RayConfig()
        // always injects SOCKS5 inbound on the VPN app side (port 10808).
        // Having a separate "socks5" field here is unused and misleading.

        return obj.toString(2);
    }

    // ══════════════════════════════════════════════════════════════
    //  Helpers
    // ══════════════════════════════════════════════════════════════
    private String getText(TextView view) {
        return (view != null && view.getText() != null)
                ? view.getText().toString().trim() : "";
    }

    private int parseIntSafe(String val) {
        try { return Integer.parseInt(val); } catch (NumberFormatException e) { return 0; }
    }

    private void toast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }
}