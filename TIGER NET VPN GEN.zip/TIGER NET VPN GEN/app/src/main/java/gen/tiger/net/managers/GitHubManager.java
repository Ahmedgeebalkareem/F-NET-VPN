package gen.tiger.net.managers;

import android.os.Handler;
import android.os.Looper;
import android.util.Base64;
import android.util.Log;

import androidx.annotation.NonNull;

import org.json.JSONObject;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.TimeUnit;

import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import okhttp3.ResponseBody;

/**
 * ══════════════════════════════════════════════════════════════
 *  GitHubManager — مدير عمليات GitHub API
 * ══════════════════════════════════════════════════════════════
 *
 *  يتولى هذا الكلاس:
 *  • رفع ملف Config إلى GitHub (Upload)
 *  • تنزيل ملف Config من GitHub (Download)
 *  • ترجمة أكواد HTTP إلى رسائل واضحة للمستخدم
 *  • إدارة OkHttpClient بشكل صحيح (Singleton + إغلاق الـ Response)
 *  • تسليم النتائج والأخطاء على الـ Main Thread
 *
 *  المشاكل التي يحلّها:
 *  ─────────────────────────────────────────────────────────────
 *  1. Response body لم تكن تُغلق → تسريب ذاكرة (Memory Leak)
 *  2. OkHttpClient جديد في كل طلب → استهلاك زائد للذاكرة
 *  3. رسائل الخطأ غامضة ("Upload failed" فقط)
 *  4. HTTP 401 / 403 / 404 / 429 لم تكن تُفسَّر
 *  5. لا يوجد Timeout محدد → قد ينتظر إلى الأبد
 *  6. الـ Token يُقرأ من كل مكان بدون مركزية
 *  7. استخدام new Thread() بدلاً من ExecutorService منظّم
 */
public final class GitHubManager {

    private static final String TAG = "GitHubManager";

    // ── GitHub API Settings ───────────────────────────────────────
    private static final String GITHUB_API_BASE =
            "https://api.github.com/repos/Ahmedgeebalkareem/TIGER-NET-VPN/contents/ConfigUpdate";
    private static final String ACCEPT_HEADER   = "application/vnd.github.v3+json";
    private static final MediaType JSON_MEDIA    =
            MediaType.parse("application/json; charset=utf-8");

    // ── HTTP Timeouts ─────────────────────────────────────────────
    private static final int CONNECT_TIMEOUT_SEC = 15;
    private static final int READ_TIMEOUT_SEC    = 30;
    private static final int WRITE_TIMEOUT_SEC   = 30;

    // ── Singleton OkHttpClient ────────────────────────────────────
    private static volatile OkHttpClient sClient;

    private static OkHttpClient getClient() {
        if (sClient == null) {
            synchronized (GitHubManager.class) {
                if (sClient == null) {
                    sClient = new OkHttpClient.Builder()
                            .connectTimeout(CONNECT_TIMEOUT_SEC, TimeUnit.SECONDS)
                            .readTimeout(READ_TIMEOUT_SEC,    TimeUnit.SECONDS)
                            .writeTimeout(WRITE_TIMEOUT_SEC,  TimeUnit.SECONDS)
                            .build();
                }
            }
        }
        return sClient;
    }

    // ── Main Thread Handler ───────────────────────────────────────
    private static final Handler MAIN = new Handler(Looper.getMainLooper());

    // No instances
    private GitHubManager() {}

    // ══════════════════════════════════════════════════════════════
    //  Callback Interface
    // ══════════════════════════════════════════════════════════════

    public interface Callback {
        /** نجاح العملية — يُستدعى على الـ Main Thread */
        void onSuccess(@NonNull String message);

        /** فشل العملية — يُستدعى على الـ Main Thread */
        void onError(@NonNull String errorMessage);
    }

    public interface DownloadCallback {
        /** نجاح التنزيل — يُعيد المحتوى المُشفَّر — Main Thread */
        void onSuccess(@NonNull String encryptedContent);

        /** فشل التنزيل — Main Thread */
        void onError(@NonNull String errorMessage);
    }

    // ══════════════════════════════════════════════════════════════
    //  Upload — رفع ملف Config إلى GitHub
    // ══════════════════════════════════════════════════════════════

    /**
     * يرفع {@code encryptedJson} إلى GitHub في خيط منفصل.
     * يُبلّغ النتيجة عبر {@code callback} على الـ Main Thread.
     *
     * @param encryptedJson المحتوى المُشفَّر الجاهز للرفع
     * @param token         GitHub Personal Access Token
     * @param callback      مستقبِل النتيجة
     */
    public static void upload(
            @NonNull String   encryptedJson,
            @NonNull String   token,
            @NonNull Callback callback) {

        new Thread(() -> {
            try {
                performUpload(encryptedJson, token, callback);
            } catch (Exception e) {
                Log.e(TAG, "upload: خطأ غير متوقع", e);
                postError(callback, "خطأ غير متوقع: " + e.getMessage());
            }
        }, "github-upload").start();
    }

    private static void performUpload(
            String encryptedJson,
            String token,
            Callback callback) throws Exception {

        // ── الخطوة 1: جلب الـ SHA الحالي للملف ──────────────────
        String sha = fetchFileSha(token, callback);
        if (sha == null) return; // الخطأ أُرسل بالفعل من fetchFileSha

        // ── الخطوة 2: تحويل المحتوى إلى Base64 ──────────────────
        String base64Content = Base64.encodeToString(
                encryptedJson.getBytes(StandardCharsets.UTF_8),
                Base64.NO_WRAP);

        // ── الخطوة 3: بناء جسم الطلب ─────────────────────────────
        JSONObject body = new JSONObject();
        body.put("message", "Update Config — TIGER NET VPN GEN");
        body.put("content", base64Content);
        body.put("branch",  "main");
        body.put("sha",     sha);

        // ── الخطوة 4: إرسال طلب الرفع ────────────────────────────
        Request uploadRequest = new Request.Builder()
                .url(GITHUB_API_BASE)
                .header("Authorization", "token " + token)
                .header("Accept",        ACCEPT_HEADER)
                .put(RequestBody.create(body.toString(), JSON_MEDIA))
                .build();

        // try-with-resources يضمن إغلاق الـ Response تلقائياً
        try (Response response = getClient().newCall(uploadRequest).execute()) {
            if (response.isSuccessful()) {
                postSuccess(callback, "✅ تم رفع الإعدادات إلى GitHub بنجاح.");
            } else {
                postError(callback, buildHttpError("رفع الملف", response));
            }
        }
    }

    /**
     * يجلب الـ SHA الحالي للملف — مطلوب لتحديث الملف في GitHub.
     * يُعيد {@code null} إذا فشل ويُرسل الخطأ عبر callback.
     */
    private static String fetchFileSha(String token, Callback callback) {
        Request shaRequest = new Request.Builder()
                .url(GITHUB_API_BASE)
                .header("Authorization", "token " + token)
                .header("Accept",        ACCEPT_HEADER)
                .build();

        try (Response response = getClient().newCall(shaRequest).execute()) {
            if (!response.isSuccessful()) {
                postError(callback, buildHttpError("جلب SHA", response));
                return null;
            }

            ResponseBody body = response.body();
            if (body == null) {
                postError(callback, "❌ الاستجابة فارغة عند جلب SHA.");
                return null;
            }

            JSONObject json = new JSONObject(body.string());

            if (!json.has("sha")) {
                postError(callback, "❌ لم يُعثر على SHA في استجابة GitHub.");
                return null;
            }

            return json.getString("sha");

        } catch (IOException e) {
            Log.e(TAG, "fetchFileSha: فشل الاتصال", e);
            postError(callback, "❌ فشل الاتصال بـ GitHub: " + e.getMessage());
            return null;
        } catch (Exception e) {
            Log.e(TAG, "fetchFileSha: خطأ في تحليل الاستجابة", e);
            postError(callback, "❌ خطأ في قراءة استجابة GitHub.");
            return null;
        }
    }

    // ══════════════════════════════════════════════════════════════
    //  Download — تنزيل ملف Config من GitHub
    // ══════════════════════════════════════════════════════════════

    /**
     * يُنزّل ملف Config من GitHub ويُعيد المحتوى المُشفَّر.
     * يُبلّغ النتيجة عبر {@code callback} على الـ Main Thread.
     *
     * @param url      رابط الملف (يُستخدم GITHUB_API_BASE إذا كان null)
     * @param token    GitHub Personal Access Token
     * @param callback مستقبِل النتيجة
     */
    public static void download(
            String           url,
            @NonNull String  token,
            @NonNull DownloadCallback callback) {

        // إذا لم يُمرَّر URL، استخدم الرابط الافتراضي
        final String targetUrl = (url == null || url.isEmpty())
                ? GITHUB_API_BASE
                : url;

        new Thread(() -> {
            try {
                performDownload(targetUrl, token, callback);
            } catch (Exception e) {
                Log.e(TAG, "download: خطأ غير متوقع", e);
                postDownloadError(callback, "خطأ غير متوقع: " + e.getMessage());
            }
        }, "github-download").start();
    }

    private static void performDownload(
            String           url,
            String           token,
            DownloadCallback callback) {

        Request request = new Request.Builder()
                .url(url)
                .header("Authorization", "token " + token)
                .header("Accept",        ACCEPT_HEADER)
                .build();

        try (Response response = getClient().newCall(request).execute()) {
            if (!response.isSuccessful()) {
                postDownloadError(callback, buildHttpError("تنزيل الملف", response));
                return;
            }

            ResponseBody body = response.body();
            if (body == null) {
                postDownloadError(callback, "❌ الاستجابة فارغة من GitHub.");
                return;
            }

            String rawBody = body.string();

            // ── تحليل استجابة GitHub API ──────────────────────────
            JSONObject json = new JSONObject(rawBody);

            if (!json.has("content")) {
                postDownloadError(callback,
                        "❌ لم يُعثر على محتوى في ملف GitHub.\n" +
                        "تأكد أن المستودع يحتوي على ملف ConfigUpdate.");
                return;
            }

            // GitHub يُعيد المحتوى كـ Base64 مع مسافات بيضاء — نزيلها
            String base64Content = json.getString("content").replaceAll("\\s", "");

            if (base64Content.isEmpty()) {
                postDownloadError(callback, "❌ الملف على GitHub فارغ.");
                return;
            }

            // فك تشفير Base64 → النص المُشفَّر الأصلي
            byte[] decodedBytes  = Base64.decode(base64Content, Base64.DEFAULT);
            String encryptedJson = new String(decodedBytes, StandardCharsets.UTF_8);

            postDownloadSuccess(callback, encryptedJson);

        } catch (IOException e) {
            Log.e(TAG, "performDownload: فشل الاتصال", e);
            postDownloadError(callback, buildNetworkError(e));
        } catch (Exception e) {
            Log.e(TAG, "performDownload: خطأ في التحليل", e);
            postDownloadError(callback, "❌ خطأ في قراءة محتوى GitHub: " + e.getMessage());
        }
    }

    // ══════════════════════════════════════════════════════════════
    //  ترجمة أكواد HTTP إلى رسائل واضحة
    // ══════════════════════════════════════════════════════════════

    /**
     * يُحوّل كود HTTP إلى رسالة خطأ مفهومة للمستخدم.
     *
     * <p>بدلاً من "HTTP 401: Unauthorized" المُبهمة، يُعطي
     * رسالة توضح السبب والحل.</p>
     */
    @NonNull
    private static String buildHttpError(String operation, Response response) {
        int    code    = response.code();
        String message = resolveHttpCode(code);

        // قراءة جسم الخطأ إن وُجد (للـ Logging فقط، لا للمستخدم)
        String bodyHint = "";
        try {
            ResponseBody errorBody = response.body();
            if (errorBody != null) {
                JSONObject errorJson = new JSONObject(errorBody.string());
                if (errorJson.has("message")) {
                    bodyHint = errorJson.getString("message");
                    Log.e(TAG, operation + " — GitHub قال: " + bodyHint);
                }
            }
        } catch (Exception ignored) {}

        return String.format("❌ فشلت عملية \"%s\"\n%s", operation, message);
    }

    @NonNull
    private static String resolveHttpCode(int code) {
        switch (code) {
            case 401:
                return "كود 401 — التوكن غير صالح أو منتهي الصلاحية.\n" +
                       "تحقق من ملف github.properties.";
            case 403:
                return "كود 403 — صلاحيات التوكن غير كافية.\n" +
                       "تأكد أن التوكن يملك صلاحية 'repo'.";
            case 404:
                return "كود 404 — الملف أو المستودع غير موجود.\n" +
                       "تأكد من اسم المستودع ومسار الملف.";
            case 409:
                return "كود 409 — تعارض في الملف (Conflict).\n" +
                       "حاول مرة أخرى.";
            case 422:
                return "كود 422 — بيانات الطلب غير صحيحة.\n" +
                       "تأكد من صحة الـ SHA.";
            case 429:
                return "كود 429 — تجاوزت حد الطلبات (Rate Limit).\n" +
                       "انتظر دقيقة وحاول مجدداً.";
            case 500:
            case 502:
            case 503:
                return "كود " + code + " — خطأ في خوادم GitHub.\n" +
                       "حاول مجدداً بعد قليل.";
            default:
                return "كود HTTP " + code + " — فشل غير متوقع.";
        }
    }

    @NonNull
    private static String buildNetworkError(IOException e) {
        String msg = e.getMessage();
        if (msg == null) return "❌ فشل الاتصال بالإنترنت.";
        if (msg.contains("timeout") || msg.contains("timed out"))
            return "❌ انتهت مهلة الاتصال.\nتحقق من سرعة الإنترنت وحاول مجدداً.";
        if (msg.contains("Unable to resolve host"))
            return "❌ لا يمكن الوصول إلى GitHub.\nتحقق من اتصال الإنترنت.";
        if (msg.contains("SSL") || msg.contains("certificate"))
            return "❌ خطأ في شهادة SSL.\nتحقق من إعدادات التاريخ والوقت.";
        return "❌ فشل الاتصال: " + msg;
    }

    // ══════════════════════════════════════════════════════════════
    //  Post to Main Thread Helpers
    // ══════════════════════════════════════════════════════════════

    private static void postSuccess(Callback cb, String msg) {
        MAIN.post(() -> cb.onSuccess(msg));
    }

    private static void postError(Callback cb, String msg) {
        MAIN.post(() -> cb.onError(msg));
    }

    private static void postDownloadSuccess(DownloadCallback cb, String content) {
        MAIN.post(() -> cb.onSuccess(content));
    }

    private static void postDownloadError(DownloadCallback cb, String msg) {
        MAIN.post(() -> cb.onError(msg));
    }
}
