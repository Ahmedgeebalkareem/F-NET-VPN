package gen.tiger.net.activities;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.materialswitch.MaterialSwitch;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.color.DynamicColors;

import org.json.JSONException;
import org.json.JSONObject;

import gen.tiger.net.R;

public class UDPActivity extends AppCompatActivity {

    private static final String TAG = "UDPActivity";

    // ── Defaults ───────────────────────────────────────────────────
    private static final String DEF_UP_MBPS   = "1";
    private static final String DEF_DOWN_MBPS = "2";
    private static final String DEF_RW_CONN   = "196608";
    private static final String DEF_RW        = "491520";

    // ── Views ──────────────────────────────────────────────────────
    private MaterialToolbar   toolbar;
    private TextInputEditText etServerIP;
    private TextInputEditText etServerObfs;
    private TextInputEditText etServerUpMBPS;
    private TextInputEditText etServerDownMBPS;
    private TextInputEditText etServerRWConn;
    private TextInputEditText etServerRW;
    private TextInputEditText etUsername;
    private TextInputEditText etPassword;
    private MaterialSwitch  checkboxAuto;

    // ── State ──────────────────────────────────────────────────────
    private boolean  isEdit;
    private String[] previousCredentials = {"", ""};

    // ══════════════════════════════════════════════════════════════
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        DynamicColors.applyToActivityIfAvailable(this);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_udp);

        bindViews();
        setupToolbar();
        setupListeners();
        fillData();
    }

    // ══════════════════════════════════════════════════════════════
    //  ربط الـ Views
    // ══════════════════════════════════════════════════════════════
    private void bindViews() {
        toolbar           = findViewById(R.id.toolbar);
        etServerIP        = findViewById(R.id.etServerIP);
        etServerObfs      = findViewById(R.id.etServerObfs);
        etServerUpMBPS    = findViewById(R.id.etServerUpMBPS);
        etServerDownMBPS  = findViewById(R.id.etServerDownMBPS);
        etServerRWConn    = findViewById(R.id.etServerRWConn);
        etServerRW        = findViewById(R.id.etServerRW);
        etUsername        = findViewById(R.id.username_udp);
        etPassword        = findViewById(R.id.password_udp);
        checkboxAuto      = findViewById(R.id.use_auto_udp);
    }

    // ══════════════════════════════════════════════════════════════
    //  إعداد الـ Toolbar
    // ══════════════════════════════════════════════════════════════
    private void setupToolbar() {
        setSupportActionBar(toolbar);
        toolbar.setNavigationOnClickListener(v -> finish());
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_generator, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.action_save) {
            saveAndReturn();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    // ══════════════════════════════════════════════════════════════
    //  إعداد الـ Listeners
    // ══════════════════════════════════════════════════════════════
    private void setupListeners() {
        checkboxAuto.setOnCheckedChangeListener((btn, isChecked) -> {
            if (isChecked) {
                previousCredentials[0] = getText(etUsername);
                previousCredentials[1] = getText(etPassword);
                etUsername.setText("");
                etPassword.setText("");
                etUsername.setEnabled(false);
                etPassword.setEnabled(false);
                etUsername.setAlpha(0.1f);
                etPassword.setAlpha(0.1f);
            } else {
                etUsername.setText(previousCredentials[0]);
                etPassword.setText(previousCredentials[1]);
                etUsername.setEnabled(true);
                etPassword.setEnabled(true);
                etUsername.setAlpha(1f);
                etPassword.setAlpha(1f);
            }
        });
    }

    // ══════════════════════════════════════════════════════════════
    //  تعبئة البيانات من الـ Intent
    // ══════════════════════════════════════════════════════════════
    @SuppressLint("SetTextI18n")
    private void fillData() {
        Intent intent = getIntent();
        isEdit = intent.getBooleanExtra("is_edit", false);

        if (!isEdit) {
            toolbar.setTitle("Add UDP");
            resetToDefaults();
            return;
        }

        toolbar.setTitle("Edit UDP");
        String inputJson = intent.getStringExtra("udp_json");
        if (inputJson == null || inputJson.isEmpty()) {
            resetToDefaults();
            return;
        }

        try {
            JSONObject json = new JSONObject(inputJson);

            etServerIP.setText(extractServerIp(json.optString("server", "")));
            etServerObfs.setText(json.optString("obfs", ""));
            etServerUpMBPS.setText(String.valueOf(json.optInt("up_mbps",   Integer.parseInt(DEF_UP_MBPS))));
            etServerDownMBPS.setText(String.valueOf(json.optInt("down_mbps", Integer.parseInt(DEF_DOWN_MBPS))));
            etServerRWConn.setText(String.valueOf(json.optInt("recv_window_conn", Integer.parseInt(DEF_RW_CONN))));
            etServerRW.setText(String.valueOf(json.optInt("recv_window",  Integer.parseInt(DEF_RW))));
            etUsername.setText(json.optString("username", ""));
            etPassword.setText(json.optString("password", ""));
            checkboxAuto.setChecked(json.optBoolean("use_auto", false));

            boolean autoEnabled = checkboxAuto.isChecked();
            etUsername.setEnabled(!autoEnabled);
            etPassword.setEnabled(!autoEnabled);

            previousCredentials[0] = getText(etUsername);
            previousCredentials[1] = getText(etPassword);

        } catch (JSONException e) {
            Log.e(TAG, "fillData: " + e.getMessage(), e);
            resetToDefaults();
            toast("Invalid JSON format - Using default values");
        }
    }

    // ══════════════════════════════════════════════════════════════
    //  إعادة القيم الافتراضية
    // ══════════════════════════════════════════════════════════════
    @SuppressLint("SetTextI18n")
    private void resetToDefaults() {
        etServerIP.setText("");
        etServerObfs.setText("");
        etServerUpMBPS.setText(DEF_UP_MBPS);
        etServerDownMBPS.setText(DEF_DOWN_MBPS);
        etServerRWConn.setText(DEF_RW_CONN);
        etServerRW.setText(DEF_RW);
        etUsername.setText("");
        etPassword.setText("");
        checkboxAuto.setChecked(false);
        etUsername.setEnabled(true);
        etPassword.setEnabled(true);
    }

    // ══════════════════════════════════════════════════════════════
    //  التحقق من صحة المدخلات
    // ══════════════════════════════════════════════════════════════
    private boolean validate() {
        if (getText(etServerIP).isEmpty()) {
            etServerIP.setError("Required");
            etServerIP.requestFocus();
            return false;
        }
        if (getText(etServerObfs).isEmpty()) {
            etServerObfs.setError("Required");
            etServerObfs.requestFocus();
            return false;
        }
        return true;
    }

    // ══════════════════════════════════════════════════════════════
    //  حفظ وإرجاع
    // ══════════════════════════════════════════════════════════════
    private void saveAndReturn() {
        if (!validate()) return;

        String payload = buildJson(
                getText(etServerIP),
                getText(etServerObfs),
                getText(etServerUpMBPS),
                getText(etServerDownMBPS),
                getText(etServerRWConn),
                getText(etServerRW),
                getText(etUsername),
                getText(etPassword),
                checkboxAuto.isChecked()
        );

        Intent result = new Intent();
        result.putExtra("udp_data", payload);
        result.putExtra("is_edit",  isEdit);
        setResult(RESULT_OK, result);
        finish();
    }

    // ══════════════════════════════════════════════════════════════
    //  بناء الـ JSON
    // ══════════════════════════════════════════════════════════════
    private String buildJson(String ip, String obfs, String upMbps, String downMbps,
                             String rwConn, String rw, String username, String password,
                             boolean useAuto) {
        try {
            JSONObject obj = new JSONObject();
            obj.put("server",           ip + ":20000-50000");
            obj.put("obfs",             obfs);
            obj.put("auth_str",         "auth_xxx");
            obj.put("up_mbps",          upMbps.isEmpty()   ? 1      : Integer.parseInt(upMbps));
            obj.put("down_mbps",        downMbps.isEmpty() ? 2      : Integer.parseInt(downMbps));
            obj.put("retry",            3);
            obj.put("retry_interval",   1);
            obj.put("insecure",         true);
            obj.put("ca",               "");
            obj.put("recv_window_conn", rwConn.isEmpty()   ? 196608 : Integer.parseInt(rwConn));
            obj.put("recv_window",      rw.isEmpty()       ? 491520 : Integer.parseInt(rw));
            obj.put("use_auto",         useAuto);
            obj.put("username",         username);
            obj.put("password",         password);

            JSONObject socks5 = new JSONObject();
            socks5.put("listen", "127.0.0.1:1080");
            obj.put("socks5", socks5);

            JSONObject http = new JSONObject();
            http.put("listen", "127.0.0.1:8989");
            obj.put("http", http);

            return obj.toString(2);
        } catch (JSONException e) {
            Log.e(TAG, "buildJson: " + e.getMessage(), e);
            return "{}";
        }
    }

    // ══════════════════════════════════════════════════════════════
    //  Helpers
    // ══════════════════════════════════════════════════════════════
    private String extractServerIp(String serverField) {
        if (serverField == null || serverField.isEmpty()) return "";
        String[] parts = serverField.split(":");
        return parts.length > 0 ? parts[0] : "";
    }

    private String getText(android.widget.TextView view) {
        return (view != null && view.getText() != null)
                ? view.getText().toString().trim() : "";
    }

    private void toast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }
}