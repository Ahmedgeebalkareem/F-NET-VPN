package gen.tiger.net.adapters;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.net.Uri;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.google.android.material.textview.MaterialTextView;
import com.bumptech.glide.Glide;

import gen.tiger.net.R;

import java.io.InputStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class FlagAdapter extends ArrayAdapter<String> {

    private static final String FLAG_DIR = "flag/";

    private final List<String>          items;
    private final LayoutInflater        inflater;
    private final Map<String, Drawable> flagCache = new HashMap<>();

    // ── Constructor ────────────────────────────────────────────────
    public FlagAdapter(@NonNull Context context, @NonNull List<String> items) {
        super(context, R.layout.flag_item, items);
        this.items    = items;
        this.inflater = LayoutInflater.from(context);
    }

    // ── ViewHolder ─────────────────────────────────────────────────
    private static class ViewHolder {
        MaterialTextView textView;
        ImageView        imageView;
        View             divider;
    }

    // ── getView ────────────────────────────────────────────────────
    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        return createItemView(position, convertView, parent);
    }

    // ── getDropDownView ────────────────────────────────────────────
    @Override
    public View getDropDownView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        return createItemView(position, convertView, parent);
    }

    // ── createItemView ─────────────────────────────────────────────
    private View createItemView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        ViewHolder holder;

        if (convertView == null) {
            convertView      = inflater.inflate(R.layout.flag_item, parent, false);
            holder           = new ViewHolder();
            holder.textView  = convertView.findViewById(R.id.item_text);
            holder.imageView = convertView.findViewById(R.id.item_icon);
            holder.divider   = convertView.findViewById(R.id.divider);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }

        String fileName    = items.get(position);
        String displayName = toDisplayName(fileName);

        holder.textView.setText(displayName);
        Glide.with(getContext())
        .load(Uri.parse("file:///android_asset/flag/" + fileName))
        .placeholder(R.drawable.ic_launcher)  // صورة مؤقتة أثناء التحميل
        .into(holder.imageView);
        
        holder.divider.setVisibility(position == getCount() - 1 ? View.GONE : View.VISIBLE);

        return convertView;
    }

    // ── toDisplayName ──────────────────────────────────────────────
    private String toDisplayName(@NonNull String fileName) {
        return fileName.replace(".png", "")
                       .replace("_", " ")
                       .toUpperCase();
    }
}