package gen.tiger.net.managers;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.preference.PreferenceManager;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.android.material.textfield.MaterialAutoCompleteTextView;
import com.google.android.material.textview.MaterialTextView;

import gen.tiger.net.R;
import gen.tiger.net.activities.ServerActivity;
import gen.tiger.net.models.Config;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.List;

/**
 * ServerManager — مدير عمليات السيرفرات مسؤول عن: إضافة / تعديل / حذف / عرض السيرفرات معزول تماماً
 * عن MainActivity
 */
public class ServerManager {

    private static final String TAG = "ServerManager";

    // ── Dependencies ───────────────────────────────────────────────
    private final AppCompatActivity activity;
    private final Context context;
    private final Config json;
    private final SharedPreferences prefs;
    private final SharedPreferences.Editor editor;

    // ── UI المرتبطة بالسيرفر في MainActivity ──────────────────────
    private final MaterialAutoCompleteTextView serverDropdown;
    private final List<String> serverList;

    // ── Callback للإشعار بالتغييرات ───────────────────────────────
    private final OnServerChangedListener listener;

    // ── Launcher للصفحة ───────────────────────────────────────────
    private ActivityResultLauncher<Intent> serverLauncher;

    // ── حفظ السيرفر الحالي عند التعديل ───────────────────────────
    private int pendingEditPosition = -1;
    // ── حفظ آخر عنصر محذوف لدعم Undo ────────────────────────────
    private JSONObject lastDeletedItem = null;
    private int lastDeletedPosition = -1;

    // ══════════════════════════════════════════════════════════════
    //  Interface — Callback
    // ══════════════════════════════════════════════════════════════
    public interface OnServerChangedListener {
        void onServerAdded(String serverName);

        void onServerEdited(String serverName);

        void onServerDeleted(String name, Runnable undoAction);

        void refreshDropdown();
    }

    // ══════════════════════════════════════════════════════════════
    //  Constructor
    // ══════════════════════════════════════════════════════════════
    public ServerManager(
            AppCompatActivity activity,
            MaterialAutoCompleteTextView serverDropdown,
            List<String> serverList,
            OnServerChangedListener listener) {

        this.activity = activity;
        this.context = activity.getApplicationContext();
        this.json = Config.getInstance(activity);
        this.prefs = PreferenceManager.getDefaultSharedPreferences(activity);
        this.editor = prefs.edit();
        this.serverDropdown = serverDropdown;
        this.serverList = serverList;
        this.listener = listener;

        registerLauncher();
    }

    // ══════════════════════════════════════════════════════════════
    //  تسجيل Launcher — يجب استدعاؤه قبل onStart()
    // ══════════════════════════════════════════════════════════════
    private void registerLauncher() {
        serverLauncher =
                activity.registerForActivityResult(
                        new ActivityResultContracts.StartActivityForResult(),
                        result -> {
                            if (result.getResultCode() == AppCompatActivity.RESULT_OK
                                    && result.getData() != null) {
                                handleServerResult(result.getData());
                            }
                        });
    }

    // ══════════════════════════════════════════════════════════════
    //  معالجة النتيجة القادمة من ServerActivity
    // ══════════════════════════════════════════════════════════════
    private void handleServerResult(Intent data) {
        try {
            String jsonStr = data.getStringExtra("server_data");
            boolean isEdit = data.getBooleanExtra("is_edit", false);

            if (jsonStr == null) {
                Log.e(TAG, "Server data is null");
                return;
            }
            JSONObject jsObj = new JSONObject(jsonStr);
            String name = jsObj.optString("Name", "");

            // حفظ في prefs
            saveToPrefs(jsObj);

            if (isEdit && pendingEditPosition >= 0) {
                // تعديل — احذف القديم وأضف الجديد
                if (pendingEditPosition < json.getServerArray().length()) {
                    json.getServerArray().remove(pendingEditPosition);
                }
                pendingEditPosition = -1;
                json.addServer(jsObj);
                listener.onServerEdited(name);
            } else {
                // إضافة جديد
                json.addServer(jsObj);
                listener.onServerAdded(name);
            }

            listener.refreshDropdown();
            serverDropdown.setText(name, false);

        } catch (JSONException e) {
            Log.e(TAG, "handleServerResult: " + e.getMessage(), e);
            toast("Error saving server: " + e.getMessage());
        }
    }

    // ══════════════════════════════════════════════════════════════
    //  إضافة سيرفر جديد
    // ══════════════════════════════════════════════════════════════
    public void addServer() {
        pendingEditPosition = -1;

        Intent intent = new Intent(activity, ServerActivity.class);
        intent.putExtra("is_edit", false);
        intent.putExtra("default_ssh", prefs.getString("ssh_port", "22"));
        intent.putExtra("default_tcp", prefs.getString("tcp_port", "1194"));
        intent.putExtra("default_ssl", prefs.getString("ssl_port", "443"));
        intent.putExtra("default_auto", prefs.getBoolean("auto", false));
        intent.putExtra("default_username", prefs.getString("username", ""));
        intent.putExtra("default_password", prefs.getString("password", ""));

        serverLauncher.launch(intent);
    }

    // ══════════════════════════════════════════════════════════════
    //  تعديل سيرفر موجود
    // ══════════════════════════════════════════════════════════════
    public void editServer() {
        int position = getSelectedPosition();
        if (position == -1) {
            toast("Please select a server first");
            return;
        }

        try {
            JSONObject server = json.getServerArray().getJSONObject(position);
            pendingEditPosition = position;

            Intent intent = new Intent(activity, ServerActivity.class);
            intent.putExtra("is_edit", true);
            intent.putExtra("server_json", server.toString());

            serverLauncher.launch(intent);

        } catch (JSONException e) {
            Log.e(TAG, "editServer: " + e.getMessage(), e);
            toast("Error loading server data");
        }
    }

    // ══════════════════════════════════════════════════════════════
    //  حذف سيرفر
    // ══════════════════════════════════════════════════════════════
    public void deleteServer() {
        int position = getSelectedPosition();
        if (position == -1) {
            toast("Please select a server first");
            return;
        }

        String selectedName = serverDropdown.getText().toString();

        new MaterialAlertDialogBuilder(activity)
                .setTitle("Delete Server")
                .setMessage("Are you sure you want to delete this Server?")
                .setPositiveButton(
                        "Delete",
                        (dialog, which) -> {
                            if (position < json.getServerArray().length()) {
                                try {
                                    lastDeletedItem =
                                            new JSONObject(
                                                    json.getServerArray()
                                                            .getJSONObject(position)
                                                            .toString());
                                } catch (JSONException ignored) {
                                    lastDeletedItem = null;
                                }
                                lastDeletedPosition = position;
                                json.getServerArray().remove(position);
                                Runnable undoAction =
                                        () -> {
                                            if (lastDeletedItem != null) undoDelete();
                                        };
                                listener.onServerDeleted(selectedName, undoAction);
                                listener.refreshDropdown();
                                int newSize = json.getServerArray().length();
                                if (newSize > 0) {
                                    int newPos = Math.max(0, position - 1);
                                    try {
                                        String prevName =
                                                json.getServerArray()
                                                        .getJSONObject(newPos)
                                                        .optString("Name", "");
                                        serverDropdown.setText(prevName, false);
                                    } catch (JSONException e) {
                                        serverDropdown.setText("", false);
                                    }
                                } else {
                                    serverDropdown.setText("", false);
                                }
                            }
                        })
                .setNegativeButton("Cancel", null)
                .show();
    }

    // ══════════════════════════════════════════════════════════════
    //  Undo آخر حذف
    // ══════════════════════════════════════════════════════════════
    public void undoDelete() {
        if (lastDeletedItem == null) return;
        try {
            // أعد الإدراج في نفس الموضع القديم
            if (lastDeletedPosition >= 0 && lastDeletedPosition <= json.getServerArray().length()) {
                // JSONArray لا يدعم insert بموضع محدد مباشرة، نعيد البناء
                org.json.JSONArray arr = json.getServerArray();
                org.json.JSONArray rebuilt = new org.json.JSONArray();
                for (int i = 0; i < lastDeletedPosition; i++) rebuilt.put(arr.opt(i));
                rebuilt.put(lastDeletedItem);
                for (int i = lastDeletedPosition; i < arr.length(); i++) rebuilt.put(arr.opt(i));
                // نفرغ المصفوفة ونعيد ملأها
                while (arr.length() > 0) arr.remove(0);
                for (int i = 0; i < rebuilt.length(); i++) {
                    try {
                        arr.put(rebuilt.getJSONObject(i));
                    } catch (Exception ignored) {
                    }
                }
            } else {
                json.addServer(lastDeletedItem);
            }
            String restoredName = lastDeletedItem.optString("Name", "");
            lastDeletedItem = null;
            lastDeletedPosition = -1;
            listener.refreshDropdown();
            serverDropdown.setText(restoredName, false);
        } catch (Exception e) {
            android.util.Log.e(TAG, "undoDelete failed", e);
        }
    }

    // ══════════════════════════════════════════════════════════════
    //  الحصول على موضع السيرفر المحدد
    // ══════════════════════════════════════════════════════════════
    public int getSelectedPosition() {
        String selected = serverDropdown.getText().toString().trim();
        if (selected.isEmpty()) return -1;

        for (int i = 0; i < json.getServerArray().length(); i++) {
            JSONObject obj = json.getServerArray().optJSONObject(i);

            if (obj != null && selected.equals(obj.optString("Name"))) {
                return i;
            }
        }
        return -1;
    }

    // ══════════════════════════════════════════════════════════════
    //  الحصول على بيانات السيرفر المحدد
    // ══════════════════════════════════════════════════════════════
    public JSONObject getSelectedServer() {
        int position = getSelectedPosition();
        if (position == -1) return null;
        try {
            return json.getServerArray().getJSONObject(position);
        } catch (JSONException e) {
            return null;
        }
    }

    // ══════════════════════════════════════════════════════════════
    //  حفظ في SharedPreferences
    // ══════════════════════════════════════════════════════════════
    private void saveToPrefs(JSONObject jsObj) {
        editor.putString("ssh_port", jsObj.optString("OpenVPNSSHPort", "22"));
        editor.putString("tcp_port", jsObj.optString("OpenVPNTCPPort", "1194"));
        editor.putString("ssl_port", jsObj.optString("OpenVPNSSLPort", "443"));
        editor.putString("ServerName", jsObj.optString("Name", ""));
        editor.putString("ServerIPHost", jsObj.optString("ServerIPHost", ""));
        editor.putString("Category", jsObj.optString("Category", ""));
        editor.putString("username", jsObj.optString("Username", ""));
        editor.putString("password", jsObj.optString("Password", ""));
        editor.putBoolean("auto", jsObj.optBoolean("Auto", false));
        editor.apply();
    }

    // ══════════════════════════════════════════════════════════════
    //  Helper
    // ══════════════════════════════════════════════════════════════
    private void toast(String msg) {
        Toast.makeText(activity, msg, Toast.LENGTH_SHORT).show();
    }
}
