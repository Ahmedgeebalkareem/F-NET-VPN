package gen.tiger.net.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Filter;
import android.widget.Filterable;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.google.android.material.textview.MaterialTextView;

import java.util.ArrayList;
import java.util.List;

import gen.tiger.net.R;

/** محوّل بسيط لعرض نص داخل MaterialAutoCompleteTextView */
public class SpinnerAdapter extends ArrayAdapter<String> implements Filterable {

    private final LayoutInflater inflater;

    // ── Constructor ────────────────────────────────────────────────
    public SpinnerAdapter(@NonNull Context context, @NonNull List<String> items) {
        super(context, R.layout.spinner_item, items); // ← نسخة واحدة فقط
        this.inflater = LayoutInflater.from(context);
    }

    // ── ViewHolder ─────────────────────────────────────────────────
    private static class ViewHolder {
        MaterialTextView textView;
    }

    // ── getView ────────────────────────────────────────────────────
    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        return createItemView(position, convertView, parent);
    }

    // ── getDropDownView ────────────────────────────────────────────
    @Override
    public View getDropDownView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        return createItemView(position, convertView, parent);
    }

    // ── createItemView ─────────────────────────────────────────────
    private View createItemView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        ViewHolder holder;

        if (convertView == null) {
            convertView     = inflater.inflate(R.layout.spinner_item, parent, false);
            holder          = new ViewHolder();
            holder.textView = convertView.findViewById(R.id.spinner_item);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }

        holder.textView.setText(getItem(position)); // ← getItem من super مباشرة
        return convertView;
    }

    // ── Filter — يمنع الفلترة التلقائية ───────────────────────────
    @Override
    public Filter getFilter() {
        return new Filter() {
            @Override
            protected FilterResults performFiltering(CharSequence constraint) {
                FilterResults results = new FilterResults();
                // نرجع كل العناصر من super بدون فلترة
                List<String> all = new ArrayList<>();
                for (int i = 0; i < getCount(); i++) all.add(getItem(i));
                results.values = all;
                results.count  = all.size();
                return results;
            }

            @Override
            protected void publishResults(CharSequence constraint, FilterResults results) {
                notifyDataSetChanged();
            }
        };
    }
}