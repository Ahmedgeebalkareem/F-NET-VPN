package gen.tiger.net.utils;

import android.util.Log;

import java.security.GeneralSecurityException;

/**
 * ══════════════════════════════════════════════════════════════
 *  CryptoUtils — نقطة الدخول الوحيدة للتشفير في التطبيق
 * ══════════════════════════════════════════════════════════════
 *
 *  ثلاثة أنظمة تشفير مدعومة:
 *
 *  ┌─────┬─────────────────────────────┬──────────────────────────┐
 *  │ v3: │ PortableCryptoHelper (جديد) │ PBKDF2 + AES-256-GCM     │
 *  │     │ يعمل عبر الأجهزة والتثبيت  │ ← الافتراضي للتصدير/استيراد│
 *  ├─────┼─────────────────────────────┼──────────────────────────┤
 *  │ v2: │ KeystoreHelper              │ Android Keystore GCM     │
 *  │     │ للتخزين المحلي فقط          │ ← يُفكَّك فقط (legacy)   │
 *  ├─────┼─────────────────────────────┼──────────────────────────┤
 *  │ --- │ AESHelper (قديم جداً)       │ AES-CBC / "google" key   │
 *  │     │ بيانات ما قبل v2            │ ← يُفكَّك فقط (legacy)   │
 *  └─────┴─────────────────────────────┴──────────────────────────┘
 *
 *  لماذا v3؟
 *  ─────────────────────────────────────────────────────────────
 *  نظام v2 (Keystore) يُولِّد مفتاحاً جديداً عند إعادة تثبيت
 *  التطبيق → الكونفيجات القديمة لا تُفَكُّ → الاستيراد يفشل.
 *
 *  نظام v3 يستخدم PBKDF2 بـ secret ثابت مدمج في التطبيق →
 *  نفس المفتاح على أي جهاز وبعد أي تثبيت.
 *
 *  قاعدة الاستخدام:
 *  ─────────────────────────────────────────────────────────────
 *  • التشفير الجديد (export/import/copy) → encrypt()  → ينتج "v3:..."
 *  • فك التشفير → decrypt() → يكتشف النوع تلقائياً
 */
public final class CryptoUtils {

    private static final String TAG = "CryptoUtils";

    /** بادئة النظام القديم (Keystore / GCM) — للفك فقط */
    private static final String PREFIX_V2 = "v2:";

    /** بادئة النظام الجديد المحمول (PBKDF2 / GCM) — الافتراضي */
    private static final String PREFIX_V3 = "v3:";

    /** مفتاح النظام القديم جداً (CBC) */
    @Deprecated
    private static final String LEGACY_KEY = "google";

    private CryptoUtils() {}

    // ══════════════════════════════════════════════════════════════
    //  Public API
    // ══════════════════════════════════════════════════════════════

    /**
     * يُشفِّر النص باستخدام نظام v3 (PBKDF2 + AES-256-GCM).
     * النتيجة تبدأ بـ "v3:" وتعمل على أي جهاز وبعد إعادة التثبيت.
     *
     * @param plainText النص المراد تشفيره
     * @return النص المُشفَّر أو {@code null} عند الفشل
     */
    public static String encrypt(String plainText) {
        if (plainText == null) return null;
        try {
            return PREFIX_V3 + PortableCryptoHelper.encrypt(plainText);
        } catch (Exception e) {
            Log.e(TAG, "فشل التشفير بنظام v3", e);
            return null;
        }
    }

    /**
     * يفكّ تشفير النص — يكتشف النوع تلقائياً:
     * <ul>
     *   <li>"v3:..." → PortableCryptoHelper (PBKDF2 / GCM)</li>
     *   <li>"v2:..." → KeystoreHelper (Android Keystore / GCM)</li>
     *   <li>غير ذلك  → AESHelper القديم (CBC)</li>
     * </ul>
     *
     * @param cipherText النص المُشفَّر
     * @return النص الأصلي، أو {@code null} عند فشل كل المحاولات
     */
    public static String decrypt(String cipherText) {
        if (cipherText == null || cipherText.isEmpty()) return null;

        if (cipherText.startsWith(PREFIX_V3)) {
            // ── v3: PBKDF2 + GCM (النظام الجديد المحمول) ─────────
            return decryptV3(cipherText.substring(PREFIX_V3.length()));

        } else if (cipherText.startsWith(PREFIX_V2)) {
            // ── v2: Android Keystore + GCM ─────────────────────────
            // قد يفشل بعد إعادة التثبيت — حينها نُعيد null بصمت
            return decryptV2(cipherText.substring(PREFIX_V2.length()));

        } else {
            // ── Legacy: AES-CBC / "google" key ──────────────────────
            return decryptLegacy(cipherText);
        }
    }

    /**
     * يفكّ التشفير ويُعيد {@code fallback} بدلاً من {@code null} عند الفشل.
     */
    public static String decryptOrDefault(String cipherText, String fallback) {
        String result = decrypt(cipherText);
        return result != null ? result : fallback;
    }

    /**
     * يتحقق إذا كانت البيانات مُشفَّرة بنظام v3 (المحمول).
     */
    public static boolean isPortableFormat(String cipherText) {
        return cipherText != null && cipherText.startsWith(PREFIX_V3);
    }

    /**
     * يتحقق إذا كانت البيانات مُشفَّرة بأي نظام جديد (v2 أو v3).
     */
    public static boolean isNewFormat(String cipherText) {
        return cipherText != null
                && (cipherText.startsWith(PREFIX_V2) || cipherText.startsWith(PREFIX_V3));
    }

    // ══════════════════════════════════════════════════════════════
    //  Private Helpers
    // ══════════════════════════════════════════════════════════════

    /** v3: PBKDF2 + AES-256-GCM (محمول، يعمل بعد إعادة التثبيت) */
    private static String decryptV3(String base64Data) {
        try {
            return PortableCryptoHelper.decrypt(base64Data);
        } catch (Exception e) {
            Log.e(TAG, "فشل فك تشفير v3", e);
            return null;
        }
    }

    /** v2: Android Keystore + GCM (قد يفشل بعد إعادة التثبيت) */
    private static String decryptV2(String base64Data) {
        try {
            return KeystoreHelper.decrypt(base64Data);
        } catch (Exception e) {
            Log.w(TAG, "فشل فك تشفير v2 (ربما بعد إعادة التثبيت): " + e.getMessage());
            return null;
        }
    }

    /** Legacy: AES-CBC / "google" key */
    @SuppressWarnings("deprecation")
    private static String decryptLegacy(String base64CipherText) {
        try {
            Log.d(TAG, "فك تشفير بيانات قديمة (CBC)");
            return AESHelper.decrypt(LEGACY_KEY, base64CipherText);
        } catch (GeneralSecurityException e) {
            Log.e(TAG, "فشل فك التشفير القديم", e);
            return null;
        }
    }
}
