package gen.tiger.net.managers;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.util.Log;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.preference.PreferenceManager;

import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.android.material.textfield.MaterialAutoCompleteTextView;

import gen.tiger.net.activities.SSLNetworkActivity;
import gen.tiger.net.models.Config;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.List;

/**
 * SSLNetworkManager — مدير عمليات شبكات SSL مسؤول عن: إضافة / تعديل / حذف / عرض شبكات SSL معزول
 * تماماً عن MainActivity
 */
public class SSLNetworkManager {

    private static final String TAG = "SSLNetworkManager";

    // ── Dependencies ───────────────────────────────────────────────
    private final AppCompatActivity activity;
    private final Context context;
    private final Config json;
    private final SharedPreferences prefs;
    private final SharedPreferences.Editor editor;

    // ── UI المرتبطة بشبكة SSL في MainActivity ────────────────────
    private final MaterialAutoCompleteTextView sslNetworkDropdown;
    private final List<String> sslNetworkList;

    // ── Callback للإشعار بالتغييرات ───────────────────────────────
    private final OnSSLNetworkChangedListener listener;

    // ── Launcher للصفحة ───────────────────────────────────────────
    private JSONObject lastDeletedItem = null;
    private int lastDeletedPosition = -1;
    private ActivityResultLauncher<Intent> sslNetworkLauncher;

    // ── حفظ موضع الشبكة عند التعديل ──────────────────────────────
    private int pendingEditPosition = -1;

    // ══════════════════════════════════════════════════════════════
    //  Interface — Callback
    // ══════════════════════════════════════════════════════════════
    public interface OnSSLNetworkChangedListener {
        void onSSLNetworkAdded(String networkName);

        void onSSLNetworkEdited(String networkName);

        void onSSLNetworkDeleted(String name, Runnable undoAction);

        void refreshDropdown();
    }

    // ══════════════════════════════════════════════════════════════
    //  Constructor
    // ══════════════════════════════════════════════════════════════
    public SSLNetworkManager(
            AppCompatActivity activity,
            MaterialAutoCompleteTextView sslNetworkDropdown,
            List<String> sslNetworkList,
            OnSSLNetworkChangedListener listener) {

        this.activity = activity;
        this.context = activity.getApplicationContext();
        this.json = Config.getInstance(activity);
        this.prefs = PreferenceManager.getDefaultSharedPreferences(activity);
        this.editor = prefs.edit();
        this.sslNetworkDropdown = sslNetworkDropdown;
        this.sslNetworkList = sslNetworkList;
        this.listener = listener;

        registerLauncher();
    }

    // ══════════════════════════════════════════════════════════════
    //  تسجيل Launcher
    // ══════════════════════════════════════════════════════════════
    private void registerLauncher() {
        sslNetworkLauncher =
                activity.registerForActivityResult(
                        new ActivityResultContracts.StartActivityForResult(),
                        result -> {
                            if (result.getResultCode() == AppCompatActivity.RESULT_OK
                                    && result.getData() != null) {
                                handleSSLNetworkResult(result.getData());
                            }
                        });
    }

    // ══════════════════════════════════════════════════════════════
    //  معالجة النتيجة القادمة من SSLNetworkActivity
    // ══════════════════════════════════════════════════════════════
    private void handleSSLNetworkResult(Intent data) {
        try {
            String jsonStr = data.getStringExtra("ssl_network_data");
            boolean isEdit = data.getBooleanExtra("is_edit", false);

            if (jsonStr == null) {
                Log.e(TAG, "SSL network data is null");
                toast("Invalid data received");
                return;
            }
            JSONObject jsObj = new JSONObject(jsonStr);
            String name = jsObj.optString("Name", "");

            if (isEdit && pendingEditPosition >= 0) {
                if (pendingEditPosition < json.getSSLNetworkArray().length()) {
                    json.getSSLNetworkArray().put(pendingEditPosition, jsObj);
                }
                pendingEditPosition = -1;
                listener.onSSLNetworkEdited(name);
            } else {
                json.addSSLNetwork(jsObj);
                listener.onSSLNetworkAdded(name);
            }

            listener.refreshDropdown();
            sslNetworkDropdown.setText(name, false);

        } catch (JSONException e) {
            Log.e(TAG, "handleSSLNetworkResult: " + e.getMessage(), e);
            toast("Error saving SSL network: " + e.getMessage());
        }
    }

    // ══════════════════════════════════════════════════════════════
    //  إضافة شبكة SSL جديدة
    // ══════════════════════════════════════════════════════════════
    public void addSSLNetwork() {
        pendingEditPosition = -1;
        Intent intent = new Intent(activity, SSLNetworkActivity.class);
        intent.putExtra("is_edit", false);
        sslNetworkLauncher.launch(intent);
    }

    // ══════════════════════════════════════════════════════════════
    //  تعديل شبكة SSL موجودة
    // ══════════════════════════════════════════════════════════════
    public void editSSLNetwork() {
        int position = getSelectedPosition();
        if (position == -1) {
            toast("Please select an SSL network first");
            return;
        }
        try {
            JSONObject network = json.getSSLNetworkArray().getJSONObject(position);
            pendingEditPosition = position;

            Intent intent = new Intent(activity, SSLNetworkActivity.class);
            intent.putExtra("is_edit", true);
            intent.putExtra("ssl_network_json", network.toString());
            sslNetworkLauncher.launch(intent);

        } catch (JSONException e) {
            Log.e(TAG, "editSSLNetwork: " + e.getMessage(), e);
            toast("Error loading SSL network data");
        }
    }

    // ══════════════════════════════════════════════════════════════
    //  حذف شبكة SSL
    // ══════════════════════════════════════════════════════════════
    public void deleteSSLNetwork() {
        int position = getSelectedPosition();
        if (position == -1) {
            toast("Please select an SSL network first");
            return;
        }
        String selectedName = sslNetworkDropdown.getText().toString();

        new MaterialAlertDialogBuilder(activity)
                .setTitle("Delete SSL Network")
                .setMessage("Are you sure you want to delete this SSL network?")
                .setPositiveButton(
                        "Delete",
                        (dialog, which) -> {
                            if (position < json.getSSLNetworkArray().length()) {
                                try {
                                    lastDeletedItem =
                                            new JSONObject(
                                                    json.getSSLNetworkArray()
                                                            .getJSONObject(position)
                                                            .toString());
                                } catch (JSONException ignored) {
                                    lastDeletedItem = null;
                                }
                                lastDeletedPosition = position;
                                json.getSSLNetworkArray().remove(position);
                                Runnable undoAction =
                                        () -> {
                                            if (lastDeletedItem != null) undoDelete();
                                        };
                                listener.onSSLNetworkDeleted(selectedName, undoAction);
                                listener.refreshDropdown();
                                int newSize = json.getSSLNetworkArray().length();
                                if (newSize > 0) {
                                    int newPos = Math.max(0, position - 1);
                                    try {
                                        String prevName =
                                                json.getSSLNetworkArray()
                                                        .getJSONObject(newPos)
                                                        .optString("Name", "");
                                        sslNetworkDropdown.setText(prevName, false);
                                    } catch (JSONException e) {
                                        sslNetworkDropdown.setText("", false);
                                    }
                                } else {
                                    sslNetworkDropdown.setText("", false);
                                }
                            }
                        })
                .setNegativeButton("Cancel", null)
                .show();
    }

    // ══════════════════════════════════════════════════════════════
    //  الحصول على موضع الشبكة المحددة
    // ══════════════════════════════════════════════════════════════
    public int getSelectedPosition() {
        String selected = sslNetworkDropdown.getText().toString().trim();
        if (selected.isEmpty()) return -1;

        for (int i = 0; i < json.getSSLNetworkArray().length(); i++) {
            JSONObject obj = json.getSSLNetworkArray().optJSONObject(i);

            if (obj != null && selected.equals(obj.optString("Name"))) {
                return i;
            }
        }
        return -1;
    }

    // ══════════════════════════════════════════════════════════════
    //  الحصول على بيانات الشبكة المحددة
    // ══════════════════════════════════════════════════════════════
    public JSONObject getSelectedSSLNetwork() {
        int position = getSelectedPosition();
        if (position == -1) return null;
        try {
            return json.getSSLNetworkArray().getJSONObject(position);
        } catch (JSONException e) {
            return null;
        }
    }

    // ══════════════════════════════════════════════════════════════
    //  Helper
    // ══════════════════════════════════════════════════════════════
    private void toast(String msg) {
        Toast.makeText(context, msg, Toast.LENGTH_SHORT).show();
    }

    // ══════════════════════════════════════════════════════════════
    //  Undo آخر حذف
    // ══════════════════════════════════════════════════════════════
    public void undoDelete() {
        if (lastDeletedItem == null) return;
        try {
            JSONArray arr = json.getSSLNetworkArray();
            JSONArray rebuilt = new JSONArray();
            for (int i = 0;
                    i < (lastDeletedPosition < arr.length() ? lastDeletedPosition : arr.length());
                    i++) rebuilt.put(arr.opt(i));
            rebuilt.put(lastDeletedItem);
            int start = Math.min(lastDeletedPosition, arr.length());
            for (int i = start; i < arr.length(); i++) rebuilt.put(arr.opt(i));
            while (arr.length() > 0) arr.remove(0);
            for (int i = 0; i < rebuilt.length(); i++) {
                try {
                    arr.put(rebuilt.getJSONObject(i));
                } catch (Exception ignored) {
                }
            }
            String restoredName = lastDeletedItem.optString("Name", "");
            lastDeletedItem = null;
            lastDeletedPosition = -1;
            listener.refreshDropdown();
            sslNetworkDropdown.setText(restoredName, false);
        } catch (Exception e) {
            android.util.Log.e("Manager", "undoDelete failed", e);
        }
    }
}
