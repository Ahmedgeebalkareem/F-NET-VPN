package gen.tiger.net.activities;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ArrayAdapter;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.preference.PreferenceManager;

import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.appbar.CollapsingToolbarLayout;
import com.google.android.material.button.MaterialButtonToggleGroup;
import com.google.android.material.floatingactionbutton.ExtendedFloatingActionButton;
import com.google.android.material.materialswitch.MaterialSwitch;
import com.google.android.material.textfield.MaterialAutoCompleteTextView;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.color.DynamicColors;

import gen.tiger.net.R;

public class PayloadGeneratorActivity extends AppCompatActivity
        implements MaterialButtonToggleGroup.OnButtonCheckedListener {

    // ── SharedPreferences Keys ─────────────────────────────────────
    private static final String PREF_URL_HOST       = "URL_HOST";
    private static final String PREF_INJECT_METHOD  = "SELECTED_INJECT_METHOD";
    private static final String PREF_REQUEST_METHOD = "SELECTED_REQUEST_METHOD";
    private static final String PREF_QUERY_MODE     = "QUERY_MODE";
    private static final String PREF_ONLINE_HOST    = "ONLINE_HOST";
    private static final String PREF_FORWARD_HOST   = "FORWARD_HOST";
    private static final String PREF_REVERSE_PROXY  = "REVERSE_PROXY";
    private static final String PREF_KEEP_ALIVE     = "KEEP_ALIVE";
    private static final String PREF_DUAL_CONNECT   = "DUAL_CONNECT";
    private static final String PREF_PROXY_AUTH     = "PROXY_AUTH";
    private static final String PREF_FIXED_PAYLOAD  = "FIXED_PAYLOAD";
    private static final String PREF_SPLIT          = "SPLIT";
    private static final String PREF_IS_WEBSOCKET   = "IS_WEBSOCKET_MODE";

    // ── Options ────────────────────────────────────────────────────
    private static final String[] REQUEST_OPTIONS = {
            "CONNECT", "GET", "POST", "HEAD", "PUT", "PATCH", "DELETE"};
    private static final String[] INJECT_OPTIONS = {
            "NORMAL", "FRONT INJECT", "BACK INJECT", "WEBSOCKET INJECT"};

    // ── Views ──────────────────────────────────────────────────────
    private MaterialToolbar              toolbar;
    private TextInputEditText            urlHost;
    private MaterialAutoCompleteTextView requestMethod, injectMethod;
    private MaterialButtonToggleGroup    queryMode, splitGroup;
    private MaterialSwitch               onlineHost, forwardHost, reverseProxy, keepAlive, proxyAuth, dualConnect;
    private ExtendedFloatingActionButton fab;

    // ── State ──────────────────────────────────────────────────────
    private boolean isWebSocketMode = false;
    private SharedPreferences.Editor editor;

    // ══════════════════════════════════════════════════════════════
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        DynamicColors.applyToActivityIfAvailable(this);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payload_generator);

        editor = PreferenceManager.getDefaultSharedPreferences(this).edit();

        bindViews();
        setupToolbar();
        setupAdapters();
        setupListeners();
        loadDefaults();
    }

    // ══════════════════════════════════════════════════════════════
    //  ربط الـ Views
    // ══════════════════════════════════════════════════════════════
    private void bindViews() {
        toolbar       = findViewById(R.id.toolbar);
        urlHost       = findViewById(R.id.url_host);
        requestMethod = findViewById(R.id.request_method);
        injectMethod  = findViewById(R.id.inject_method);
        queryMode     = findViewById(R.id.query_mode);
        splitGroup    = findViewById(R.id.split_group);
        onlineHost    = findViewById(R.id.online_host);
        forwardHost   = findViewById(R.id.forward_host);
        reverseProxy  = findViewById(R.id.reverse_proxy);
        keepAlive     = findViewById(R.id.keep_alive);
        proxyAuth     = findViewById(R.id.paygen_proxy_auth);
        dualConnect   = findViewById(R.id.dual_connect);
        fab		   = findViewById(R.id.generate);
    }

    // ══════════════════════════════════════════════════════════════
    //  إعداد الـ Toolbar
    // ══════════════════════════════════════════════════════════════
    private void setupToolbar() {
        setSupportActionBar(toolbar);
        toolbar.setNavigationOnClickListener(v -> finish());
    }

    // ══════════════════════════════════════════════════════════════
    //  إعداد الـ Adapters
    // ══════════════════════════════════════════════════════════════
    private void setupAdapters() {
        requestMethod.setAdapter(
                new ArrayAdapter<>(this, R.layout.item, REQUEST_OPTIONS));
        injectMethod.setAdapter(
                new ArrayAdapter<>(this, R.layout.item, INJECT_OPTIONS));
    }

    // ══════════════════════════════════════════════════════════════
    //  إعداد الـ Listeners
    // ══════════════════════════════════════════════════════════════
    private void setupListeners() {
        splitGroup.addOnButtonCheckedListener(this);
        queryMode.addOnButtonCheckedListener(this);

        requestMethod.setOnItemClickListener((parent, v, pos, id) ->
                editor.putInt(PREF_REQUEST_METHOD, pos).apply());

        injectMethod.setOnItemClickListener((parent, v, pos, id) -> {
            adjustInjectMethod(pos);
            editor.putInt(PREF_INJECT_METHOD, pos).apply();
        });
        
        fab.setOnClickListener(v -> generateAndReturn());
    }

    // ══════════════════════════════════════════════════════════════
    //  تحميل القيم الافتراضية
    // ══════════════════════════════════════════════════════════════
    private void loadDefaults() {
        CollapsingToolbarLayout ctl =
            (CollapsingToolbarLayout) toolbar.getParent();
        if (ctl != null) ctl.setTitle("PAYLOAD GENERATOR");
        splitGroup.check(R.id.split_none);
        queryMode.check(R.id.query_mode_normal);
        requestMethod.setText(REQUEST_OPTIONS[0], false);
        injectMethod.setText(INJECT_OPTIONS[0],   false);
        isWebSocketMode = false;
    }

    // ══════════════════════════════════════════════════════════════
    //  MaterialButtonToggleGroup Listener
    // ══════════════════════════════════════════════════════════════
    @Override
    public void onButtonChecked(MaterialButtonToggleGroup group, int checkedId, boolean isChecked) {
        if (!isChecked) return;

        if (group == queryMode) {
            editor.putInt(PREF_QUERY_MODE,
                group.indexOfChild(group.findViewById(checkedId))).apply();

        } else if (group == splitGroup) {
            adjustSplitGroup(checkedId);
        }
    }

    // ══════════════════════════════════════════════════════════════
    //  منطق الحقن والتقسيم
    // ══════════════════════════════════════════════════════════════
    private void adjustInjectMethod(int pos) {
        switch (pos) {
            case 3: // WebSocket
                isWebSocketMode = true;
                requestMethod.setText(REQUEST_OPTIONS[1], false); // GET
                splitGroup.check(R.id.split_none);
                break;
            case 0: // Normal
                isWebSocketMode = false;
                splitGroup.check(R.id.split_none);
                requestMethod.setText(REQUEST_OPTIONS[0], false); // CONNECT
                break;
            default: // Front / Back Inject
                isWebSocketMode = false;
                requestMethod.setText(REQUEST_OPTIONS[1], false); // GET
                break;
        }
    }

    private void adjustSplitGroup(int checkedId) {
        int mode = splitGroup.indexOfChild(splitGroup.findViewById(checkedId));
        if (mode == 0 || mode == 1) {
            injectMethod.setText(INJECT_OPTIONS[2],   false); // Back Inject
            requestMethod.setText(REQUEST_OPTIONS[1], false); // GET
        } else {
            injectMethod.setText(INJECT_OPTIONS[0], false); // Normal
            isWebSocketMode = false;
        }
    }

    // ══════════════════════════════════════════════════════════════
    //  توليد وإرجاع الـ Payload
    // ══════════════════════════════════════════════════════════════
    private void generateAndReturn() {
        if (!validateInputs()) return;
        String url = urlHost.getText() != null
                ? urlHost.getText().toString().trim() : "";

        String payload = generatePayload(url);
        savePrefs(url, payload);

        Intent result = new Intent();
        result.putExtra("payload", payload);
        setResult(RESULT_OK, result);
        finish();
    }
    
        // ══════════════════════════════════════════════════════════════
    //   شرط التحقق من مدخلات Payload
    // ══════════════════════════════════════════════════════════════
    private boolean validateInputs() {
        String url = urlHost.getText().toString().trim();
    
        if (TextUtils.isEmpty(url)) {
            urlHost.setError("Required");
            return false;
        }
        return true;
    }


    // ══════════════════════════════════════════════════════════════
    //  بناء الـ Payload
    // ══════════════════════════════════════════════════════════════
    private String generatePayload(String host) {
        
        final String crlf   = "[crlf]";
        String       method = requestMethod.getText().toString();
        String       path   = isWebSocketMode ? "/" : "http://" + host + "/";

        StringBuilder sb = new StringBuilder();
        sb.append(method).append(" ").append(path).append(" HTTP/1.1").append(crlf);
        sb.append("Host: ").append(host).append(crlf);

        if (isWebSocketMode) {
            sb.append("Upgrade: websocket").append(crlf);
            sb.append("Connection: Upgrade").append(crlf);
        }

        if (onlineHost.isChecked())  sb.append("X-Online-Host: ")            .append(host).append(crlf);
        if (forwardHost.isChecked()) sb.append("X-Forward-Host: ")           .append(host).append(crlf);
        if (reverseProxy.isChecked())sb.append("X-Forwarded-For: ")          .append(host).append(crlf);
        if (proxyAuth.isChecked())   sb.append("Proxy-Authorization: [auth]").append(crlf);
        if (keepAlive.isChecked())   sb.append("Connection: Keep-Alive")     .append(crlf);
        if (dualConnect.isChecked()) sb.append("CONNECT [host_port] [protocol]").append(crlf).append(crlf);

        sb.append(crlf);
        sb.append(getSplitToken());

        return sb.toString();
    }

    private String getSplitToken() {
        int id = splitGroup.getCheckedButtonId();
        if (id == R.id.split_instant) return "[instant_split]";
        if (id == R.id.split_delay)   return "[delay_split]";
        return "";
    }

    // ══════════════════════════════════════════════════════════════
    //  حفظ الإعدادات
    // ══════════════════════════════════════════════════════════════
    private void savePrefs(String url, String payload) {
        int splitIdx = splitGroup.indexOfChild(
                splitGroup.findViewById(splitGroup.getCheckedButtonId()));

        editor.putString(PREF_URL_HOST,       url)
              .putBoolean(PREF_ONLINE_HOST,   onlineHost.isChecked())
              .putBoolean(PREF_FORWARD_HOST,  forwardHost.isChecked())
              .putBoolean(PREF_REVERSE_PROXY, reverseProxy.isChecked())
              .putBoolean(PREF_KEEP_ALIVE,    keepAlive.isChecked())
              .putBoolean(PREF_PROXY_AUTH,    proxyAuth.isChecked())
              .putBoolean(PREF_DUAL_CONNECT,  dualConnect.isChecked())
              .putBoolean(PREF_IS_WEBSOCKET,  isWebSocketMode)
              .putInt(PREF_SPLIT,             splitIdx)
              .putString(PREF_FIXED_PAYLOAD,  payload)
              .apply();
    }
}