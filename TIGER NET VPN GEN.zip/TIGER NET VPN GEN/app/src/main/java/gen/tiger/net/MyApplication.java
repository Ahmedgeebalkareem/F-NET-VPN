package gen.tiger.net;

import android.app.Application;
import android.util.Log;

import androidx.appcompat.app.AppCompatDelegate;
import androidx.preference.PreferenceManager;

import com.google.android.material.color.DynamicColors;

import gen.tiger.net.BuildConfig;
import gen.tiger.net.models.Config;

public class MyApplication extends Application {

    private static final String TAG = "MyApplication";

    // ════════════════════════════════════════════════════════════════════════
    //  BUG FIX #10: CONFIG_GET_API و CONFIG_POST_API كانا يُهيَّآن كـ static
    //  fields عند تحميل الكلاس (قبل استدعاء onCreate)، وقيمتهما مشتقّة من
    //  Config.getGetApiUrl() التي تستدعي decrypt(null, ...) بدون context.
    //  إذا فشل الفكّ، القيمة تكون null وكل استخدام لاحق يرمي NPE.
    //
    //  الحل: بما أن Config.getGetApiUrl() أصبحت تُعيد @NonNull (تُعيد ""
    //  بدلاً من null)، الحقول لن تكون null. لكن الجذر الحقيقي للمشكلة هو
    //  أن ENCRYPTED_GET_API == ENCRYPTED_POST_API (copy-paste bug في Config).
    //  بعد إصلاح الـ encrypted values، ستعمل هذه الحقول بشكل صحيح.
    //
    //  ملاحظة: static field initialization يحدث في main thread قبل onCreate،
    //  لذا لا يوجد race condition هنا.
    // ════════════════════════════════════════════════════════════════════════
    public static final String CONFIG_GET_API  = Config.getGetApiUrl();
    public static final String CONFIG_POST_API = Config.getPostApiUrl();
    public static final String PASSCODE        = Config.getPasscode();

    @Override
    public void onCreate() {
        super.onCreate();
        DynamicColors.applyToActivitiesIfAvailable(this);

        // ── تطبيق الثيم المحفوظ قبل رسم أي Activity ─────────────
        // 0 = Light | 1 = Dark | 2 = Follow System (الافتراضي)
        int savedTheme = PreferenceManager
                .getDefaultSharedPreferences(this)
                .getInt("THEME_MODE", 2);

        switch (savedTheme) {
            case 0:
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
                break;
            case 1:
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
                break;
            default:
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM);
                break;
        }

        if (BuildConfig.DEBUG) {
            Log.d(TAG, "GET  API : " + (CONFIG_GET_API.isEmpty() ? "⚠️ EMPTY (check ENCRYPTED_GET_API)" : "✅ OK"));
            Log.d(TAG, "POST API : " + (CONFIG_POST_API.isEmpty() ? "⚠️ EMPTY (check ENCRYPTED_POST_API)" : "✅ OK"));
            Log.d(TAG, "Passcode : " + PASSCODE);
        }
    }
}
