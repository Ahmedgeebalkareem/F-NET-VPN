package gen.tiger.net.utils;

import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;
import android.util.Log;

import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.security.KeyStore;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

/**
 * ══════════════════════════════════════════════════════════════
 *  KeystoreHelper — AES-256-GCM via Android Keystore
 * ══════════════════════════════════════════════════════════════
 *
 *  لماذا Android Keystore؟
 *  ─────────────────────────────────────────────────────────────
 *  • المفتاح يُولَّد داخل Secure Hardware ولا يمكن استخراجه أبداً.
 *  • لا يوجد كلمة مرور مكشوفة في الكود مثل "google".
 *  • كل عملية تشفير تستخدم IV عشوائياً جديداً ← نفس النص
 *    لا يُنتج نفس التشفير مرتين.
 *  • GCM يوفر Authentication بجانب التشفير ← يكتشف أي تلاعب
 *    في البيانات تلقائياً.
 *
 *  تنسيق البيانات المُشفَّرة:
 *  ─────────────────────────────────────────────────────────────
 *  البيانات المُخزَّنة = Base64( IV[12 bytes] + CipherText )
 *  عند فك التشفير نستخرج الـ IV من أول 12 بايت ثم نفكّ الباقي.
 *
 *  التوافق مع البيانات القديمة:
 *  ─────────────────────────────────────────────────────────────
 *  البيانات القديمة (CBC) لا تبدأ بـ "v2:"
 *  البيانات الجديدة (GCM) تبدأ بـ "v2:"
 *  CryptoUtils تستخدم هذا الفرق للتعامل مع كلا النوعين.
 */
public final class KeystoreHelper {

    private static final String TAG           = "KeystoreHelper";
    private static final String KEY_ALIAS     = "tiger_net_vpn_key";
    private static final String KEYSTORE_TYPE = "AndroidKeyStore";
    private static final String AES_MODE      = "AES/GCM/NoPadding";
    private static final int    GCM_TAG_BITS  = 128;
    private static final int    IV_SIZE_BYTES = 12;

    private KeystoreHelper() {}

    // ══════════════════════════════════════════════════════════════
    //  Public API
    // ══════════════════════════════════════════════════════════════

    /**
     * يُشفّر النص ويُعيد: Base64( IV[12] + CipherText )
     */
    public static String encrypt(String plainText) throws Exception {
        SecretKey key    = getOrCreateKey();
        Cipher    cipher = Cipher.getInstance(AES_MODE);
        cipher.init(Cipher.ENCRYPT_MODE, key);

        byte[] iv         = cipher.getIV();               // 12 bytes عشوائي
        byte[] cipherText = cipher.doFinal(
                plainText.getBytes(StandardCharsets.UTF_8));

        // دمج IV + CipherText في مصفوفة واحدة
        ByteBuffer buffer = ByteBuffer.allocate(IV_SIZE_BYTES + cipherText.length);
        buffer.put(iv);
        buffer.put(cipherText);

        return Base64.encodeToString(buffer.array(), Base64.NO_WRAP);
    }

    /**
     * يفكّ تشفير نص مُشفَّر بـ {@link #encrypt}.
     * يتوقع: Base64( IV[12] + CipherText )
     */
    public static String decrypt(String base64Data) throws Exception {
        byte[] combined = Base64.decode(base64Data, Base64.NO_WRAP);

        if (combined.length < IV_SIZE_BYTES) {
            throw new IllegalArgumentException("البيانات أقصر من الحد الأدنى المتوقع.");
        }

        // استخراج IV (أول 12 بايت) و CipherText (الباقي)
        byte[] iv         = new byte[IV_SIZE_BYTES];
        byte[] cipherText = new byte[combined.length - IV_SIZE_BYTES];
        System.arraycopy(combined, 0,             iv,         0, IV_SIZE_BYTES);
        System.arraycopy(combined, IV_SIZE_BYTES, cipherText, 0, cipherText.length);

        SecretKey key    = getOrCreateKey();
        Cipher    cipher = Cipher.getInstance(AES_MODE);
        cipher.init(Cipher.DECRYPT_MODE, key, new GCMParameterSpec(GCM_TAG_BITS, iv));

        byte[] plain = cipher.doFinal(cipherText);
        return new String(plain, StandardCharsets.UTF_8);
    }

    // ══════════════════════════════════════════════════════════════
    //  إدارة المفتاح
    // ══════════════════════════════════════════════════════════════

    /**
     * يُعيد المفتاح إذا كان موجوداً، أو يُنشئ مفتاحاً جديداً ويُخزّنه.
     * المفتاح لا يمكن استخراجه من الـ Keystore أبداً.
     */
    private static SecretKey getOrCreateKey() throws Exception {
        KeyStore keyStore = KeyStore.getInstance(KEYSTORE_TYPE);
        keyStore.load(null);

        // إذا كان المفتاح موجوداً، أعده مباشرةً
        if (keyStore.containsAlias(KEY_ALIAS)) {
            KeyStore.SecretKeyEntry entry =
                    (KeyStore.SecretKeyEntry) keyStore.getEntry(KEY_ALIAS, null);
            if (entry != null) {
                Log.d(TAG, "مفتاح موجود في Keystore، تم استرجاعه.");
                return entry.getSecretKey();
            }
        }

        // أنشئ مفتاحاً جديداً وخزّنه في Keystore
        Log.d(TAG, "إنشاء مفتاح جديد في Keystore...");
        KeyGenerator keyGen = KeyGenerator.getInstance(
                KeyProperties.KEY_ALGORITHM_AES, KEYSTORE_TYPE);

        keyGen.init(
            new KeyGenParameterSpec.Builder(
                    KEY_ALIAS,
                    KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
                .setKeySize(256)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                // المفتاح يبقى صالحاً حتى بعد إعادة تشغيل الجهاز
                .setUserAuthenticationRequired(false)
                .build()
        );

        return keyGen.generateKey();
    }
}
