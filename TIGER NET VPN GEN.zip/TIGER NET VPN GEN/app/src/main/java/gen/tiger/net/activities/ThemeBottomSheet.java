package gen.tiger.net.activities;

import android.animation.AnimatorSet;
import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ObjectAnimator;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.interpolator.view.animation.FastOutSlowInInterpolator;
import androidx.preference.PreferenceManager;

import com.google.android.material.bottomsheet.BottomSheetBehavior;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.bottomsheet.BottomSheetDialogFragment;
import com.google.android.material.card.MaterialCardView;

import gen.tiger.net.R;

/**
 * ══════════════════════════════════════════════════════════════
 *  ThemeBottomSheet — Material 3 EXPRESSIVE Edition
 * ══════════════════════════════════════════════════════════════
 *
 *  المميزات الجديدة:
 *  ─────────────────────────────────────────────────────────────
 *  ① Spring-feel animations — Overshoot scale + alpha fade
 *  ② Icon + subtitle — كل خيار له أيقونة ووصف قصير
 *  ③ Selected state — الكارد يتغير للـ colorPrimaryContainer
 *                     والأيقونة تنتقل للـ colorOnPrimaryContainer
 *  ④ WindowInsets  — paddingBottom ديناميكي لـ Gesture Nav
 *  ⑤ Stable dismiss — dismiss() أولاً ثم setDefaultNightMode()
 *  ⑥ Same-mode guard — لو اختار نفس الثيم → dismiss فقط
 */
public class ThemeBottomSheet extends BottomSheetDialogFragment {

    public static final String TAG = "ThemeBottomSheet";

    private static final String PREF_THEME   = "THEME_MODE";
    private static final int    ANIM_MS      = 220;
    private static final int    DISMISS_DELAY= 180;

    // ── Views ──────────────────────────────────────────────
    private MaterialCardView rowLight, rowDark, rowSystem;
    private ImageView        checkLight, checkDark, checkSystem;
    private MaterialCardView iconContLight, iconContDark, iconContSystem;
    private ImageView        iconLight, iconDark, iconSystem;

    // ══════════════════════════════════════════════════════
    //  Theme override → 40dp rounded corners
    // ══════════════════════════════════════════════════════
    @Override
    public int getTheme() {
        return R.style.AppTheme_BottomSheet;
    }

    // ══════════════════════════════════════════════════════
    //  Inflate
    // ══════════════════════════════════════════════════════
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.bottom_sheet_theme, container, false);
    }

    // ══════════════════════════════════════════════════════
    //  onStart — BottomSheet fully attached to window here
    // ══════════════════════════════════════════════════════
    @Override
    public void onStart() {
        super.onStart();
        BottomSheetDialog dialog = (BottomSheetDialog) getDialog();
        if (dialog == null) return;

        View sheet = dialog.findViewById(
                com.google.android.material.R.id.design_bottom_sheet);
        if (sheet == null) return;

        BottomSheetBehavior<View> b = BottomSheetBehavior.from(sheet);
        b.setState(BottomSheetBehavior.STATE_EXPANDED);
        b.setSkipCollapsed(true);
        b.setDraggable(true);
    }

    // ══════════════════════════════════════════════════════
    //  Setup
    // ══════════════════════════════════════════════════════
    @Override
    public void onViewCreated(@NonNull View root, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(root, savedInstanceState);

        bindViews(root);
        applyWindowInsets(root);
        setRowContent();

        int saved = savedPref();
        renderSelection(saved, false);

        rowLight .setOnClickListener(v -> onPick(0, AppCompatDelegate.MODE_NIGHT_NO));
        rowDark  .setOnClickListener(v -> onPick(1, AppCompatDelegate.MODE_NIGHT_YES));
        rowSystem.setOnClickListener(v -> onPick(2, AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM));
    }

    // ══════════════════════════════════════════════════════
    //  Bind all views
    // ══════════════════════════════════════════════════════
    private void bindViews(View root) {
        rowLight  = root.findViewById(R.id.row_light);
        rowDark   = root.findViewById(R.id.row_dark);
        rowSystem = root.findViewById(R.id.row_system);

        checkLight  = rowLight .findViewById(R.id.check);
        checkDark   = rowDark  .findViewById(R.id.check);
        checkSystem = rowSystem.findViewById(R.id.check);

        iconContLight  = rowLight .findViewById(R.id.icon_container);
        iconContDark   = rowDark  .findViewById(R.id.icon_container);
        iconContSystem = rowSystem.findViewById(R.id.icon_container);

        iconLight  = rowLight .findViewById(R.id.theme_icon);
        iconDark   = rowDark  .findViewById(R.id.theme_icon);
        iconSystem = rowSystem.findViewById(R.id.theme_icon);
    }

    // ══════════════════════════════════════════════════════
    //  Set icons + labels + subtitles per row
    // ══════════════════════════════════════════════════════
    private void setRowContent() {
        // Light row
        iconLight.setImageResource(R.drawable.ic_theme_light);
        setText(rowLight,  R.string.theme_light,  R.string.theme_light_desc);

        // Dark row
        iconDark.setImageResource(R.drawable.ic_theme_dark);
        setText(rowDark,   R.string.theme_dark,   R.string.theme_dark_desc);

        // System row
        iconSystem.setImageResource(R.drawable.ic_theme_system);
        setText(rowSystem, R.string.theme_system, R.string.theme_system_desc);
    }

    private void setText(MaterialCardView row, int titleRes, int subtitleRes) {
        TextView title    = row.findViewById(R.id.title);
        TextView subtitle = row.findViewById(R.id.subtitle);
        if (title    != null) title   .setText(titleRes);
        if (subtitle != null) subtitle.setText(subtitleRes);
    }

    // ══════════════════════════════════════════════════════
    //  WindowInsets — Gesture Navigation padding
    // ══════════════════════════════════════════════════════
    private void applyWindowInsets(View root) {
        ViewCompat.setOnApplyWindowInsetsListener(root, (v, windowInsets) -> {
            Insets nav = windowInsets.getInsets(WindowInsetsCompat.Type.navigationBars());
            int min = dpToPx(28);
            int pad = nav.bottom > 0 ? nav.bottom + dpToPx(8) : min;
            v.setPadding(v.getPaddingLeft(), v.getPaddingTop(),
                         v.getPaddingRight(), Math.max(min, pad));
            return WindowInsetsCompat.CONSUMED;
        });
    }

    // ══════════════════════════════════════════════════════
    //  Pick a theme
    // ══════════════════════════════════════════════════════
    private void onPick(int mode, int nightMode) {
        int current = savedPref();

        // Same mode → just close
        if (current == mode) { dismiss(); return; }

        // Save preference
        PreferenceManager.getDefaultSharedPreferences(requireContext())
                .edit().putInt(PREF_THEME, mode).apply();

        // Animate selection then dismiss + apply
        renderSelection(mode, true);

        rowSystem.postDelayed(() -> {
            dismiss();
            AppCompatDelegate.setDefaultNightMode(nightMode);
        }, DISMISS_DELAY);
    }

    // ══════════════════════════════════════════════════════
    //  Render selection state for all 3 rows
    // ══════════════════════════════════════════════════════
    private void renderSelection(int selected, boolean animate) {
        applyRowState(rowLight,  iconContLight,  iconLight,  checkLight,  selected == 0, animate);
        applyRowState(rowDark,   iconContDark,   iconDark,   checkDark,   selected == 1, animate);
        applyRowState(rowSystem, iconContSystem, iconSystem, checkSystem, selected == 2, animate);
    }

    /**
     * Selected:
     *   card bg   → colorPrimaryContainer  (warm tonal fill)
     *   icon cont → colorPrimary
     *   icon tint → colorOnPrimary (white)
     *   check     → fade in + scale spring
     *   card      → scale up slightly (Expressive spring)
     *
     * Unselected:
     *   card bg   → colorSurfaceContainerLow (neutral)
     *   icon cont → colorSurfaceContainerHighest
     *   icon tint → colorOnSurfaceVariant
     *   check     → fade out
     *   card      → normal scale
     */
    private void applyRowState(MaterialCardView card,
                               MaterialCardView iconCont,
                               ImageView icon,
                               ImageView check,
                               boolean selected,
                               boolean animate) {

        // Colors
        int cardBg  = selected
                ? resolveColor(com.google.android.material.R.attr.colorPrimaryContainer)
                : resolveColor(com.google.android.material.R.attr.colorSurfaceContainerLow);

        int icContBg = selected
                ? resolveColor(android.R.attr.colorPrimary)
                : resolveColor(com.google.android.material.R.attr.colorSurfaceContainerHighest);

        int icTint   = selected
                ? resolveColor(com.google.android.material.R.attr.colorOnPrimary)
                : resolveColor(com.google.android.material.R.attr.colorOnSurfaceVariant);

        int strokeColor = selected
                ? resolveColor(android.R.attr.colorPrimary)
                : resolveColor(com.google.android.material.R.attr.colorOutlineVariant);

        float strokeWidth = selected ? dpToPx(2) : dpToPx(1.5f);

        if (animate) {
            // Card bg + scale spring
            card.setCardBackgroundColor(cardBg);
            card.setStrokeColor(strokeColor);
            card.setStrokeWidth((int) strokeWidth);

            float toScale = selected ? 1.03f : 1.0f;
            card.animate()
                    .scaleX(toScale).scaleY(toScale)
                    .setDuration(ANIM_MS)
                    .setInterpolator(new FastOutSlowInInterpolator())
                    .start();

            // Icon container
            iconCont.setCardBackgroundColor(icContBg);

            // Icon tint
            icon.setColorFilter(icTint);

            // Check mark animation
            animateCheck(check, selected);

        } else {
            // Instant apply (first render)
            card.setCardBackgroundColor(cardBg);
            card.setStrokeColor(strokeColor);
            card.setStrokeWidth((int) strokeWidth);
            iconCont.setCardBackgroundColor(icContBg);
            icon.setColorFilter(icTint);
            check.setAlpha(selected ? 1f : 0f);
            check.setVisibility(selected ? View.VISIBLE : View.GONE);
        }
    }

    // ══════════════════════════════════════════════════════
    //  ✨ Expressive Check Animation — spring scale + fade
    // ══════════════════════════════════════════════════════
    private void animateCheck(ImageView check, boolean show) {
        if (show) {
            check.setVisibility(View.VISIBLE);
            check.setAlpha(0f);
            check.setScaleX(0.5f);
            check.setScaleY(0.5f);

            AnimatorSet set = new AnimatorSet();
            set.playTogether(
                ObjectAnimator.ofFloat(check, "alpha",  0f,    1f),
                ObjectAnimator.ofFloat(check, "scaleX", 0.5f,  1.1f),
                ObjectAnimator.ofFloat(check, "scaleY", 0.5f,  1.1f)
            );
            set.setDuration(ANIM_MS);
            set.setInterpolator(new FastOutSlowInInterpolator());
            set.addListener(new AnimatorListenerAdapter() {
    			@Override
    			public void onAnimationEnd(Animator animation) {
        			set.removeAllListeners(); // مهم لتجنب التكرار

       			 check.animate()
             		   .scaleX(1f)
           		     .scaleY(1f)
           		     .setDuration(80)
             		   .setInterpolator(new FastOutSlowInInterpolator())
            		    .start();
  		  	}
			});
            set.start();

        } else {
            check.animate()
                    .alpha(0f)
                    .scaleX(0.6f).scaleY(0.6f)
                    .setDuration(140)
                    .setInterpolator(new FastOutSlowInInterpolator())
                    .withEndAction(() -> check.setVisibility(View.GONE))
                    .start();
        }
    }

    // ══════════════════════════════════════════════════════
    //  Helpers
    // ══════════════════════════════════════════════════════
    private int savedPref() {
        return PreferenceManager
                .getDefaultSharedPreferences(requireContext())
                .getInt(PREF_THEME, 2);
    }

    private int resolveColor(int attrRes) {
        TypedValue tv = new TypedValue();
        requireContext().getTheme().resolveAttribute(attrRes, tv, true);
        return tv.data;
    }

    private int dpToPx(float dp) {
        return (int) TypedValue.applyDimension(
                TypedValue.COMPLEX_UNIT_DIP, dp,
                requireContext().getResources().getDisplayMetrics());
    }
}
