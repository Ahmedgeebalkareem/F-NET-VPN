package gen.tiger.net.utils;

import android.util.Base64;
import android.util.Log;

import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.security.SecureRandom;
import java.security.spec.KeySpec;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;

/**
 * ══════════════════════════════════════════════════════════════
 *  PortableCryptoHelper — AES-256-GCM with PBKDF2-derived key
 * ══════════════════════════════════════════════════════════════
 *
 *  لماذا هذا الملف؟
 *  ─────────────────────────────────────────────────────────────
 *  Android Keystore (KeystoreHelper) يُولِّد مفتاحاً جديداً عند
 *  إعادة تثبيت التطبيق → البيانات المُشفَّرة قديماً لا تُفَكُّ.
 *
 *  هذا الـ Helper يستخدم مفتاحاً مشتقاً من سرٍّ ثابت مدمج في
 *  التطبيق عبر PBKDF2. النتيجة:
 *  • نفس المفتاح على كل الأجهزة ✓
 *  • نفس المفتاح بعد إعادة التثبيت ✓
 *  • يقبل الكونفيج من أي جهاز مُصدَّر منه ✓
 *
 *  الخوارزميات:
 *  ─────────────────────────────────────────────────────────────
 *  • مشتقة المفتاح : PBKDF2WithHmacSHA256 — 100,000 iteration
 *  • التشفير       : AES-256-GCM (Authenticated Encryption)
 *  • IV            : 12 byte عشوائي لكل عملية تشفير
 *  • GCM Tag       : 128 bit (يكتشف أي تلاعب)
 *
 *  تنسيق البيانات المُشفَّرة (بعد Base64):
 *  ─────────────────────────────────────────────────────────────
 *  [ IV: 12 bytes ] + [ CipherText + GCM Tag ]
 *
 *  ملاحظة أمنية:
 *  ─────────────────────────────────────────────────────────────
 *  الـ salt ثابت → أمان يعتمد على سرية الـ APP_SECRET.
 *  في Release build، Proguard يُشوِّه الأسماء ويُصعِّب الاستخراج.
 *  هذا الحل أفضل من تخزين النص الصريح (plaintext) وأفضل من
 *  Keystore لحالة الاستيراد عبر الأجهزة.
 */
public final class PortableCryptoHelper {

    private static final String TAG = "PortableCrypto";

    // ── سرّ التطبيق — لا يُغيَّر أبداً (يكسر التوافق مع الكونفيجات القديمة)
    private static final char[] APP_SECRET =
            "T1g3rN3tVPN_H4m00dy_2025_S3cur3K3y!@#$".toCharArray();

    // ── salt ثابتة — يجب أن تبقى ثابتة عبر الإصدارات
    private static final byte[] PBKDF2_SALT =
            "TigerNet.v3.PortableSalt.2025".getBytes(StandardCharsets.UTF_8);

    private static final int    PBKDF2_ITERATIONS = 100_000;
    private static final int    KEY_SIZE_BITS      = 256;
    private static final int    IV_BYTES           = 12;
    private static final int    GCM_TAG_BITS       = 128;
    private static final String PBKDF2_ALGO        = "PBKDF2WithHmacSHA256";
    private static final String AES_MODE           = "AES/GCM/NoPadding";

    // المفتاح يُشتق مرة واحدة ويُخزَّن في الذاكرة (lazy init)
    private static volatile SecretKey cachedKey;

    private PortableCryptoHelper() {}

    // ══════════════════════════════════════════════════════════════
    //  Public API
    // ══════════════════════════════════════════════════════════════

    /**
     * يُشفِّر النص ويُعيد: Base64( IV[12] + CipherText )
     * النتيجة متطابقة على كل جهاز وبعد كل تثبيت.
     */
    public static String encrypt(String plainText) throws Exception {
        if (plainText == null) throw new IllegalArgumentException("plainText is null");

        SecretKey key    = getKey();
        Cipher    cipher = Cipher.getInstance(AES_MODE);
        cipher.init(Cipher.ENCRYPT_MODE, key);

        byte[] iv         = cipher.getIV();           // 12 byte عشوائي
        byte[] cipherText = cipher.doFinal(
                plainText.getBytes(StandardCharsets.UTF_8));

        // دمج IV + CipherText
        ByteBuffer buf = ByteBuffer.allocate(IV_BYTES + cipherText.length);
        buf.put(iv);
        buf.put(cipherText);

        return Base64.encodeToString(buf.array(), Base64.NO_WRAP);
    }

    /**
     * يفكّ تشفير نص مُشفَّر بـ {@link #encrypt}.
     * يعمل على أي جهاز وبعد إعادة التثبيت.
     */
    public static String decrypt(String base64Data) throws Exception {
        if (base64Data == null || base64Data.isEmpty())
            throw new IllegalArgumentException("base64Data is empty");

        byte[] combined = Base64.decode(base64Data, Base64.NO_WRAP);

        if (combined.length <= IV_BYTES)
            throw new IllegalArgumentException("Data too short to be valid.");

        byte[] iv         = new byte[IV_BYTES];
        byte[] cipherText = new byte[combined.length - IV_BYTES];
        System.arraycopy(combined, 0,       iv,         0, IV_BYTES);
        System.arraycopy(combined, IV_BYTES, cipherText, 0, cipherText.length);

        SecretKey key    = getKey();
        Cipher    cipher = Cipher.getInstance(AES_MODE);
        cipher.init(Cipher.DECRYPT_MODE, key, new GCMParameterSpec(GCM_TAG_BITS, iv));

        byte[] plain = cipher.doFinal(cipherText);
        return new String(plain, StandardCharsets.UTF_8);
    }

    // ══════════════════════════════════════════════════════════════
    //  إشتقاق المفتاح (Lazy, Thread-safe)
    // ══════════════════════════════════════════════════════════════
    private static SecretKey getKey() throws Exception {
        if (cachedKey != null) return cachedKey;
        synchronized (PortableCryptoHelper.class) {
            if (cachedKey != null) return cachedKey;
            Log.d(TAG, "Deriving portable key (PBKDF2)...");
            SecretKeyFactory factory = SecretKeyFactory.getInstance(PBKDF2_ALGO);
            KeySpec spec = new PBEKeySpec(
                    APP_SECRET, PBKDF2_SALT, PBKDF2_ITERATIONS, KEY_SIZE_BITS);
            byte[] keyBytes = factory.generateSecret(spec).getEncoded();
            cachedKey = new SecretKeySpec(keyBytes, "AES");
            Log.d(TAG, "Portable key derived successfully.");
        }
        return cachedKey;
    }
}
