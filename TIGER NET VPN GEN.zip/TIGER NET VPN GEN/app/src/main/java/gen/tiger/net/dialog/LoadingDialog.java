package gen.tiger.net.dialog;

import gen.tiger.net.R;
import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.TextView;
import androidx.appcompat.app.AlertDialog;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;




public class LoadingDialog {

    private AlertDialog dialog;
    private TextView txtMessage;

    public LoadingDialog(Activity activity, String message) {

        View view = LayoutInflater.from(activity).inflate(R.layout.loading_dialog, null);

        txtMessage = view.findViewById(R.id.txtMessage);
        txtMessage.setText(message);

        dialog = new MaterialAlertDialogBuilder(activity)
                .setView(view)
                .setCancelable(false)
                .create();
    }

    public void show() {
        if (dialog != null && !dialog.isShowing()) {
            dialog.show();

            // ✨ Animation (Material feel)
            if (dialog.getWindow() != null) {
                View decor = dialog.getWindow().getDecorView();
                decor.setScaleX(0.9f);
                decor.setScaleY(0.9f);
                decor.setAlpha(0f);

                decor.animate()
                        .scaleX(1f)
                        .scaleY(1f)
                        .alpha(1f)
                        .setDuration(200)
                        .start();
            }
        }
    }

    public void dismiss() {
        if (dialog != null && dialog.isShowing()) {
            dialog.dismiss();
        }
    }

    // 🔥 تغيير النص أثناء التشغيل (مهم للـ VPN)
    public void setMessage(String message) {
        if (txtMessage != null) {
            txtMessage.setText(message);
        }
    }

    // اختياري
    public void setCancelable(boolean cancelable) {
        if (dialog != null) {
            dialog.setCancelable(cancelable);
        }
    }
}