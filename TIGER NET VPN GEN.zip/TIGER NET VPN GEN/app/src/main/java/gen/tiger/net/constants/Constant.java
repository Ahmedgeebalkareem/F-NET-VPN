package gen.tiger.net.constants;

/** Holds all constant values used across the app */
public final class Constant {

    private Constant() { /* no instances */ }

    // ══════════════════════════════════════════════════════════════
    //  VPN Connection Modes
    // ══════════════════════════════════════════════════════════════
    public static final class Mode {
        public static final int SSH_DIRECT              = 0;
        public static final int SSH_DIRECT_WITH_PAYLOAD = 1;
        public static final int SSH_HTTP_PROXY          = 2;
        public static final int SSL_DIRECT              = 3;
        public static final int SSL_DIRECT_WITH_PAYLOAD = 4;
        public static final int SSL_HTTP_PROXY          = 5;
        public static final int UDP                     = 6;
        public static final int OVPN_DIRECT_UDP         = 7;
        public static final int V2RAY                   = 8;

        private Mode() {}
    }

    // ══════════════════════════════════════════════════════════════
    //  JSON Keys
    // ══════════════════════════════════════════════════════════════
    public static final class Key {
        public static final String V2RAY_JSON       = "V2_JSON";
        public static final String SERVER_NAME      = "SERVER_NAME";
        public static final String SERVER_IP        = "ServerIPHost";
        public static final String OVPN_PORT        = "OVPN_PORT";
        public static final String SSH_PORT         = "SSH_PORT";
        public static final String SSL_PORT         = "SSL_PORT";
        public static final String NETWORK_NAME     = "NETWORK_NAME";
        public static final String NETWORK_MSG      = "NETWORK_MSG";
        public static final String NETWORK_PAYLOAD  = "NETWORK_PAYLOAD";
        public static final String SSL_NETWORK_NAME = "SSL_NETWORK_NAME";
        public static final String SSL_NETWORK_MSG  = "SSL_MESSAGE";
        public static final String SSL_SNI          = "SSL_SNI";
        public static final String VERSION          = "JSON_VERSION";
        public static final String JSON             = "JSON";

        private Key() {}
    }

    // ══════════════════════════════════════════════════════════════
    //  Default Ports
    // ══════════════════════════════════════════════════════════════
    public static final class Port {
        public static final int OVPN = 1194;
        public static final int SSH  = 22;
        public static final int SSL  = 443;

        private Port() {}
    }
}