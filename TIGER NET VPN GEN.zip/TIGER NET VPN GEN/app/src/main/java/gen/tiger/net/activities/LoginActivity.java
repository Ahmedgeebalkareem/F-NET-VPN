package gen.tiger.net.activities;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.preference.PreferenceManager;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputLayout;

import gen.tiger.net.MyApplication;
import gen.tiger.net.R;

public class LoginActivity extends AppCompatActivity {

    private MaterialButton  loginBtn;
    private TextInputLayout textInputLayout;
    private EditText        editText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(this);

        editText        = findViewById(R.id.admin_login);
        loginBtn        = findViewById(R.id.loginBtn);
        textInputLayout = findViewById(R.id.passwordInputLayout);

        // ✨ Fade-in animation
        View root = findViewById(android.R.id.content);
        root.setAlpha(0f);
        root.animate().alpha(1f).setDuration(500).start();

        // تسجيل دخول تلقائي إذا كانت الجلسة محفوظة
        if (prefs.getString("Admin", "").equals(MyApplication.PASSCODE)) {
            goToMain();
            return;
        }

        // ✨ IME action — الضغط على "Done" في الكيبورد يُشغّل Login
        editText.setImeActionLabel("Login", EditorInfo.IME_ACTION_DONE);
        editText.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_DONE
                    || (event != null
                        && event.getKeyCode() == KeyEvent.KEYCODE_ENTER
                        && event.getAction() == KeyEvent.ACTION_DOWN)) {
                hideKeyboard();
                attemptLogin(prefs);
                return true;
            }
            return false;
        });

        // ✨ مسح الخطأ عند الكتابة
        editText.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                textInputLayout.setError(null);
                // ✨ تفعيل الزر فقط عند وجود نص
                loginBtn.setEnabled(s.length() > 0);
            }
            @Override public void afterTextChanged(Editable s) {}
        });

        // الزر غير مفعّل عند البداية إذا الحقل فارغ
        loginBtn.setEnabled(false);

        loginBtn.setOnClickListener(v -> {
            hideKeyboard();
            attemptLogin(prefs);
        });
    }

    // ══════════════════════════════════════════════════════════════
    //  ✨ منطق تسجيل الدخول مُجمَّع في دالة واحدة
    // ══════════════════════════════════════════════════════════════
    private void attemptLogin(SharedPreferences prefs) {
        String password = editText.getText() != null
                ? editText.getText().toString().trim() : "";

        textInputLayout.setError(null);

        if (password.isEmpty()) {
            textInputLayout.setError("Enter password");
            editText.requestFocus();
            return;
        }

        if (password.equals(MyApplication.PASSCODE)) {
            // ✅ كلمة مرور صحيحة
            prefs.edit().putString("Admin", password).apply();

            loginBtn.setEnabled(false);
            loginBtn.setText("Loading…");

            // ✨ Delay قصير ليرى المستخدم "Loading" قبل الانتقال
            loginBtn.postDelayed(this::goToMain, 150);

        } else {
            // ❌ كلمة مرور خاطئة
            textInputLayout.setError("Wrong password");
            // ✨ Shake animation على حقل الإدخال
            shakeView(textInputLayout);
            editText.selectAll();
        }
    }

    private void goToMain() {
        startActivity(new Intent(this, MainActivity.class));
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
        finish();
    }

    // ✨ Shake animation — للإشارة للخطأ بصرياً
    private void shakeView(View view) {
        android.animation.ObjectAnimator shake = android.animation.ObjectAnimator.ofFloat(
                view, "translationX", 0f, -16f, 16f, -12f, 12f, -8f, 8f, 0f);
        shake.setDuration(400);
        shake.start();
    }

    private void hideKeyboard() {
        View current = getCurrentFocus();
        if (current != null) {
            InputMethodManager imm = (InputMethodManager)
                    getSystemService(INPUT_METHOD_SERVICE);
            if (imm != null)
                imm.hideSoftInputFromWindow(current.getWindowToken(), 0);
        }
    }
}
