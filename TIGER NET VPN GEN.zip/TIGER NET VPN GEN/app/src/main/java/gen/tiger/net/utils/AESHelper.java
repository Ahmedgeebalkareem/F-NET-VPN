package gen.tiger.net.utils;

import android.util.Base64;
import android.util.Log;

import java.nio.charset.StandardCharsets;
import java.security.GeneralSecurityException;
import java.security.MessageDigest;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

/**
 * AES-256-CBC encryption/decryption helper.
 * Key is derived from a password using SHA-256.
 * IV is a fixed zero-byte array (16 bytes).
 */
public final class AESHelper {

    private static final String TAG          = "AESHelper";
    private static final String AES_MODE     = "AES/CBC/PKCS7Padding";
    private static final String HASH_ALGO    = "SHA-256";
    private static final byte[] IV           = new byte[16]; // fixed zero IV

    public static boolean DEBUG = false;

    private AESHelper() {}

    // ══════════════════════════════════════════════════════════════
    //  Public API
    // ══════════════════════════════════════════════════════════════

    /**
     * Encrypts a plain text string and returns a Base64-encoded cipher text.
     */
    public static String encrypt(String password, String plainText)
            throws GeneralSecurityException {
        SecretKeySpec key = deriveKey(password);
        Cipher cipher = buildCipher(Cipher.ENCRYPT_MODE, key);
        byte[] cipherBytes = cipher.doFinal(plainText.getBytes(StandardCharsets.UTF_8));
        String result = Base64.encodeToString(cipherBytes, Base64.NO_WRAP);
        log("encrypt", result);
        return result;
    }

    /**
     * Decrypts a Base64-encoded cipher text and returns the plain text string.
     */
    public static String decrypt(String password, String base64CipherText)
            throws GeneralSecurityException {
        SecretKeySpec key = deriveKey(password);
        Cipher cipher = buildCipher(Cipher.DECRYPT_MODE, key);
        byte[] decoded = Base64.decode(base64CipherText, Base64.NO_WRAP);
        byte[] plain   = cipher.doFinal(decoded);
        return new String(plain, StandardCharsets.UTF_8);
    }

    // ══════════════════════════════════════════════════════════════
    //  Private Helpers
    // ══════════════════════════════════════════════════════════════

    private static SecretKeySpec deriveKey(String password)
            throws GeneralSecurityException {
        try {
            MessageDigest digest = MessageDigest.getInstance(HASH_ALGO);
            byte[] keyBytes = digest.digest(password.getBytes(StandardCharsets.UTF_8));
            log("key", bytesToHex(keyBytes));
            return new SecretKeySpec(keyBytes, "AES");
        } catch (GeneralSecurityException e) {
            logError("deriveKey failed", e);
            throw e;
        }
    }

    private static Cipher buildCipher(int mode, SecretKeySpec key)
            throws GeneralSecurityException {
        Cipher cipher = Cipher.getInstance(AES_MODE);
        cipher.init(mode, key, new IvParameterSpec(IV));
        return cipher;
    }

    private static String bytesToHex(byte[] bytes) {
        char[] hex   = "0123456789ABCDEF".toCharArray();
        char[] chars = new char[bytes.length * 2];
        for (int i = 0; i < bytes.length; i++) {
            int v = bytes[i] & 0xFF;
            chars[i * 2]     = hex[v >>> 4];
            chars[i * 2 + 1] = hex[v & 0x0F];
        }
        return new String(chars);
    }

    private static void log(String label, String value) {
        if (DEBUG) Log.d(TAG, label + ": " + value);
    }

    private static void logError(String msg, Exception e) {
        if (DEBUG) Log.e(TAG, msg, e);
    }
}