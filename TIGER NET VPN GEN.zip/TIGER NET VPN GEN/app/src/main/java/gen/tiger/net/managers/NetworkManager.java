package gen.tiger.net.managers;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.util.Log;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.preference.PreferenceManager;

import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.android.material.textfield.MaterialAutoCompleteTextView;

import gen.tiger.net.activities.NetworkActivity;
import gen.tiger.net.constants.Constant;
import gen.tiger.net.models.Config;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.List;

/**
 * NetworkManager — مدير عمليات الشبكات (HTTP) مسؤول عن: إضافة / تعديل / حذف / عرض الشبكات معزول
 * تماماً عن MainActivity
 */
public class NetworkManager {

    private static final String TAG = "NetworkManager";

    // ── Dependencies ───────────────────────────────────────────────
    private final AppCompatActivity activity;
    private final Context context;
    private final Config json;
    private final SharedPreferences prefs;
    // BUG-GEN-1: REMOVED shared Editor field.
    // SharedPreferences.Editor is NOT thread-safe — its internal HashMap is
    // corrupted when two threads call putX() simultaneously.
    // Each write now creates its own fresh editor via prefs.edit().
    // private final SharedPreferences.Editor editor;  ← DELETED

    // ── UI المرتبطة بالشبكة في MainActivity ──────────────────────
    private final MaterialAutoCompleteTextView networkDropdown;
    private final List<String> networkList;

    // ── Callback للإشعار بالتغييرات ───────────────────────────────
    private final OnNetworkChangedListener listener;

    // ── Launcher للصفحة ───────────────────────────────────────────
    private JSONObject lastDeletedItem = null;
    private int lastDeletedPosition = -1;
    private ActivityResultLauncher<Intent> networkLauncher;

    // ── حفظ موضع الشبكة عند التعديل ──────────────────────────────
    private int pendingEditPosition = -1;

    // ══════════════════════════════════════════════════════════════
    //  Interface — Callback
    // ══════════════════════════════════════════════════════════════
    public interface OnNetworkChangedListener {
        void onNetworkAdded(String networkName);

        void onNetworkEdited(String networkName);

        void onNetworkDeleted(String name, Runnable undoAction);

        void refreshDropdown();
    }

    // ══════════════════════════════════════════════════════════════
    //  Constructor
    // ══════════════════════════════════════════════════════════════
    public NetworkManager(
            AppCompatActivity activity,
            MaterialAutoCompleteTextView networkDropdown,
            List<String> networkList,
            OnNetworkChangedListener listener) {

        this.activity = activity;
        this.context = activity.getApplicationContext();
        this.json = Config.getInstance(activity);
        this.prefs = PreferenceManager.getDefaultSharedPreferences(activity);
        // BUG-GEN-1: No shared editor — each write uses a fresh prefs.edit() call
        this.networkDropdown = networkDropdown;
        this.networkList = networkList;
        this.listener = listener;

        registerLauncher();
    }

    // ══════════════════════════════════════════════════════════════
    //  تسجيل Launcher
    // ══════════════════════════════════════════════════════════════
    private void registerLauncher() {
        networkLauncher =
                activity.registerForActivityResult(
                        new ActivityResultContracts.StartActivityForResult(),
                        result -> {
                            if (result.getResultCode() == AppCompatActivity.RESULT_OK
                                    && result.getData() != null) {
                                handleNetworkResult(result.getData());
                            }
                        });
    }

    // ══════════════════════════════════════════════════════════════
    //  معالجة النتيجة القادمة من NetworkActivity
    // ══════════════════════════════════════════════════════════════
    private void handleNetworkResult(Intent data) {
        try {
            String jsonStr = data.getStringExtra("network_data");
            boolean isEdit = data.getBooleanExtra("is_edit", false);

            if (jsonStr == null) {
                Log.e(TAG, "Network data is null");
                toast("Invalid data received");
                return;
            }
            JSONObject jsObj = new JSONObject(jsonStr);
            String name = jsObj.optString("Name", "");

            saveToPrefs(jsObj);

            if (isEdit && pendingEditPosition >= 0) {
                if (pendingEditPosition < json.getNetworkArray().length()) {
                    json.getNetworkArray().put(pendingEditPosition, jsObj);
                }
                pendingEditPosition = -1;
                listener.onNetworkEdited(name);
            } else {
                json.addNetwork(jsObj);
                listener.onNetworkAdded(name);
            }

            listener.refreshDropdown();
            networkDropdown.setText(name, false);

        } catch (JSONException e) {
            Log.e(TAG, "handleNetworkResult: " + e.getMessage(), e);
            toast("Error saving network: " + e.getMessage());
        }
    }

    // ══════════════════════════════════════════════════════════════
    //  إضافة شبكة جديدة
    // ══════════════════════════════════════════════════════════════
    public void addNetwork() {
        pendingEditPosition = -1;
        Intent intent = new Intent(activity, NetworkActivity.class);
        intent.putExtra("is_edit", false);
        networkLauncher.launch(intent);
    }

    // ══════════════════════════════════════════════════════════════
    //  تعديل شبكة موجودة
    // ══════════════════════════════════════════════════════════════
    public void editNetwork() {
        int position = getSelectedPosition();
        if (position == -1) {
            toast("Please select a network first");
            return;
        }
        try {
            JSONObject network = json.getNetworkArray().getJSONObject(position);
            pendingEditPosition = position;

            Intent intent = new Intent(activity, NetworkActivity.class);
            intent.putExtra("is_edit", true);
            intent.putExtra("network_json", network.toString());
            networkLauncher.launch(intent);

        } catch (JSONException e) {
            Log.e(TAG, "editNetwork: " + e.getMessage(), e);
            toast("Error loading network data");
        }
    }

    // ══════════════════════════════════════════════════════════════
    //  حذف شبكة
    // ══════════════════════════════════════════════════════════════
    public void deleteNetwork() {
        int position = getSelectedPosition();
        if (position == -1) {
            toast("Please select a network first");
            return;
        }
        String selectedName = networkDropdown.getText().toString();

        new MaterialAlertDialogBuilder(activity)
                .setTitle("Delete Network")
                .setMessage("Are you sure you want to delete this network?")
                .setPositiveButton(
                        "Delete",
                        (dialog, which) -> {
                            if (position < json.getNetworkArray().length()) {
                                try {
                                    lastDeletedItem =
                                            new JSONObject(
                                                    json.getNetworkArray()
                                                            .getJSONObject(position)
                                                            .toString());
                                } catch (JSONException ignored) {
                                    lastDeletedItem = null;
                                }
                                lastDeletedPosition = position;
                                json.getNetworkArray().remove(position);
                                Runnable undoAction =
                                        () -> {
                                            if (lastDeletedItem != null) undoDelete();
                                        };
                                listener.onNetworkDeleted(selectedName, undoAction);
                                listener.refreshDropdown();
                                int newSize = json.getNetworkArray().length();
                                if (newSize > 0) {
                                    int newPos = Math.max(0, position - 1);
                                    try {
                                        String prevName =
                                                json.getNetworkArray()
                                                        .getJSONObject(newPos)
                                                        .optString("Name", "");
                                        networkDropdown.setText(prevName, false);
                                    } catch (JSONException e) {
                                        networkDropdown.setText("", false);
                                    }
                                } else {
                                    networkDropdown.setText("", false);
                                }
                            }
                        })
                .setNegativeButton("Cancel", null)
                .show();
    }

    // ══════════════════════════════════════════════════════════════
    //  الحصول على موضع الشبكة المحددة
    public int getSelectedPosition() {
        String selected = networkDropdown.getText().toString().trim();
        if (selected.isEmpty()) return -1;
        for (int i = 0; i < json.getNetworkArray().length(); i++) {
            JSONObject obj = json.getNetworkArray().optJSONObject(i);
            if (obj != null && selected.equals(obj.optString("Name"))) {
                return i;
            }
        }
        return -1;
    }

    // ══════════════════════════════════════════════════════════════
    //  الحصول على بيانات الشبكة المحددة
    // ══════════════════════════════════════════════════════════════
    public JSONObject getSelectedNetwork() {
        int position = getSelectedPosition();
        if (position == -1) return null;
        try {
            return json.getNetworkArray().getJSONObject(position);
        } catch (JSONException e) {
            return null;
        }
    }

    // ══════════════════════════════════════════════════════════════
    //  حفظ في SharedPreferences
    // ══════════════════════════════════════════════════════════════
    private void saveToPrefs(JSONObject jsObj) {
        try {
            // BUG-GEN-1: Use fresh editor each time (thread-safe)
            prefs.edit()
                 .putString(Constant.Key.NETWORK_NAME, jsObj.optString("Name", ""))
                 .putString(Constant.Key.NETWORK_MSG,  jsObj.optString("Info", ""))
                 .putString("DefHttpPort",
                         jsObj.optJSONObject("ProxySettings") != null
                                 ? jsObj.getJSONObject("ProxySettings").optString("Port", "")
                                 : "")
                 .apply();
        } catch (JSONException e) {
            Log.e(TAG, "saveToPrefs: " + e.getMessage(), e);
        }
    }

    // ══════════════════════════════════════════════════════════════
    //  Helper
    // ══════════════════════════════════════════════════════════════
    private void toast(String msg) {
        Toast.makeText(activity, msg, Toast.LENGTH_SHORT).show();
    }

    // ══════════════════════════════════════════════════════════════
    //  Undo آخر حذف
    // ══════════════════════════════════════════════════════════════
    public void undoDelete() {
        if (lastDeletedItem == null) return;
        try {
            JSONArray arr = json.getNetworkArray();
            JSONArray rebuilt = new JSONArray();
            for (int i = 0;
                    i < (lastDeletedPosition < arr.length() ? lastDeletedPosition : arr.length());
                    i++) rebuilt.put(arr.opt(i));
            rebuilt.put(lastDeletedItem);
            int start = Math.min(lastDeletedPosition, arr.length());
            for (int i = start; i < arr.length(); i++) rebuilt.put(arr.opt(i));
            while (arr.length() > 0) arr.remove(0);
            for (int i = 0; i < rebuilt.length(); i++) {
                try {
                    arr.put(rebuilt.getJSONObject(i));
                } catch (Exception ignored) {
                }
            }
            String restoredName = lastDeletedItem.optString("Name", "");
            lastDeletedItem = null;
            lastDeletedPosition = -1;
            listener.refreshDropdown();
            networkDropdown.setText(restoredName, false);
        } catch (Exception e) {
            android.util.Log.e("Manager", "undoDelete failed", e);
        }
    }
}