package gen.tiger.net.activities;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Toast;
import android.widget.TextView;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.color.DynamicColors;
import com.google.android.material.appbar.CollapsingToolbarLayout;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.card.MaterialCardView;
import com.google.android.material.materialswitch.MaterialSwitch;
import com.google.android.material.button.MaterialButtonToggleGroup;
import com.google.android.material.floatingactionbutton.ExtendedFloatingActionButton;
import com.google.android.material.textfield.MaterialAutoCompleteTextView;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.Arrays;
import java.util.List;

import gen.tiger.net.R;
import gen.tiger.net.constants.Constant;

public class NetworkActivity extends AppCompatActivity {

    private static final String TAG = "NetworkActivity";

    // ── Generator types — يُحدَّد قبل الإطلاق لمعرفة مفتاح الـ result ──
    private static final int GEN_PAYLOAD = 0;   // PayloadGeneratorActivity → "payload"
    private static final int GEN_UDP     = 1;   // UDPActivity             → "udp_data"
    private static final int GEN_V2RAY   = 2;   // V2RayActivity           → "v2ray_data"

    // ── Views ──────────────────────────────────────────────────────
    private MaterialToolbar              toolbar;
    private TextInputLayout              payloadLayoutText;
    private TextInputEditText            nameEditText;
    private TextInputEditText            payloadEditText;
    private TextInputEditText            infoEditText;
    private TextInputEditText            proxyEditText;
    private TextInputEditText            proxyPortEditText;
    private TextInputEditText            frontQueryEditText;
    private TextInputEditText            backQueryEditText;
    private MaterialSwitch               useDefaultProxySwitch;
    private MaterialAutoCompleteTextView tunnelModeSpinner;
    private MaterialAutoCompleteTextView prioritySpinner;
    private MaterialButtonToggleGroup    segmentGroup;
    private ExtendedFloatingActionButton fab;
    private MaterialCardView             serverTypeCard;
    private View                         selectServer, proxySettings;
    private View                         udpLayout;

    // ── Data ───────────────────────────────────────────────────────
    private List<String> priorityOptions;
    private List<String> tunnelModeOptions;
    private boolean      isEdit;

    /**
     * نوع الـ Generator الأخير الذي أُطلق.
     * يُستخدم في callback لقراءة المفتاح الصحيح من الـ Intent.
     */
    private int lastLaunchedGeneratorType = GEN_PAYLOAD;

    // ── Generator Launcher ─────────────────────────────────────────
    private ActivityResultLauncher<Intent> generatorLauncher;

    // ══════════════════════════════════════════════════════════════
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        DynamicColors.applyToActivityIfAvailable(this);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fragment_network);

        registerGeneratorLauncher();
        bindViews();
        setupToolbar();
        setupAdapters();
        setupListeners();
        fillData();
    }

    // ══════════════════════════════════════════════════════════════
    //  تسجيل Generator Launcher — FIX: معالجة مفاتيح الـ 3 generators
    // ══════════════════════════════════════════════════════════════
    private void registerGeneratorLauncher() {
        generatorLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() != RESULT_OK || result.getData() == null) return;

                    Intent data    = result.getData();
                    String payload = null;

                    // ═══════════════════════════════════════════════════════
                    //  FIX #1: كل Generator يُرسل مفتاحاً مختلفاً.
                    //  - PayloadGeneratorActivity → "payload"
                    //  - UDPActivity              → "udp_data"   (كان مفقوداً)
                    //  - V2RayActivity            → "v2ray_data" (كان مفقوداً)
                    //  نستخدم lastLaunchedGeneratorType لقراءة المفتاح الصحيح.
                    // ═══════════════════════════════════════════════════════
                    switch (lastLaunchedGeneratorType) {
                        case GEN_UDP:
                            payload = data.getStringExtra("udp_data");
                            break;
                        case GEN_V2RAY:
                            payload = data.getStringExtra("v2ray_data");
                            break;
                        case GEN_PAYLOAD:
                        default:
                            payload = data.getStringExtra("payload");
                            break;
                    }

                    if (payload != null && !payload.isEmpty()) {
                        payloadEditText.setText(payload);
                        Log.d(TAG, "Generator returned payload (" +
                                generatorTypeName(lastLaunchedGeneratorType) + "): " +
                                payload.length() + " chars");
                    } else {
                        Log.w(TAG, "Generator returned null/empty payload for type: "
                                + generatorTypeName(lastLaunchedGeneratorType));
                    }
                });
    }

    // ══════════════════════════════════════════════════════════════
    //  ربط الـ Views
    // ══════════════════════════════════════════════════════════════
    private void bindViews() {
        toolbar               = findViewById(R.id.toolbar);
        nameEditText          = findViewById(R.id.network_name_dialog);
        payloadLayoutText     = findViewById(R.id.etNetworkPayloadInput);
        payloadEditText       = findViewById(R.id.network_payload_dialog);
        infoEditText          = findViewById(R.id.network_info_dialog);
        proxyEditText         = findViewById(R.id.network_proxy_ip);
        proxyPortEditText     = findViewById(R.id.network_proxy_port);
        frontQueryEditText    = findViewById(R.id.network_front_query);
        backQueryEditText     = findViewById(R.id.network_back_query);
        useDefaultProxySwitch = findViewById(R.id.use_default_proxy);
        tunnelModeSpinner     = findViewById(R.id.proto_spin);
        prioritySpinner       = findViewById(R.id.priority_spin);
        segmentGroup          = findViewById(R.id.segment_server_type);
        fab                   = findViewById(R.id.generate);
        serverTypeCard        = findViewById(R.id.card_server_type);
        selectServer          = findViewById(R.id.server_title);
        proxySettings         = findViewById(R.id.proxy_title);
        udpLayout             = findViewById(R.id.excluded_udp_layout);
    }

    // ══════════════════════════════════════════════════════════════
    //  إعداد الـ Toolbar
    // ══════════════════════════════════════════════════════════════
    private void setupToolbar() {
        setSupportActionBar(toolbar);
        toolbar.setNavigationOnClickListener(v -> finish());
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_network, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.action_payload_gen) {
            openGenerator();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    // ══════════════════════════════════════════════════════════════
    //  إعداد الـ Adapters
    // ══════════════════════════════════════════════════════════════
    private void setupAdapters() {
        priorityOptions   = Arrays.asList("PRIORITY LOW", "PRIORITY MEDIUM", "PRIORITY HIGH");
        tunnelModeOptions = Arrays.asList("HTTP PROXY", "HYSTERIA UDP", "V2RAY");

        prioritySpinner.setAdapter(
                new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, priorityOptions));
        tunnelModeSpinner.setAdapter(
                new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, tunnelModeOptions));

        prioritySpinner.setText(priorityOptions.get(0),    false);
        tunnelModeSpinner.setText(tunnelModeOptions.get(0), false);
    }

    // ══════════════════════════════════════════════════════════════
    //  إعداد الـ Listeners
    // ══════════════════════════════════════════════════════════════
    private void setupListeners() {

        useDefaultProxySwitch.setOnCheckedChangeListener((btn, isChecked) -> {
            proxyEditText.setEnabled(!isChecked);
            proxyEditText.setText(isChecked ? "[DEFAULT]" : "");
        });

        tunnelModeSpinner.setOnItemClickListener((parent, view, position, id) ->
                updateTunnelVisibility(position));

        segmentGroup.addOnButtonCheckedListener((group, checkedId, isChecked) -> {
            if (!isChecked) return;
            String type = "cf";
            if      (checkedId == R.id.btn_ws)   type = "ws";
            else if (checkedId == R.id.btn_http)  type = "http";
            Log.d(TAG, "ServerType selected: " + type);
        });

        fab.setOnClickListener(v -> saveAndReturn());
    }

    // ══════════════════════════════════════════════════════════════
    //  تعبئة البيانات من الـ Intent
    // ══════════════════════════════════════════════════════════════
    private void fillData() {
        Intent intent = getIntent();
        isEdit = intent.getBooleanExtra("is_edit", false);

        CollapsingToolbarLayout ctl = (CollapsingToolbarLayout) toolbar.getParent();

        if (!isEdit) {
            if (ctl != null) ctl.setTitle("Add NETWORK");
            useDefaultProxySwitch.setChecked(true);
            proxyEditText.setText("[DEFAULT]");
            proxyEditText.setEnabled(false);
            segmentGroup.check(R.id.btn_cf);
            updateTunnelVisibility(0);
            return;
        }

        if (ctl != null) ctl.setTitle("Edit NETWORK");

        try {
            String json = intent.getStringExtra("network_json");
            if (json == null || json.isEmpty()) return;

            JSONObject network = new JSONObject(json);

            nameEditText.setText(network.optString("Name", ""));
            infoEditText.setText(network.optString("Info", ""));
            frontQueryEditText.setText(network.optString("FrontQuery", ""));
            backQueryEditText.setText(network.optString("BackQuery", ""));
            
            // Payload — مشفّر في JSON
            try {
                payloadEditText.setText(
                        MainActivity.decrypt(network.optString("Payload", "")));
            } catch (Exception ignored) {}

            // Proxy Settings
            if (network.has("ProxySettings")) {
                JSONObject proxy = network.getJSONObject("ProxySettings");
                proxyPortEditText.setText(proxy.optString("Port", ""));
                try {
                    String squid    = MainActivity.decrypt(proxy.optString("Squid", ""));
                    boolean isDef   = squid != null && squid.contains("Default");
                    useDefaultProxySwitch.setChecked(isDef);
                    proxyEditText.setText(isDef ? "[DEFAULT]" : squid);
                    proxyEditText.setEnabled(!isDef);
                } catch (Exception ignored) {}
            }

            // Server Type
            String serverType = network.optString("ServerHostDNS", "cf");
            int btnId = R.id.btn_cf;
            if      ("ws".equals(serverType))   btnId = R.id.btn_ws;
            else if ("http".equals(serverType)) btnId = R.id.btn_http;
            segmentGroup.check(btnId);

            // Priority
            int priorityIndex = network.optInt("Priority", 0);
            if (priorityIndex >= 0 && priorityIndex < priorityOptions.size())
                prioritySpinner.setText(priorityOptions.get(priorityIndex), false);

            // TunnelType
            int tunnelType = network.optInt("TunnelType", Constant.Mode.SSH_HTTP_PROXY);
            int spinnerPos = tunnelType == Constant.Mode.SSH_HTTP_PROXY ? 0
                           : tunnelType == Constant.Mode.UDP            ? 1 : 2;
            tunnelModeSpinner.setText(tunnelModeOptions.get(spinnerPos), false);
            updateTunnelVisibility(spinnerPos);

        } catch (Exception e) {
            Log.e(TAG, "fillData: " + e.getMessage(), e);
        }
    }

    // ══════════════════════════════════════════════════════════════
    //  إخفاء/إظهار حقول الـ Tunnel
    // ══════════════════════════════════════════════════════════════
    private void updateTunnelVisibility(int position) {
        boolean isHttpProxy = (position == 0);
        int vis = isHttpProxy ? View.VISIBLE : View.GONE;
        udpLayout.setVisibility(vis);
        serverTypeCard.setVisibility(vis);
        selectServer.setVisibility(vis);
        proxySettings.setVisibility(vis);

        switch (position) {
            case 1:  payloadLayoutText.setHint(getString(R.string.udp_title));    break;
            case 2:  payloadLayoutText.setHint(getString(R.string.v2ray_config)); break;
            default: payloadLayoutText.setHint(getString(R.string.payload));      break;
        }
    }

    // ══════════════════════════════════════════════════════════════
    //  التحقق من صحة المدخلات
    // ══════════════════════════════════════════════════════════════
    private boolean validate() {
        if (getText(nameEditText).isEmpty()) {
            nameEditText.setError("Required");
            nameEditText.requestFocus();
            return false;
        }
        if (getText(payloadEditText).isEmpty()) {
            payloadEditText.setError("Required");
            payloadEditText.requestFocus();
            return false;
        }

        // التحقق من Proxy فقط في وضع HTTP
        if (tunnelModeSpinner.getText().toString().equals(tunnelModeOptions.get(0))) {
            String proxy = getText(proxyEditText);
            String port  = getText(proxyPortEditText);
            if (proxy.isEmpty() || proxy.equals("[DEFAULT]")) {
                proxyEditText.setError("Required");
                proxyEditText.requestFocus();
                return false;
            }
            if (port.isEmpty() || !port.matches("\\d+")) {
                proxyPortEditText.setError("Required");
                proxyPortEditText.requestFocus();
                return false;
            }
        }

        // Front و Back لا يُملآن معاً
        if (!getText(frontQueryEditText).isEmpty() && !getText(backQueryEditText).isEmpty()) {
            toast("Only one of Front or Back query should be filled");
            return false;
        }

        return true;
    }

    // ══════════════════════════════════════════════════════════════
    //  حفظ وإرجاع
    // ══════════════════════════════════════════════════════════════
    private void saveAndReturn() {
        if (!validate()) return;
        try {
            JSONObject networkJson = buildNetworkJson();
            Intent result = new Intent();
            result.putExtra("network_data", networkJson.toString());
            result.putExtra("is_edit", isEdit);
            setResult(RESULT_OK, result);
            finish();
        } catch (JSONException e) {
            Log.e(TAG, "saveAndReturn: " + e.getMessage(), e);
            toast("Error: " + e.getMessage());
        }
    }

    // ══════════════════════════════════════════════════════════════
    //  بناء JSONObject
    // ══════════════════════════════════════════════════════════════
    private JSONObject buildNetworkJson() throws JSONException {
        JSONObject obj = new JSONObject();
        obj.put("Name",       getText(nameEditText));
        obj.put("Info",       getText(infoEditText));
        obj.put("FrontQuery", getText(frontQueryEditText));
        obj.put("BackQuery",  getText(backQueryEditText));

        // Payload مشفّر
        try { obj.put("Payload", MainActivity.encrypt(getText(payloadEditText))); }
        catch (Exception ignored) {}

        // TunnelType
        String tunnelMode = tunnelModeSpinner.getText().toString();
        int tunnelType = tunnelMode.equals(tunnelModeOptions.get(0)) ? Constant.Mode.SSH_HTTP_PROXY
                       : tunnelMode.equals(tunnelModeOptions.get(1)) ? Constant.Mode.UDP
                       : Constant.Mode.V2RAY;
        obj.put("TunnelType", tunnelType);

        // Priority
        obj.put("Priority", priorityOptions.indexOf(prioritySpinner.getText().toString()));

        // Server Host DNS
        int selectedId = segmentGroup.getCheckedButtonId();
        String dns = "cf";
        if      (selectedId == R.id.btn_ws)   dns = "ws";
        else if (selectedId == R.id.btn_http)  dns = "http";
        obj.put("ServerHostDNS", dns);

        // Proxy Settings
        JSONObject proxyObj = new JSONObject();
        String proxy = useDefaultProxySwitch.isChecked() ? "Default" : getText(proxyEditText);
        try { proxyObj.put("Squid", MainActivity.encrypt(proxy)); }
        catch (Exception ignored) {}
        proxyObj.put("Port", getText(proxyPortEditText));
        obj.put("ProxySettings", proxyObj);

        return obj;
    }

    // ══════════════════════════════════════════════════════════════
    //  فتح Generator المناسب حسب وضع الـ Tunnel
    // ══════════════════════════════════════════════════════════════
    private void openGenerator() {
        String mode           = tunnelModeSpinner.getText().toString();
        String currentPayload = getText(payloadEditText);
        boolean hasPayload    = !currentPayload.isEmpty();

        Intent intent;

        if (mode.equals(tunnelModeOptions.get(0))) {
            // ── HTTP PROXY → PayloadGeneratorActivity ─────────────────
            lastLaunchedGeneratorType = GEN_PAYLOAD;
            intent = new Intent(this, PayloadGeneratorActivity.class);
            if (hasPayload) {
                intent.putExtra("payload", currentPayload);
                intent.putExtra("is_edit", true);
            }

        } else if (mode.equals(tunnelModeOptions.get(1))) {
            // ── HYSTERIA UDP → UDPActivity ────────────────────────────
            lastLaunchedGeneratorType = GEN_UDP;
            intent = new Intent(this, UDPActivity.class);
            if (hasPayload) {
                // ═══════════════════════════════════════════════════════
                //  FIX #2: UDPActivity يتوقع "udp_data" وليس "payload".
                //  نُمرّر البيانات الحالية تحت المفتاح الصحيح لتفعيل التعديل.
                // ═══════════════════════════════════════════════════════
                intent.putExtra("udp_data", currentPayload);
                intent.putExtra("is_edit", true);
            }

        } else {
            // ── V2RAY → V2RayActivity ─────────────────────────────────
            lastLaunchedGeneratorType = GEN_V2RAY;
            intent = new Intent(this, V2RayActivity.class);
            if (hasPayload) {
                // ═══════════════════════════════════════════════════════
                //  FIX #3: V2RayActivity يتوقع "v2ray_json" لتعبئة الحقول
                //  عند التعديل. نُمرّر البايلود الحالي لإعادة تحميله.
                // ═══════════════════════════════════════════════════════
                intent.putExtra("v2ray_json", currentPayload);
                intent.putExtra("is_edit", true);
            }
        }

        generatorLauncher.launch(intent);
    }

    // ══════════════════════════════════════════════════════════════
    //  Helpers
    // ══════════════════════════════════════════════════════════════
    private String getText(TextView view) {
        return (view != null && view.getText() != null)
                ? view.getText().toString().trim() : "";
    }

    private void toast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }

    private String generatorTypeName(int type) {
        switch (type) {
            case GEN_UDP:    return "UDP";
            case GEN_V2RAY:  return "V2RAY";
            default:         return "PAYLOAD";
        }
    }
}
