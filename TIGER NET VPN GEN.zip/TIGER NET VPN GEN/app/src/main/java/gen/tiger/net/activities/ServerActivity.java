package gen.tiger.net.activities;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.util.Patterns;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.appbar.CollapsingToolbarLayout;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.color.DynamicColors;
import com.google.android.material.floatingactionbutton.ExtendedFloatingActionButton;
import com.google.android.material.materialswitch.MaterialSwitch;
import com.google.android.material.textfield.MaterialAutoCompleteTextView;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

import gen.tiger.net.R;
import gen.tiger.net.adapters.FlagAdapter;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.net.InetAddress;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class ServerActivity extends AppCompatActivity {

    private static final String TAG = "ServerActivity";

    // ── Views ──────────────────────────────────────────────────────
    private MaterialToolbar toolbar;
    // private TextInputLayout              nameLayout;
    private TextInputEditText serverNameInput;
    private TextInputEditText serverIpInput;
    private TextInputEditText cloudfront;
    private TextInputEditText serverhttp;
    private TextInputEditText ssh_port;
    private TextInputEditText tcp_port;
    private TextInputEditText ssl_port;
    private TextInputEditText username_v;
    private TextInputEditText password_v;
    private MaterialSwitch autoSwitch;
    private MaterialAutoCompleteTextView flag;
    private MaterialAutoCompleteTextView category_spin;
    private ExtendedFloatingActionButton fab;

    // ── Data ───────────────────────────────────────────────────────
    private List<String> categoryOptions;
    private ArrayList<String> flagsList;
    private boolean isEdit;

    // ══════════════════════════════════════════════════════════════
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        DynamicColors.applyToActivityIfAvailable(this);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fragment_server);

        bindViews();
        setupToolbar();
        setupAdapters();
        setupListeners();
        setupAutoLoginToggle();
        fillData();
    }

    // ══════════════════════════════════════════════════════════════
    //  ربط الـ Views
    // ══════════════════════════════════════════════════════════════
    private void bindViews() {
        toolbar = findViewById(R.id.toolbar);
        serverNameInput = findViewById(R.id.server_name_dialog);
        // nameLayout    = findViewById(R.id.layout_name);
        serverIpInput = findViewById(R.id.server_ip_dialog);
        cloudfront = findViewById(R.id.etServerCloudFront);
        serverhttp = findViewById(R.id.etServerHTTP);
        ssh_port = findViewById(R.id.openvpn_ssh_port);
        tcp_port = findViewById(R.id.openvpn_tcp_port);
        ssl_port = findViewById(R.id.openvpn_ssl_port);
        username_v = findViewById(R.id.username);
        password_v = findViewById(R.id.password);
        autoSwitch = findViewById(R.id.auto);
        flag = findViewById(R.id.flagspin);
        category_spin = findViewById(R.id.category_spin);
        fab = findViewById(R.id.generate);
    }

    // ══════════════════════════════════════════════════════════════
    //  إعداد الـ Toolbar
    // ══════════════════════════════════════════════════════════════
    private void setupToolbar() {
        setSupportActionBar(toolbar);
        toolbar.setNavigationOnClickListener(v -> finish());
    }

    /*@Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_server, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.action_save) {
            if (!validate()) return true;
            try {
                JSONObject jsObj = buildServerJson();
                Intent result = new Intent();
                result.putExtra("server_data", jsObj.toString());
                result.putExtra("is_edit", isEdit);
                setResult(RESULT_OK, result);
                finish();
            } catch (JSONException e) {
                toast("Error: " + e.getMessage());
            }
            return true;
        }
        return super.onOptionsItemSelected(item);
    }*/

    // ══════════════════════════════════════════════════════════════
    //  إعداد الـ Adapters
    // ══════════════════════════════════════════════════════════════
    private void setupAdapters() {
        categoryOptions = Arrays.asList("PREMIUM", "VIP", "PRIVATE");
        flagsList = getFlags();

        flag.setAdapter(new FlagAdapter(this, flagsList));
        category_spin.setAdapter(
                new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, categoryOptions));
    }

    private void setupListeners() {
        fab.setOnClickListener(v -> saveAndReturn());
    }

    // ══════════════════════════════════════════════════════════════
    //  تفعيل / تعطيل حقلي Username & Password
    // ══════════════════════════════════════════════════════════════
    private void setupAutoLoginToggle() {
        autoSwitch.setOnCheckedChangeListener(
                (btn, isChecked) -> {
                    username_v.setEnabled(!isChecked);
                    password_v.setEnabled(!isChecked);

                    username_v.setAlpha(isChecked ? 0.1f : 1f);
                    password_v.setAlpha(isChecked ? 0.1f : 1f);
                });
    }

    // ══════════════════════════════════════════════════════════════
    //  تعبئة البيانات من الـ Intent
    // ══════════════════════════════════════════════════════════════
    private void fillData() {
        Intent intent = getIntent();
        isEdit = intent.getBooleanExtra("is_edit", false);

        if (isEdit) {
            // title set via CollapsingToolbarLayout
            CollapsingToolbarLayout ctl = (CollapsingToolbarLayout) toolbar.getParent();
            if (ctl != null) ctl.setTitle("Edit SERVER");

            JSONObject server = null; // ✅ هنا الحل

            try {
                String json = intent.getStringExtra("server_json");
                if (json != null) {
                    server = new JSONObject(json);
                }
            } catch (JSONException e) {
                Log.e(TAG, "fillData edit: " + e.getMessage(), e);
            }

            if (server != null) {
                serverNameInput.setText(server.optString("Name", ""));
                serverIpInput.setText(server.optString("ServerIPHost", ""));
                cloudfront.setText(server.optString("ServerCloudFrontHost", ""));
                serverhttp.setText(server.optString("ServerHTTPHost", ""));
                ssh_port.setText(server.optString("OpenVPNSSHPort", ""));
                tcp_port.setText(server.optString("OpenVPNTCPPort", ""));
                ssl_port.setText(server.optString("OpenVPNSSLPort", ""));
                autoSwitch.setChecked(server.optBoolean("Auto", false));
                username_v.setText(server.optString("Username", ""));
                password_v.setText(server.optString("Password", ""));

                setSelection(
                        category_spin, categoryOptions, server.optString("Category", "PREMIUM"));

                if (!flagsList.isEmpty()) {
                    setSelection(flag, flagsList, server.optString("Flag", flagsList.get(0)));
                }
            }

        } else {
            // title set via CollapsingToolbarLayout
            CollapsingToolbarLayout ctl = (CollapsingToolbarLayout) toolbar.getParent();
            if (ctl != null) ctl.setTitle("Add SERVER");

            ssh_port.setText(intent.getStringExtra("default_ssh"));
            tcp_port.setText(intent.getStringExtra("default_tcp"));
            ssl_port.setText(intent.getStringExtra("default_ssl"));

            autoSwitch.setChecked(intent.getBooleanExtra("default_auto", false));

            setSelection(category_spin, categoryOptions, categoryOptions.get(0));

            if (!flagsList.isEmpty()) {
                setSelection(flag, flagsList, flagsList.get(0));
            }
        }
    }

    // ══════════════════════════════════════════════════════════════
    //  التحقق من صحة المدخلات
    // ══════════════════════════════════════════════════════════════

    private boolean validate() {

        String name = getText(serverNameInput).trim();
        String ip = getText(serverIpInput).trim();
        String ssh = getText(ssh_port).trim();
        String tcp = getText(tcp_port).trim();
        String ssl = getText(ssl_port).trim();

        boolean valid = true;

        // ✅ Name
        if (name.isEmpty()) {
            serverNameInput.setError("Required");
            valid = false;
        } else {
            serverNameInput.setError(null);
        }

        // ✅ IP / Domain
        if (ip.isEmpty()) {

            serverIpInput.setError("Required");
            valid = false;

        } else if (!Patterns.DOMAIN_NAME.matcher(ip).matches() && !isValidIp(ip)) {

            serverIpInput.setError("Invalid host");
            valid = false;

        } else {

            serverIpInput.setError(null);
        }

        // ❌ إذا فيه خطأ لا تكمل
        if (!valid) {
            return false;
        }

        // ✅ Ports
        try {

            int sshPort = Integer.parseInt(ssh);
            int tcpPort = Integer.parseInt(tcp);
            int sslPort = Integer.parseInt(ssl);

            if (sshPort < 1 || sshPort > 65535) {
                ssh_port.setError("Invalid");
                valid = false;
            } else {
                ssh_port.setError(null);
            }

            if (tcpPort < 1 || tcpPort > 65535) {
                tcp_port.setError("Invalid");
                valid = false;
            } else {
                tcp_port.setError(null);
            }

            if (sslPort < 1 || sslPort > 65535) {
                ssl_port.setError("Invalid");
                valid = false;
            } else {
                ssl_port.setError(null);
            }

        } catch (NumberFormatException e) {

            toast("Ports must be numbers");
            return false;
        }

        return valid;
    }

    private boolean isValidIp(String ip) {
        try {
            InetAddress address = InetAddress.getByName(ip);
            return address != null;
        } catch (Exception e) {
            return false;
        }
    }

    private void saveAndReturn() {
        if (!validate()) return;
        try {
            JSONObject serverJson = buildServerJson();
            Intent result = new Intent();
            result.putExtra("server_data", serverJson.toString());
            result.putExtra("is_edit", isEdit);
            setResult(RESULT_OK, result);
            finish();
        } catch (JSONException e) {
            Log.e(TAG, "saveAndReturn: " + e.getMessage(), e);
            toast("Error: " + e.getMessage());
        }
    }

    // ══════════════════════════════════════════════════════════════
    //  بناء JSONObject من الحقول
    // ══════════════════════════════════════════════════════════════
    private JSONObject buildServerJson() throws JSONException {
        JSONObject jsObj = new JSONObject();
        jsObj.put("Name", getText(serverNameInput));
        jsObj.put("Flag", getText(flag));
        jsObj.put("ServerIPHost", getText(serverIpInput));
        jsObj.put("ServerCloudFrontHost", getText(cloudfront));
        jsObj.put("ServerHTTPHost", getText(serverhttp));
        jsObj.put("Category", getText(category_spin));
        jsObj.put("OpenVPNSSHPort", getText(ssh_port));
        jsObj.put("OpenVPNTCPPort", getText(tcp_port));
        jsObj.put("OpenVPNSSLPort", getText(ssl_port));
        jsObj.put("Username", getText(username_v));
        jsObj.put("Password", getText(password_v));
        jsObj.put("Auto", autoSwitch.isChecked());
        return jsObj;
    }

    // ══════════════════════════════════════════════════════════════
    //  Helpers
    // ══════════════════════════════════════════════════════════════
    private String getText(TextView view) {
        return (view != null && view.getText() != null) ? view.getText().toString().trim() : "";
    }

    private void setSelection(MaterialAutoCompleteTextView view, List<String> list, String value) {
        int idx = list.indexOf(value);
        if (idx >= 0) view.setText(list.get(idx), false);
    }

    private ArrayList<String> getFlags() {
        try {
            String[] files = getAssets().list("flag");
            return (files != null) ? new ArrayList<>(Arrays.asList(files)) : new ArrayList<>();
        } catch (IOException e) {
            Log.e(TAG, "getFlags: " + e.getMessage(), e);
            return new ArrayList<>();
        }
    }

    private void toast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }
}
