package gen.tiger.net.activities;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.AssetManager;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Base64;
import android.util.Log;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.preference.PreferenceManager;

import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.checkbox.MaterialCheckBox;
import com.google.android.material.color.DynamicColors;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.android.material.floatingactionbutton.ExtendedFloatingActionButton;
import com.google.android.material.progressindicator.LinearProgressIndicator;
import com.google.android.material.radiobutton.MaterialRadioButton;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.textfield.MaterialAutoCompleteTextView;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import com.google.android.material.textview.MaterialTextView;

import gen.tiger.net.MyApplication;
import gen.tiger.net.R;
import gen.tiger.net.activities.PayloadGeneratorActivity;
import gen.tiger.net.adapters.FlagAdapter;
import gen.tiger.net.adapters.SpinnerAdapter;
import gen.tiger.net.constants.Constant;
import gen.tiger.net.dialog.LoadingDialog;
import gen.tiger.net.managers.GitHubManager;
import gen.tiger.net.managers.NetworkManager;
import gen.tiger.net.managers.SSLNetworkManager;
import gen.tiger.net.managers.ServerManager;
import gen.tiger.net.models.Config;
// import gen.tiger.net.utils.CryptoUtils;
import gen.tiger.net.utils.AESHelper;
import gen.tiger.net.utils.GETRequest;
import gen.tiger.net.utils.QrCodeUtils;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Objects;
import java.util.Properties;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

public class MainActivity extends AppCompatActivity
        implements ActivityCompat.OnRequestPermissionsResultCallback {

    private static final String TAG = "MainActivity"; // Tag for logging

    private MaterialToolbar toolbar;
    private LinearProgressIndicator loadingBar;
    private ExtendedFloatingActionButton fabSave;

    private Config json;
    private SharedPreferences prefs;
    private SharedPreferences.Editor editor;
    private MaterialAutoCompleteTextView server_ac, network_ac, ssl_network_ac;

    private final List<String> listServer = new ArrayList<>();
    private final List<String> listNetwork = new ArrayList<>();
    private final List<String> listSSLNetwork = new ArrayList<>();

    // private TextInputEditText payload_v;

    private String tempFileName = "";

    // Launcher لعملية استيراد الملف (Import)
    private ActivityResultLauncher<Intent> importLauncher;
    // Launcher لعملية تصدير الملف (Export)
    private ActivityResultLauncher<Intent> exportLauncher;

    private ServerManager serverManager;
    private NetworkManager networkManager;
    private SSLNetworkManager sslNetworkManager;

    private ExecutorService executor = Executors.newCachedThreadPool();
    private final AtomicBoolean isImporting = new AtomicBoolean(false);
    private boolean hasUnsavedChanges = false;
    private View rootView; // لـ Snackbar anchor

    @SuppressLint({"CutPasteId", "SetTextI18n"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        DynamicColors.applyToActivityIfAvailable(this);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.mtkofficial);

        rootView = findViewById(android.R.id.content);
        toolbar = findViewById(R.id.toolbar);
        loadingBar = findViewById(R.id.loading_bar);
        fabSave = findViewById(R.id.save);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN);
        setSupportActionBar(toolbar);
        // CollapsingToolbarLayout يتولى العنوان
        if (getSupportActionBar() != null) getSupportActionBar().setDisplayShowTitleEnabled(false);

        // ── تحذير الخروج بدون حفظ ──────────────────────────────────
        getOnBackPressedDispatcher()
                .addCallback(
                        this,
                        new OnBackPressedCallback(true) {
                            @Override
                            public void handleOnBackPressed() {
                                if (!hasUnsavedChanges) {
                                    setEnabled(false);
                                    getOnBackPressedDispatcher().onBackPressed();
                                    return;
                                }
                                new com.google.android.material.dialog.MaterialAlertDialogBuilder(
                                                MainActivity.this)
                                        .setTitle("Unsaved Changes")
                                        .setMessage(
                                                "You have unsaved changes. Exit without saving?")
                                        .setPositiveButton(
                                                "Exit",
                                                (d, w) -> {
                                                    setEnabled(false);
                                                    getOnBackPressedDispatcher().onBackPressed();
                                                })
                                        .setNegativeButton("Stay", null)
                                        .show();
                            }
                        });

        // json = Config.getInstance(this);
        prefs = PreferenceManager.getDefaultSharedPreferences(this);
        editor = prefs.edit();

        exportLauncher = initExportLauncher();
        importLauncher = initImportLauncher();

        // الوصول لكل Section
        MaterialTextView serverSpinner =
                findViewById(R.id.server_section).findViewById(R.id.section_title);
        MaterialTextView networkSpinner =
                findViewById(R.id.http_section).findViewById(R.id.section_title);
        MaterialTextView sslSpinner =
                findViewById(R.id.ssl_section).findViewById(R.id.section_title);

        // تغيير العناوين
        serverSpinner.setText(R.string.section_servers);
        networkSpinner.setText(R.string.section_networks);
        sslSpinner.setText(R.string.section_ssl_networks);

        // أيقونة مختلفة لكل قسم
        setSectionIcon(findViewById(R.id.server_section), R.drawable.ic_server);
        setSectionIcon(findViewById(R.id.http_section), R.drawable.ic_network);
        setSectionIcon(findViewById(R.id.ssl_section), R.drawable.ic_ssl_network);

        // ربط الـ AutoCompleteTextView لكل include
        server_ac = findViewById(R.id.server_section).findViewById(R.id.dropdown_list);
        network_ac = findViewById(R.id.http_section).findViewById(R.id.dropdown_list);
        ssl_network_ac = findViewById(R.id.ssl_section).findViewById(R.id.dropdown_list);

        serverManager =
                new ServerManager(
                        this,
                        server_ac,
                        listServer,
                        new ServerManager.OnServerChangedListener() {
                            @Override
                            public void onServerAdded(String serverName) {
                                hasUnsavedChanges = true;
                                snack("✅ Server added: " + serverName);
                            }

                            @Override
                            public void onServerEdited(String serverName) {
                                hasUnsavedChanges = true;
                                snack("✅ Server updated: " + serverName);
                            }

                            @Override
                            public void onServerDeleted(String name, Runnable undoAction) {
                                snackWithAction("🗑 " + name + " deleted", "UNDO", undoAction);
                            }

                            @Override
                            public void refreshDropdown() {
                                try {
                                    setupAutoCompleteTextView(
                                            server_ac, listServer, json.getServerList());
                                } catch (JSONException e) {
                                    Log.e(
                                            TAG,
                                            "Failed to setup AutoCompleteTextViews on create.",
                                            e);
                                }
                            }
                        });

        networkManager =
                new NetworkManager(
                        this,
                        network_ac,
                        listNetwork,
                        new NetworkManager.OnNetworkChangedListener() {
                            @Override
                            public void onNetworkAdded(String name) {
                                hasUnsavedChanges = true;
                                snack("✅ Network added: " + name);
                            }

                            @Override
                            public void onNetworkEdited(String name) {
                                hasUnsavedChanges = true;
                                snack("✅ Network updated: " + name);
                            }

                            @Override
                            public void onNetworkDeleted(String name, Runnable undoAction) {
                                snackWithAction("🗑 " + name + " deleted", "UNDO", undoAction);
                            }

                            @Override
                            public void refreshDropdown() {
                                try {
                                    setupAutoCompleteTextView(
                                            network_ac, listNetwork, json.getNetworkList());
                                } catch (JSONException e) {
                                    Log.e(TAG, e.getMessage(), e);
                                }
                            }
                        });

        sslNetworkManager =
                new SSLNetworkManager(
                        this,
                        ssl_network_ac,
                        listSSLNetwork,
                        new SSLNetworkManager.OnSSLNetworkChangedListener() {
                            @Override
                            public void onSSLNetworkAdded(String name) {
                                hasUnsavedChanges = true;
                                snack("✅ SSL network added: " + name);
                            }

                            @Override
                            public void onSSLNetworkEdited(String name) {
                                hasUnsavedChanges = true;
                                snack("✅ SSL network updated: " + name);
                            }

                            @Override
                            public void onSSLNetworkDeleted(String name, Runnable undoAction) {
                                snackWithAction("🗑 " + name + " deleted", "UNDO", undoAction);
                            }

                            @Override
                            public void refreshDropdown() {
                                try {
                                    setupAutoCompleteTextView(
                                            ssl_network_ac,
                                            listSSLNetwork,
                                            json.getSSLNetworkList());
                                } catch (JSONException e) {
                                    Log.e(TAG, e.getMessage(), e);
                                }
                            }
                        });

        View serverSection = findViewById(R.id.server_section);
        View httpSection = findViewById(R.id.http_section);
        View sslSection = findViewById(R.id.ssl_section);

        MaterialButton save = findViewById(R.id.save);

        setupSectionButtons(
                serverSection,
                () -> serverManager.addServer(),
                () -> serverManager.editServer(),
                () -> serverManager.deleteServer());

        setupSectionButtons(
                httpSection,
                () -> networkManager.addNetwork(),
                () -> networkManager.editNetwork(),
                () -> networkManager.deleteNetwork());

        setupSectionButtons(
                sslSection,
                () -> sslNetworkManager.addSSLNetwork(),
                () -> sslNetworkManager.editSSLNetwork(),
                () -> sslNetworkManager.deleteSSLNetwork());

        save.setOnClickListener(
                v -> {
                    showSaveDialog();
                });

        SpinnerAdapter serverAdapter = new SpinnerAdapter(this, listServer);
        server_ac.setAdapter(serverAdapter);

        SpinnerAdapter spinnerAdapter = new SpinnerAdapter(this, listNetwork);
        network_ac.setAdapter(spinnerAdapter);

        SpinnerAdapter sslSpinnerAdapter = new SpinnerAdapter(this, listSSLNetwork);
        ssl_network_ac.setAdapter(sslSpinnerAdapter);

        executor.execute(
                () -> {
                    json = Config.getInstance(MainActivity.this); // ← background
                    runOnUiThread(
                            () -> {
                                try {
                                    setupAutoCompleteTextView(
                                            server_ac, listServer, json.getServerList());
                                    setupAutoCompleteTextView(
                                            network_ac, listNetwork, json.getNetworkList());
                                    setupAutoCompleteTextView(
                                            ssl_network_ac,
                                            listSSLNetwork,
                                            json.getSSLNetworkList());
                                    refreshSectionStates();
                                } catch (JSONException e) {
                                    Log.e(TAG, "Failed to setup dropdowns", e);
                                }
                                // ✨ Hide loading bar after data is ready
                                hideLoadingBar();
                            });
                });
        // ✨ FAB scroll behavior
        setupFabScrollBehavior();
    }

    // دالة لتهيئة Export Launcher
    private ActivityResultLauncher<Intent> initExportLauncher() {
        return registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() != RESULT_OK || result.getData() == null) {
                        toast("No file selected or operation cancelled.");
                        return;
                    }
                    Uri uri = result.getData().getData();
                    executor.execute(
                            () -> {
                                try (OutputStream outputStream =
                                        getContentResolver().openOutputStream(uri)) {
                                    if (outputStream == null) {
                                        runOnUiThread(
                                                () -> toast("Unable to open file for saving."));
                                        return;
                                    }
                                    // BUG FIX #8: assert مُعطَّل في Android (Dalvik/ART) ← كان
                                    // يسبّب
                                    // NullPointerException صامت إذا فشل encrypt(). تم استبداله بفحص
                                    // صريح مع رسالة خطأ واضحة للمستخدم.
                                    String encryptedJson = encrypt(json.toString());
                                    if (encryptedJson == null) {
                                        runOnUiThread(
                                                () -> toast("Export failed: encryption error."));
                                        return;
                                    }
                                    outputStream.write(
                                            encryptedJson.getBytes(StandardCharsets.UTF_8));
                                    runOnUiThread(() -> toast("File saved successfully."));
                                } catch (Exception e) {
                                    Log.e(TAG, "Error during file export", e);
                                    runOnUiThread(() -> toast("Save error: " + e.getMessage()));
                                }
                            });
                });
    }

    // دالة لتهيئة Import Launcher
    private ActivityResultLauncher<Intent> initImportLauncher() {
        return registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() != RESULT_OK || result.getData() == null) {
                        toast("No file selected or operation cancelled.");
                        return;
                    }
                    Uri uri = result.getData().getData();
                    executor.execute(
                            () -> {
                                try (BufferedReader reader =
                                        new BufferedReader(
                                                new InputStreamReader(
                                                        getContentResolver()
                                                                .openInputStream(uri)))) {
                                    StringBuilder sb = new StringBuilder();
                                    String line;
                                    while ((line = reader.readLine()) != null) sb.append(line);
                                    String content = sb.toString();
                                    runOnUiThread(() -> importConfig(content));
                                } catch (IOException e) {
                                    runOnUiThread(
                                            () -> toast("Failed to read file: " + e.getMessage()));
                                }
                            });
                });
    }

    private void setupAutoCompleteTextView(
            MaterialAutoCompleteTextView autoComplete,
            List<String> targetList,
            ArrayList<JSONObject> sourceList)
            throws JSONException {
        try {
            targetList.clear();
            for (JSONObject obj : sourceList) {
                targetList.add(obj.getString("Name"));
            }
            // FilterableAdapter يدعم البحث النصي داخل القائمة
            ArrayAdapter<String> adapter =
                    new ArrayAdapter<>(this, R.layout.item, new java.util.ArrayList<>(targetList));
            autoComplete.setAdapter(adapter);
            autoComplete.setThreshold(1); // ابدأ البحث بعد حرف واحد

            if (!targetList.isEmpty()) {
                autoComplete.setText(targetList.get(0), false);
            } else {
                autoComplete.setText("", false);
            }

            // تحديث Empty State للقسم المرتبط
            refreshSectionStates();
        } catch (JSONException e) {
            Log.e(TAG, "Load Error: " + e.getMessage(), e);
            toast("Load Error: " + e.getMessage());
        }
    }

    private void setupSectionButtons(
            View section, Runnable onAdd, Runnable onEdit, Runnable onDelete) {
        section.findViewById(R.id.add_button).setOnClickListener(v -> onAdd.run());
        section.findViewById(R.id.edit_button).setOnClickListener(v -> onEdit.run());
        section.findViewById(R.id.delete_button).setOnClickListener(v -> onDelete.run());
    }

    private void showVersionDialog(String initialVersion) {
        View v = LayoutInflater.from(this).inflate(R.layout.version_dialog, null);
        TextInputEditText versionEditText = v.findViewById(R.id.version);
        if (initialVersion != null && !initialVersion.isEmpty()) {
            versionEditText.setText(initialVersion);
        } else {
            versionEditText.setText(json.getVersion());
        }

        MaterialAlertDialogBuilder builder = new MaterialAlertDialogBuilder(this);
        builder.setView(v).setCancelable(false);
        final AlertDialog dialog = builder.create();
        dialog.show();

        MaterialButton btnVersionSave = v.findViewById(R.id.btn_save_version);
        btnVersionSave.setOnClickListener(
                p1 -> {
                    String versionText = getText(versionEditText);
                    prefs.edit().putString("Version", versionText).apply();

                    dialog.dismiss();
                });

        MaterialButton btnVersionCancel = v.findViewById(R.id.btn_cancel_version);
        btnVersionCancel.setOnClickListener(
                p1 -> {
                    dialog.dismiss();
                });
    }

    private void showNoteDialog() {
        View v = LayoutInflater.from(this).inflate(R.layout.notes_dialog, null);
        final TextInputEditText notes = v.findViewById(R.id.notes);
        notes.setText(json.getNotes());

        MaterialAlertDialogBuilder builder = new MaterialAlertDialogBuilder(this);
        builder.setView(v).setCancelable(false);
        final AlertDialog dialog = builder.create();
        dialog.show();

        MaterialButton save = v.findViewById(R.id.save_json_dialog);
        save.setOnClickListener(
                p1 -> {
                    String noteText = getText(notes);
                    json.setNotes(noteText);
                    dialog.dismiss();
                });

        MaterialButton cancel = v.findViewById(R.id.cancel_json_dialog);
        cancel.setOnClickListener(
                p1 -> {
                    dialog.dismiss();
                });
    }

    private void showSaveDialog() {
        if (json == null) {
            showJsonLoadingSnack();
            return;
        }
        View v = LayoutInflater.from(this).inflate(R.layout.save_dialog, null);
        TextInputEditText fileNameEditText = v.findViewById(R.id.file_name);
        // اسم افتراضي: config_YYYY-MM-DD
        String defaultName =
                "config_"
                        + new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
                                .format(new Date());
        fileNameEditText.setText(defaultName);

        MaterialAlertDialogBuilder builder = new MaterialAlertDialogBuilder(this);
        builder.setView(v);
        final AlertDialog dialog = builder.create();
        dialog.show();

        MaterialButton save = v.findViewById(R.id.btn_save);
        save.setOnClickListener(
                p1 -> {
                    String fileName = getText(fileNameEditText);
                    final String chosenName = fileName.isEmpty() ? defaultName : fileName;
                    tempFileName = chosenName;
                    json.setVersion(prefs.getString("Version", ""));
                    json.save();
                    requestExportPermission();
                    toast("Settings saved successfully.");
                    dialog.dismiss();
                });
        MaterialButton copy = v.findViewById(R.id.btn_copy);
        copy.setOnClickListener(
                p1 -> {
                    json.setVersion(prefs.getString("Version", ""));
                    json.save();
                    try {
                        String encryptedJson = encrypt(json.toString());
                        ((ClipboardManager) getSystemService(CLIPBOARD_SERVICE))
                                .setPrimaryClip(
                                        ClipData.newPlainText("Encrypted JSON", encryptedJson));
                        snack("✅ Copied to clipboard.");
                    } catch (Exception ignored) {
                    }
                    dialog.dismiss();
                });
        MaterialButton upload = v.findViewById(R.id.btn_upload);
        upload.setOnClickListener(
                p1 -> {
                    if (!isNetworkAvailable()) {
                        toast("No internet connection. Please check your connection.");
                        return;
                    }

                    // تنفيذ الرفع عبر GitHubManager
                    json.setVersion(prefs.getString("Version", ""));
                    json.save();
                    try {
                        uploadToGitHub(encrypt(json.toString()));
                    } catch (Exception e) {
                        toast("فشل تحضير البيانات للرفع: " + e.getMessage());
                    }
                    dialog.dismiss();
                });
    }

    private boolean isNetworkAvailable() {
        ConnectivityManager connectivityManager =
                (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);

        if (connectivityManager == null) {
            return false;
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Network activeNetwork = connectivityManager.getActiveNetwork();
            if (activeNetwork != null) {
                NetworkCapabilities networkCapabilities =
                        connectivityManager.getNetworkCapabilities(activeNetwork);
                return networkCapabilities != null
                        && networkCapabilities.hasCapability(
                                NetworkCapabilities.NET_CAPABILITY_INTERNET)
                        && networkCapabilities.hasCapability(
                                NetworkCapabilities.NET_CAPABILITY_VALIDATED);
            }
        }
        return false;
    }

    // ══════════════════════════════════════════════════════════════
    //  GitHub — Upload
    // ══════════════════════════════════════════════════════════════
    private void uploadToGitHub(String encryptedJson) {
        String token = getGithubTokenFromAssets();
        if (token.isEmpty()) {
            toast("❌ توكن GitHub غير موجود.\nتحقق من ملف github.properties.");
            return;
        }

        // إظهار Loading
        LoadingDialog loading = new LoadingDialog(this, "جاري الرفع إلى GitHub...");
        loading.show();

        GitHubManager.upload(
                encryptedJson,
                token,
                new GitHubManager.Callback() {
                    @Override
                    public void onSuccess(@NonNull String message) {
                        loading.dismiss();
                        toast(message);
                    }

                    @Override
                    public void onError(@NonNull String errorMessage) {
                        loading.dismiss();
                        // رسالة خطأ تفصيلية في Dialog بدلاً من Toast المؤقت
                        new MaterialAlertDialogBuilder(MainActivity.this)
                                .setTitle("فشل الرفع")
                                .setMessage(errorMessage)
                                .setPositiveButton(R.string.ok, null)
                                .show();
                    }
                });
    }

    // ══════════════════════════════════════════════════════════════
    //  GitHub — Download (Import from API / Panel)
    // ══════════════════════════════════════════════════════════════
    private void importFromAPI(String url) {
        String token = getGithubTokenFromAssets();
        if (token.isEmpty()) {
            toast("❌ توكن GitHub غير موجود.\nتحقق من ملف github.properties.");
            return;
        }

        // إظهار Loading
        LoadingDialog loading = new LoadingDialog(this, "جاري التنزيل من GitHub...");
        loading.show();

        // الإصلاح: تمرير url الفعلي بدلاً من تجاهله
        GitHubManager.download(
                url,
                token,
                new GitHubManager.DownloadCallback() {
                    @Override
                    public void onSuccess(@NonNull String encryptedContent) {
                        loading.dismiss();
                        importConfig(encryptedContent);
                    }

                    @Override
                    public void onError(@NonNull String errorMessage) {
                        loading.dismiss();
                        new MaterialAlertDialogBuilder(MainActivity.this)
                                .setTitle("فشل التنزيل")
                                .setMessage(errorMessage)
                                .setPositiveButton(R.string.ok, null)
                                .show();
                    }
                });
    }

    // ══════════════════════════════════════════════════════════════
    //  قراءة التوكن من Assets
    // ══════════════════════════════════════════════════════════════
    private String getGithubTokenFromAssets() {
        try {
            InputStream inputStream = getAssets().open("github.properties");
            Properties properties = new Properties();
            properties.load(inputStream);
            String token = properties.getProperty("github_token", "").trim();
            if (token.isEmpty()) {
                Log.w(TAG, "github.properties موجود لكن github_token فارغ.");
            }
            return token;
        } catch (IOException e) {
            Log.e(TAG, "لم يُعثر على github.properties في assets.", e);
            return "";
        }
    }

    private void importOnline() {
        View v = LayoutInflater.from(this).inflate(R.layout.import_dialog, null);
        TextInputEditText url = v.findViewById(R.id.url);

        MaterialAlertDialogBuilder builder = new MaterialAlertDialogBuilder(this);
        builder.setView(v).setCancelable(false);
        final AlertDialog dialog = builder.create();
        dialog.show();

        MaterialButton importJson = v.findViewById(R.id.btn_import_json_url);
        importJson.setOnClickListener(
                p1 -> {
                    if (Objects.requireNonNull(url.getText()).toString().isEmpty()) {
                        toast("Invalid Json URL");
                    } else {
                        importFromAPI(url.getText().toString());
                    }
                });
        MaterialButton cancelJson = v.findViewById(R.id.btn_cancel_json_url);
        cancelJson.setOnClickListener(
                p1 -> {
                    dialog.dismiss();
                });
    }

    private void requestExportPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            saveJson();
        } else {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)
                    != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(
                        this, new String[] {Manifest.permission.WRITE_EXTERNAL_STORAGE}, 2);
            } else {
                saveJson();
            }
        }
    }

    private void saveJson() {
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        // MISMATCH-FIX-1: VPN app only accepts .js and .rj extensions.
        // Changed MIME + default filename to use .js so the user gets the right
        // extension by default without having to rename the file manually.
        intent.setType("application/javascript");
        intent.putExtra(
                Intent.EXTRA_TITLE,
                tempFileName.isEmpty() ? "config.js" : tempFileName + ".js");
        try {
            exportLauncher.launch(Intent.createChooser(intent, "Select JSON file"));
        } catch (ActivityNotFoundException e) {
            Log.e(TAG, "No activity found to handle file creation", e);
            toast("Cannot save file: No file manager app found.");
        }
    }

    @Override
    public void onRequestPermissionsResult(
            int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode) {
            case 1:
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    startImport();
                } else {
                    toast("You can't import json without granting permission!");
                }
                break;
            case 2:
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    saveJson();
                } else {
                    toast("You can't save Generated Json to SDCard without granting permission!");
                }
                break;
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.menu_clipboard) {
            importFromClipboard();
            return true;
        } else if (id == R.id.menu_online) {
            importOnline();
            return true;
        } else if (id == R.id.menu_panel) {
            importFromAPI(MyApplication.CONFIG_GET_API);
            return true;
        } else if (id == R.id.menu_theme) {
            showThemeDialog();
            return true;
        } else if (id == R.id.menu_info) {
            showAboutDialog();
            return true;
        } else if (id == R.id.menu_qr) {
            showQrExport();
            return true;
        } else if (id == R.id.menu_sort) {
            sortAllLists();
            return true;
        }
        // الأوامر التالية تحتاج json — نتحقق أولاً
        else if (id == R.id.menu_version) {
            if (json == null) {
                showJsonLoadingSnack();
                return true;
            }
            showVersionDialog(json.getVersion());
            return true;
        } else if (id == R.id.menu_notes) {
            if (json == null) {
                showJsonLoadingSnack();
                return true;
            }
            showNoteDialog();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    // ── Helper ─────────────────────────────────────────────────────
    private int dpToPx(int dp) {
        return (int)
                TypedValue.applyDimension(
                        TypedValue.COMPLEX_UNIT_DIP, dp, getResources().getDisplayMetrics());
    }

    private void importFromClipboard() {
        ClipboardManager clipboard = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
        if (clipboard != null && clipboard.hasPrimaryClip()) {
            ClipData clip = clipboard.getPrimaryClip();
            if (clip != null && clip.getItemCount() > 0) {
                CharSequence text = clip.getItemAt(0).coerceToText(this);
                if (text != null) {
                    importConfig(text.toString());
                }
            }
        }
    }

    // ══════════════════════════════════════════════════════════════
    //  Theme Mode — BottomSheet
    // ══════════════════════════════════════════════════════════════
    private void showThemeDialog() {
        // تجنب فتح أكثر من نسخة إذا كانت مفتوحة بالفعل
        if (getSupportFragmentManager().findFragmentByTag(ThemeBottomSheet.TAG) != null) return;

        new ThemeBottomSheet().show(getSupportFragmentManager(), ThemeBottomSheet.TAG);
    }

    private void showAboutDialog() {
        View v = LayoutInflater.from(this).inflate(R.layout.about, null);

        MaterialAlertDialogBuilder builder = new MaterialAlertDialogBuilder(this);
        builder.setView(v).setCancelable(false);
        final AlertDialog dialog = builder.create();
        dialog.show();

        MaterialButton ok = v.findViewById(R.id.ok);
        ok.setOnClickListener(
                p1 -> {
                    dialog.dismiss();
                });
    }

    @SuppressLint("SetTextI18n")
    private void startImport() {
        // تحقق من خيار "Don't show again"
        if (prefs.getBoolean("DIALOG_DONT_SHOW_AGAIN", false)) {
            launchImportFilePicker();
            return;
        }

        // إنشاء CheckBox Material3 مع padding محسّن
        MaterialCheckBox dontShowAgainCheckBox = new MaterialCheckBox(this);
        dontShowAgainCheckBox.setText("Don't show again");

        int paddingDp =
                (int)
                        TypedValue.applyDimension(
                                TypedValue.COMPLEX_UNIT_DIP,
                                16,
                                getResources().getDisplayMetrics());
        dontShowAgainCheckBox.setPadding(paddingDp, paddingDp / 2, paddingDp, paddingDp / 2);

        // إنشاء AlertDialog للتحذير
        new MaterialAlertDialogBuilder(this)
                .setTitle("Warning")
                .setMessage(
                        "Warning! Do not import JSON files from other developers, they may cause"
                                + " the app to crash.")
                .setView(dontShowAgainCheckBox)
                .setPositiveButton(
                        "OK",
                        (dialog, which) -> {
                            if (dontShowAgainCheckBox.isChecked()) {
                                prefs.edit().putBoolean("DIALOG_DONT_SHOW_AGAIN", true).apply();
                            }
                            launchImportFilePicker();
                        })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void launchImportFilePicker() {
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.setType("application/json"); // أفضل من "*/*"
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        try {
            importLauncher.launch(Intent.createChooser(intent, "Select JSON file"));
        } catch (ActivityNotFoundException e) {
            Log.e(TAG, "No file manager found to handle import", e);
            Toast.makeText(this, "No file manager app found.", Toast.LENGTH_SHORT).show();
        }
    }

    private void importConfig(String str) {
        if (str == null || str.trim().isEmpty()) {
            toast("Import failed: empty input.");
            return;
        }
        // منع الاستدعاء المتزامن — لو هناك import جارٍ بالفعل، نرفض الثاني
        if (!isImporting.compareAndSet(false, true)) {
            snack("⏳ Import already in progress...");
            return;
        }

        // أعد إنشاء الـ executor إذا كان مغلقاً
        if (executor == null || executor.isShutdown() || executor.isTerminated()) {
            executor = Executors.newSingleThreadExecutor();
        }

        executor.execute(
                () -> {
                    try {
                        // فك التشفير
                        String decrypted = decrypt(str);

                        // تحديث JSON داخلي
                        json.setJson(decrypted);

                        // تحديث واجهة المستخدم على Main Thread
                        runOnUiThread(
                                () -> {
                                    try {
                                        // إعداد الـ AutoCompleteTextViews
                                        setupAutoCompleteTextView(
                                                server_ac, listServer, json.getServerList());
                                        setupAutoCompleteTextView(
                                                network_ac, listNetwork, json.getNetworkList());
                                        setupAutoCompleteTextView(
                                                ssl_network_ac,
                                                listSSLNetwork,
                                                json.getSSLNetworkList());

                                        String versionFromJson = json.getVersion();
                                        isImporting.set(false);
                                        hasUnsavedChanges = true;
                                        autoBackup();
                                        snack("✅ Import successful — v" + versionFromJson);
                                    } catch (JSONException e) {
                                        toast("Import Error: Invalid format.");
                                    }
                                });

                    } catch (Exception e) {
                        isImporting.set(false);
                        runOnUiThread(() -> toast("Import Error: " + e.getMessage()));
                    }
                });
    }

    public static String encrypt(String str) {
        try {
            return AESHelper.encrypt("google", str);
        } catch (Exception e) {
            e.printStackTrace();
            return "";
        }
    }

    public static String decrypt(String str) {
        try {
            return AESHelper.decrypt("google", str);
        } catch (Exception e) {
            e.printStackTrace();
            return "";
        }
    }

    private void toast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }

    /** Snackbar قصير على الشاشة الرئيسية */
    // ══════════════════════════════════════════════════════════════
    //  ✨ Loading Bar — يُخفى بعد تحميل البيانات
    // ══════════════════════════════════════════════════════════════
    private void hideLoadingBar() {
        if (loadingBar == null) return;
        loadingBar
                .animate()
                .alpha(0f)
                .setDuration(300)
                .withEndAction(
                        () -> {
                            loadingBar.setVisibility(android.view.View.GONE);
                            loadingBar.setAlpha(1f); // reset for potential reuse
                        })
                .start();
    }

    /*private void showLoadingBar() {
        if (loadingBar == null) return;
        loadingBar.setAlpha(0f);
        loadingBar.setVisibility(android.view.View.VISIBLE);
        loadingBar.animate().alpha(1f).setDuration(200).start();
    }*/

    // ══════════════════════════════════════════════════════════════
    //  ✨ FAB Scroll Behavior — يُصغَّر عند التمرير للأسفل
    // ══════════════════════════════════════════════════════════════
    private void setupFabScrollBehavior() {
        androidx.core.widget.NestedScrollView scroll = findViewById(R.id.scroll);
        if (scroll == null || fabSave == null) return;

        scroll.setOnScrollChangeListener(
                (androidx.core.widget.NestedScrollView.OnScrollChangeListener)
                        (v, scrollX, scrollY, oldScrollX, oldScrollY) -> {
                            if (scrollY > oldScrollY + 8 && fabSave.isExtended()) {
                                fabSave.shrink(); // تمرير للأسفل → يُصغَّر
                            } else if (scrollY < oldScrollY - 8 && !fabSave.isExtended()) {
                                fabSave.extend(); // تمرير للأعلى → يُكبَّر
                            }
                            // عند الوصول للقمة → تأكيد الإظهار
                            if (scrollY == 0) fabSave.extend();
                        });
    }

    private void snack(String msg) {
        if (rootView != null) Snackbar.make(rootView, msg, Snackbar.LENGTH_SHORT).show();
        else toast(msg);
    }

    /** Snackbar مع زر Action */
    private void snackWithAction(String msg, String actionLabel, Runnable action) {
        if (rootView == null) {
            toast(msg);
            return;
        }
        Snackbar.make(rootView, msg, Snackbar.LENGTH_LONG)
                .setAction(actionLabel, v -> action.run())
                .show();
    }

    /** يظهر عندما يضغط المستخدم قبل انتهاء تحميل الـ Config */
    private void showJsonLoadingSnack() {
        snack("⏳ جاري تحميل البيانات، حاول مجدداً...");
    }

    private String getText(TextView view) {
        return view != null && view.getText() != null ? view.getText().toString() : "";
    }

    // ══════════════════════════════════════════════════════════════
    //  QR Code Export
    // ══════════════════════════════════════════════════════════════
    private void showQrExport() {
        if (json == null) {
            showJsonLoadingSnack();
            return;
        }

        executor.execute(
                () -> {
                    try {
                        String encrypted = encrypt(json.toString());
                        if (encrypted == null) {
                            runOnUiThread(() -> snack("❌ Failed to encrypt config."));
                            return;
                        }

                        boolean tooLong = QrCodeUtils.isTooLong(encrypted);
                        android.graphics.Bitmap qrBitmap =
                                tooLong ? null : QrCodeUtils.generate(encrypted);

                        runOnUiThread(
                                () -> {
                                    android.view.View v =
                                            LayoutInflater.from(this)
                                                    .inflate(R.layout.dialog_qr_code, null);

                                    android.widget.ImageView qrImage =
                                            v.findViewById(R.id.qr_image);
                                    android.view.View qrWarning = v.findViewById(R.id.qr_warning);
                                    MaterialButton btnClose = v.findViewById(R.id.btn_qr_close);

                                    if (tooLong || qrBitmap == null) {
                                        qrWarning.setVisibility(android.view.View.VISIBLE);
                                        qrImage.setVisibility(android.view.View.GONE);
                                    } else {
                                        qrImage.setImageBitmap(qrBitmap);
                                    }

                                    androidx.appcompat.app.AlertDialog dialog =
                                            new com.google.android.material.dialog
                                                            .MaterialAlertDialogBuilder(this)
                                                    .setView(v)
                                                    .setCancelable(true)
                                                    .create();
                                    dialog.show();
                                    btnClose.setOnClickListener(x -> dialog.dismiss());
                                });

                    } catch (Exception e) {
                        runOnUiThread(() -> snack("❌ QR Error: " + e.getMessage()));
                    }
                });
    }

    // ══════════════════════════════════════════════════════════════
    //  Auto Backup — نسخة احتياطية محلية (آخر 5 نسخ)
    // ══════════════════════════════════════════════════════════════
    private void autoBackup() {
        if (json == null) return;
        executor.execute(
                () -> {
                    try {
                        String encrypted = encrypt(json.toString());
                        if (encrypted == null) return;

                        String timestamp =
                                new java.text.SimpleDateFormat(
                                                "yyyyMMdd_HHmmss", java.util.Locale.getDefault())
                                        .format(new java.util.Date());
                        String fileName = "tiger_backup_" + timestamp + ".json";

                        java.io.File backupDir = new java.io.File(getFilesDir(), "backups");
                        if (!backupDir.exists()) backupDir.mkdirs();

                        // احذف الأقدم إذا تجاوزنا 5 نسخ
                        java.io.File[] existing =
                                backupDir.listFiles(f -> f.getName().startsWith("tiger_backup_"));
                        if (existing != null && existing.length >= 5) {
                            java.util.Arrays.sort(
                                    existing,
                                    (a, b) -> Long.compare(a.lastModified(), b.lastModified()));
                            existing[0].delete();
                        }

                        java.io.File backup = new java.io.File(backupDir, fileName);
                        try (java.io.FileOutputStream fos = new java.io.FileOutputStream(backup)) {
                            fos.write(encrypted.getBytes(java.nio.charset.StandardCharsets.UTF_8));
                        }
                        Log.d(TAG, "Auto backup saved: " + fileName);

                    } catch (Exception e) {
                        Log.w(TAG, "Auto backup failed: " + e.getMessage());
                    }
                });
    }

    // ══════════════════════════════════════════════════════════════
    //  Sort القوائم أبجدياً
    // ══════════════════════════════════════════════════════════════
    private void sortAllLists() {
        if (json == null) {
            showJsonLoadingSnack();
            return;
        }
        try {
            sortJsonArray(json.getServerArray());
            sortJsonArray(json.getNetworkArray());
            sortJsonArray(json.getSSLNetworkArray());
            setupAutoCompleteTextView(server_ac, listServer, json.getServerList());
            setupAutoCompleteTextView(network_ac, listNetwork, json.getNetworkList());
            setupAutoCompleteTextView(ssl_network_ac, listSSLNetwork, json.getSSLNetworkList());
            hasUnsavedChanges = true;
            snack("✅ Lists sorted alphabetically.");
        } catch (Exception e) {
            Log.e(TAG, "sort failed", e);
        }
    }

    private void sortJsonArray(org.json.JSONArray arr) {
        if (arr == null || arr.length() < 2) return;
        java.util.List<org.json.JSONObject> list = new java.util.ArrayList<>();
        for (int i = 0; i < arr.length(); i++) {
            org.json.JSONObject o = arr.optJSONObject(i);
            if (o != null) list.add(o);
        }
        list.sort((a, b) -> a.optString("Name", "").compareToIgnoreCase(b.optString("Name", "")));
        while (arr.length() > 0) arr.remove(0);
        for (org.json.JSONObject o : list) arr.put(o);
    }

    // ══════════════════════════════════════════════════════════════
    //  Section State — Empty State + Count Badge
    // ══════════════════════════════════════════════════════════════
    private void updateSectionState(android.view.View section, int count) {
        android.view.View emptyState = section.findViewById(R.id.empty_state);
        android.view.View dropdownLayout = section.findViewById(R.id.dropdown_layout);
        android.view.View actionButtons = section.findViewById(R.id.action_buttons);
        android.view.View countBadge = section.findViewById(R.id.count_badge);
        com.google.android.material.textview.MaterialTextView countText =
                section.findViewById(R.id.count_text);

        boolean isEmpty = (count == 0);
        emptyState.setVisibility(isEmpty ? android.view.View.VISIBLE : android.view.View.GONE);
        dropdownLayout.setVisibility(isEmpty ? android.view.View.GONE : android.view.View.VISIBLE);
        actionButtons.setVisibility(isEmpty ? android.view.View.GONE : android.view.View.VISIBLE);
        countBadge.setVisibility(isEmpty ? android.view.View.GONE : android.view.View.VISIBLE);
        if (countText != null) countText.setText(String.valueOf(count));
    }

    private void refreshSectionStates() {
        android.view.View serverSection = findViewById(R.id.server_section);
        android.view.View httpSection = findViewById(R.id.http_section);
        android.view.View sslSection = findViewById(R.id.ssl_section);
        if (serverSection != null) updateSectionState(serverSection, listServer.size());
        if (httpSection != null) updateSectionState(httpSection, listNetwork.size());
        if (sslSection != null) updateSectionState(sslSection, listSSLNetwork.size());
    }

    private void setSectionIcon(android.view.View section, int iconRes) {
        android.widget.ImageView icon = section.findViewById(R.id.section_icon);
        if (icon != null) icon.setImageResource(iconRes);
    }

    @Override
    protected void onPause() {
        super.onPause();
        // حفظ تلقائي عند مغادرة الشاشة — يحمي من فقدان البيانات
        if (json != null) {
            json.save();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (executor != null && !executor.isShutdown()) {
            executor.shutdown();
        }
    }
}
